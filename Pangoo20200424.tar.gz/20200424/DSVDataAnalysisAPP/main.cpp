#include <glib.h>
#include "AppManager.h"
#include <iostream>
#include <fstream>
#include "DSVLog.h"

int main(void)
{
	AppManager* _manager = AppManager::GetInstance();
	_manager->StartApp();
	YDLOG(YD_INFO, "main", "~~~~~~~~~~~~~~~~~~~~~~~~\n");
	YDLOG(YD_INFO, "main", "DataAnalysisAPP Start!!!\n");
	YDLOG(YD_INFO, "main", "~~~~~~~~~~~~~~~~~~~~~~~~\n");

	while (true) {
		sleep(10);
	}
	return 0;
}


