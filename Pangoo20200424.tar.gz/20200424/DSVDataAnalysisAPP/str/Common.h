/*
 * Common.h
 *
 *  Created on: Mar 6, 2020
 *      Author: yindi
 * Description: 
 */

#ifndef COMMON_H_
#define COMMON_H_

#define MCU_COM_GET4 SV_USER_COMPONENT_24

#define vuint8 unsigned char

//Pangoo
typedef struct PG_CmdData{
	vuint8 PG_CmdLock;
	vuint8 PG_CmdFindCar;
	vuint8 PG_CmdAirCon;
	vuint8 PG_CmdLight[4];
}PG_CmdData_t;

#endif /* COMMON_H_ */
