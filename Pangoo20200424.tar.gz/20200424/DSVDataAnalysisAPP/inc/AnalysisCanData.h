/*
 * AnalysisCanData.h
 *
 *  Created on: 2017年9月1日
 *      Author: ghy
 *      Editor: huangwenchao
 */

#ifndef ANALYSISCANDATA_H_
#define ANALYSISCANDATA_H_

#include <string>
#include <string.h>
#include <stdint.h>
#include <glib.h>
#include <vector>
#include "CANMessageManagement_GB.h"
#include "Common.h"
#include <vector>
#include <map>

class AnalysisCanData
{
public:
	AnalysisCanData();
	virtual ~AnalysisCanData();
	virtual void AnalysisToPlat(uint8_t __number) = 0;//Pangoo--20181128
	void AnalysisMCU(uint8_t __MCUTYPE, uint8_t __MCUNO, uint8_t* __buff,uint8_t __len);//Pangoo
	virtual void HandleMCU(uint8_t __MCUTYPE, uint8_t __MCUNO, uint8_t* __buff, uint8_t __len)=0;//Pangoo
protected:
	CANMessageManagement_GB* m_canMessageManagementGB;
};

#endif /* ANALYSISCANDATA_H_ */
