#ifndef CANMESSAGEMANAGEMENT_GB_H_
#define CANMESSAGEMANAGEMENT_GB_H_

#include <map>
#include <sys/types.h>
#include "CANMessageManagement.h"
#include "Common.h"
#include <sys/time.h>
#include <time.h>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <mutex>

class CANMessageManagement_GB:public CANMessageManagement
{
public:
	virtual ~CANMessageManagement_GB();
	static CANMessageManagement_GB* GetInstance();

	void SetVehicleCondition(uint8_t __vehicleCondition);//车辆状态
	void SetChargingState(uint8_t __chargingState);//充电状态
	void SetRuningMode(uint8_t __runingMode);//运行模式
	void SetVehicleSpeed(uint16_t __vehicleSpeed);//车速
	void SetAccumulatedMileage(uint32_t __accumulatedMileage);//里程
	void SetTotalVoltage(uint16_t __totalVoltage);//总电压
	void SetTotalCurrent(uint16_t __totalCurrent);//总电流
	void SetSOCState(uint8_t __SOCState);//SOC状态
	void SetDCDCState(uint8_t __DCDCState);//DC-DC状态
	void SetAccelerationPedal(uint8_t __accelerationPedal);//加速踏板状态
	void SetBrakePedalState(uint8_t __brakePedalState);//制动踏板状态
	void SetDrivelineState(uint8_t __drivelineState);//齿轮状态
	void SetInsulationResistance(uint16_t __insulationResistance);//绝缘电阻
	void SetNumberOfDriveMotorNumber(uint16_t __numberOfDriveMotorNumber);//驱动电机个数
	void SetFuelCellVoltage(uint16_t __fuelCellVoltage);//燃料电池电压
	void SetFuelCellCurrent(uint16_t __fuelCellCurrent);//燃料电池电流
	void SetFuelConsumptionRate(uint16_t __fuelConsumptionRate);//燃料消耗率
	void SetTotalNumberOfFuelCellTemperatureProbes(uint16_t __totalNumberOfFuelCellTemperatureProbes);//燃料电池温度探针总数
	void SetProbeTemperatureValue(uint8_t __probeTemperatureValue);//探针温度值
	void SetTheHighestTemperatureInAHydrogenSystem(uint16_t __theHighestTemperatureInAHydrogenSystem);//氢系统中最高温度
	void SetTheHighestTemperatureProbeCodeInTheHydrogenSystem(uint8_t __theHighestTemperatureProbeCodeInTheHydrogenSystem);//氢系统中最高温度探针代号
	void SetTheHighestConcentrationOfHydrogen(uint16_t __theHighestConcentrationOfHydrogen);//氢气最高浓度
	void SetHydrogenMaximumConcentrationSensorCode(uint8_t __hydrogenMaximumConcentrationSensorCode);//氢气最高浓度传感器代号
	void SetHydrogenMaximumPressure(uint16_t __hydrogenMaximumPressure);//氢气最高压力
	void SetHydrogenMaximumPressureSensorCode(uint8_t __hydrogenMaximumPressureSensorCode);//氢气最高压力传感器代号
	void SetHighVoltageDCDCStatus(uint8_t __highVoltageDCDCStatus);//高压DC/DC状态
	void SetEngineState(uint8_t __engineState);//发动机状态
	void SetCrankshaftSpeed(uint16_t __crankshaftSpeed);//曲轴转速
	void SetValidPosition(uint8_t __validPosition);//定位状态
	void SetLongitude(uint32_t __longitude);//经度
	void SetLatitude(uint32_t __latitude);//纬度
	void SetHighestVoltageBatterySubsystemNumber(uint8_t __highestVoltageBatterySubsystemNumber);//最高电压电池子系列号
	void SetHighestVoltageBatteryCellCode( uint8_t __highestVoltageBatteryCellCode);//最高电压电池单元代码
	void SetHighestcellvoltage(uint16_t __highestcellvoltage);//电池单体电压最高值
	void SetLowestVoltageBatterySubsystemNumber(uint8_t __lowestVoltageBatterySubsystemNumber);//最低电压电池子系统号
	void SetLowestVoltageBatteryCellCode(uint8_t __lowestVoltageBatteryCellCode);//最低电压电池单体代号
	void SetLowestCellVoltage(uint16_t __lowestCellVoltage);//电池单体电压最低值
	void SetHighestTemperatureSubsystemNumber(uint8_t __highestTemperatureSubsystemNumber);//最高温度子系统号
	void SetHighestTemperatureProbeNumber(uint8_t __highestTemperatureProbeNumber);//最高温度探针单体代号
	void SetHighestTemperatureValue(uint8_t __highestTemperatureValue);//最高温度值
	void SetLowestTemperatureSubsystemNumber(uint8_t __lowestTemperatureSubsystemNumber);//最低温度子系统号
	void SetLowestTemperatureProbeSerialNumber(uint8_t __lowestTemperatureProbeSerialNumber);//最低温度探针子系统代号
	void SetLowestTemperatureValue(uint8_t __lowestTemperatureValue);//最低温度值
	void SetAlertFrame(std::string __alertFrame);//报警数据
	void SetRechargeableEnergyStorageDeviceTemperatureSum(uint8_t __rechargeableEnergyStorageDeviceTemperatureSum);//可充电储能子系统个数
	void SetRechargeableEnergyStorageDeviceVolSum(uint8_t __rechargeableEnergyStorageDeviceVolSum);//可充电储能子系统个数

	void SetWindowMode(uint8_t __windowMode);//车窗状态
	void SetLockerMode(uint8_t __lockerMode);//门锁状态
	void SetCarLightState(uint32_t __carLightState);//车灯状态
	void SetBCMState(uint8_t __BCMstate);//发动机
	void SetWaterTemperature(uint8_t __waterTemperature);//水温
	void SetAirCondition(uint8_t __AirCondition);//空调
	void SetErrorLevel(uint8_t __errorLevel);//故障
	void SetReAccumulatedMileage(uint16_t __reAccumulatedMileage);//续驶里程
	void SetHandBrake(uint8_t __handBrake);//手刹
	void SetWiper(uint8_t __wiper);//雨刮
	void SetACPower(uint8_t __ACPower);//空调风速
	void SetACTemperature(uint8_t __ACTemperature);//空调温度
	void SetACWindType(uint8_t __ACWindType);//空调吹风模式
	void SetACType(uint8_t __ACType);//空调模式
	void SetBatteryWaterTemperature(uint32_t __batteryWaterTemperature);//电池水温
	void SetMachineWaterTemperature(uint8_t __machineWaterTemperature);//电机水温
	void SetLockResponse(uint8_t __LockRes);//门锁响应
	void SetFindResponse(uint8_t __FindCar);//寻车响应
	void SetAirConditionResponse(uint8_t __AirCond);//空调响应
	void SetRollAngle(uint8_t __RollAngle);//侧倾角
	void SetPitchAngle(uint8_t __PitchAngle);//俯仰角
	void SetWarnClutch(uint8_t __WarnClutch);//离合器预警
	void SetWarnGearBox(uint8_t __WarnGearBox);//变速箱预警
	void SetWarnBrake(uint8_t __WarnBrake);//刹车过热
	void SetWarnOxygen(uint8_t __WarnOxygen);//发动机后置氧传感器需要诊断援助
	void SetWarnTire(uint8_t __WarnTire);//胎压预警
	void SetOilSpeed(uint16_t __OilSpeed);//瞬时油耗
	void SetDriverBelt(uint8_t __DriverBelt);//驾驶员安全带状态
	void SetPassengerBelt(uint8_t __PassengerBelt);//乘客安全带状态
	void SetDaiSu(uint8_t __DaiSu);//怠速状态
	void SetTirePreLow(uint8_t __TirePreLow);//轮胎低压指示
	void SetKeyGear(uint8_t __KeyGear);//钥匙档位
	void SetSpeedLimitState(uint8_t __SpeedLimitState);//巡航和限速系统开关状态
	void SetAbsFailure(uint8_t __AbsFailure);//防抱死制动系统失败
	void SetAbsActive(uint8_t __AbsActive);//防抱死制动系统激活
	void SetYawAcc(uint16_t __YawAcc);//车身横摆角速度
	void SetActualAccValid(uint8_t __ActualAccValid);//实际加速度有效
	void SetActualAcc(uint16_t __ActualAcc);//实际加速度
	void SetWheelAngle(uint16_t __WheelAngle);//方向盘转角
	void SetCrossAcc(uint16_t __CrossAcc);//侧向加速度
	void SetVerticalAcc(uint16_t __VerticalAcc);//纵向加速度
	void SetTurnLight(uint8_t __TurnLight);//转向灯
	void SetIMUYaw(uint16_t __IMUYaw);//IMU横摆角速度
	void SetWheelSpeed(uint16_t __WheelSpeed);//方向盘转速
	void SetBrakeStatSig(uint8_t __BrakeStatSig);//刹车状态信号
	void SetRemainOil(uint16_t __RemainOil);//剩余油量

	void AppendPGPacket(guchar* __vehicleData, guint& __index);//Pangoo
	void DebugPGPacket(guchar* __vehicleData, guint& __index);//Pangoo--0820--only use for ChengDu_Test
	void LogPGforMCUTest();//Pangoo
	void DataUploadTest();//Pangoo
	void AppendPGResPacket(guchar* __vehicleData, guint& __index);//Pangoo
private:
	CANMessageManagement_GB();
	static CANMessageManagement_GB* m_instance;
	//Pangoo
	uint8_t m_PG_CarStat;//车辆状态
	uint8_t m_PG_ChargeStat;//充电状态×
	uint16_t m_PG_Speed;//车速
	uint32_t m_PG_TotalMile;//累计里程
	uint16_t m_PG_TotalVol;//总电压×
	uint16_t m_PG_TotalEle;//总电流×
	uint8_t m_PG_SOC;//SOC状态×
	uint8_t m_PG_DC2;//DC-DC状态×
	uint8_t m_PG_Gear;//档位
	uint16_t m_PG_Resis;//绝缘电阻×
	uint8_t m_PG_AccPedal;//加速踏板行程
	uint8_t m_PG_BrakePedal;//制动踏板行程
	uint8_t	m_PG_TurnLight;//转向灯
	uint16_t m_PG_VerticalAcc;//纵向加速度
	uint16_t m_PG_CrossAcc;//侧向加速度
	uint16_t m_PG_IMUSpeed;//IMU横摆角速度×
	uint16_t m_PG_WheelAngel;//方向盘转角
	uint16_t m_PG_WheelSpeed;//方向盘转速×
	uint16_t m_PG_ActualAcc;//实际加速度
	uint8_t m_PG_ActualAccBool;//实际加速度有效
	uint16_t m_PG_YawAcc;//车身横摆角速度
	uint8_t m_PG_AbsActive;//防抱死制动系统激活
	uint8_t m_PG_AbsFailure;//防抱死制动系统失败
	uint8_t m_PG_SpeedLimitStat;//巡航和限速系统开关状态
	uint8_t m_PG_BrakeStateSig;//制动状态信号×
	uint8_t m_PG_KeyGear;//钥匙档位
	uint8_t m_PG_TirePreLow;//轮胎低压指示
	uint8_t m_PG_DaiSu;//怠速状态
	uint8_t m_PG_PassBelt;//乘客安全带状态
	uint8_t m_PG_DriverBelt;//驾驶员安全带状态
	uint8_t m_PG_ValidPosition;//定位状态
	uint32_t m_PG_Longitude;//经度
	uint32_t m_PG_Latitude;//纬度
	uint8_t m_PG_EngineStat;//发动机状态
	uint16_t m_PG_QuZhou;//曲轴转速
	uint16_t m_PG_oilSpeed;//瞬时油耗
	uint16_t m_PG_RemainOil;//剩余油量
	uint8_t m_PG_DoorLockMode;//门锁状态
	uint8_t m_PG_WindowMode;//门窗状态
	uint32_t m_PG_CarLight;//车灯
	uint8_t m_PG_Engine;//发动机
	uint8_t m_PG_WaterTemperature;//水温
	uint8_t m_PG_AirConditioner;//空调
	uint8_t m_PG_BatteryMode;//动力电池故障严重状态×
	uint16_t m_PG_ContinueMile;//续航里程
	uint8_t m_PG_HandBrake;//手刹
	uint8_t m_PG_Wiper;//雨刮
	uint8_t m_PG_ResLock;//门锁响应
	uint8_t m_PG_ResFind;//寻车响应
	uint8_t m_PG_ResAirCond;//空调响应


	//----------------------20181128------------------
	//轻微故障--20181128
	uint8_t m_PG_MinorWarn1;//刹车片磨损指示
	uint8_t m_PG_MinorWarn2;//发动机机油更换指示
	uint8_t m_PG_MinorWarn3;//发动机机油热指示
	uint8_t m_PG_MinorWarn4;//发动机机油压力低指示
	//一般故障--20181128
	uint8_t m_PG_NormalWarn1;//12伏电池系统不稳定指示
	uint8_t m_PG_NormalWarn2;//空调压缩机故障指示
	uint8_t m_PG_NormalWarn3;//主动振动故障指示
	uint8_t m_PG_NormalWarn4;//巡航暂时不可用指示
	uint8_t m_PG_NormalWarn5;//刹车过热指示
	uint8_t m_PG_NormalWarn6;//压缩机驱动故障状态指示
	uint8_t m_PG_NormalWarn7;//压缩机高压异常状态指示
	uint8_t m_PG_NormalWarn8;//压缩机内部可恢复故障指示
	uint8_t m_PG_NormalWarn9;//压缩机内部关闭故障指示
	uint8_t m_PG_NormalWarn10;//压缩机电机性能故障指示
	uint8_t m_PG_NormalWarn11;//压缩机输出过载指示
	uint8_t m_PG_NormalWarn12;//压缩机过热指示
	uint8_t m_PG_NormalWarn13;//过温警告指示
	uint8_t m_PG_NormalWarn14;//发动机扭矩减小故障
	uint8_t m_PG_NormalWarn15;//电动驻车系统警告指示
	uint8_t m_PG_NormalWarn16;//燃油系统非排放相关故障指示
	uint8_t m_PG_NormalWarn17;//变速离合器故障指示
	uint8_t m_PG_NormalWarn18;//变速箱液力变矩器离合器命令模式故障指示
	uint8_t m_PG_NormalWarn19;//变速箱热管理
	//严重故障--20181128
	uint8_t m_PG_SeriousWarn1;//自动变速器换挡方向故障指示
	uint8_t m_PG_SeriousWarn2;//智能电池传感器内部故障指示
	uint8_t m_PG_SeriousWarn3;//碰撞准备系统失败指示
	uint8_t m_PG_SeriousWarn4;//碰撞准备系统不可用指示
	uint8_t m_PG_SeriousWarn5;//检测到驾驶员油门超驰
	uint8_t m_PG_SeriousWarn6;//燃油控制系统故障指示
	uint8_t m_PG_SeriousWarn7;//燃油喷射器控制模块注入故障指示
	uint8_t m_PG_SeriousWarn8;//燃油系统排放相关故障指示
	//致命故障
	uint8_t m_PG_DeadlyWarn1;//制动系统故障指示
	uint8_t m_PG_DeadlyWarn2;//发动机失败指示

	//根据成都20181128需求，将报警数据迁移到故障信息上报
	uint8_t m_PG_WarnTire;//胎压预警
	uint8_t m_PG_WarnOxygen;//发动机后置氧传感器需要诊断援助
	uint8_t m_PG_WarnBrake;//刹车过热
	uint8_t m_PG_WarnGearBox;//变速箱预警
	uint8_t m_PG_WarnClutch;//离合器预警
	uint8_t m_PG_WarnPitchAngle;//俯仰角
	uint8_t m_PG_WarnRollAngle;//侧倾角

	std::vector<uint8_t> m_PG_WarnFlag; // 各个预警等级的集合

	std::mutex m_mutex; // 针对m_PG_WarnFlag

public:
	void SetWarnFlag(uint8_t __WarnFlag);
	std::vector<uint8_t> GetWarnFlag(); // 获取需要上传的预警数据(按照预警等级区分)
	void InitWarn();
	//20181128:成都要求增加故障信息上传
	void SetMinorFailure1(uint8_t __Fault);
	void SetMinorFailure2(uint8_t __Fault);
	void SetMinorFailure3(uint8_t __Fault);
	void SetMinorFailure4(uint8_t __Fault);
	void SetNormalFailure1(uint8_t __Fault);
	void SetNormalFailure2(uint8_t __Fault);
	void SetNormalFailure3(uint8_t __Fault);
	void SetNormalFailure4(uint8_t __Fault);
	void SetNormalFailure5(uint8_t __Fault);
	void SetNormalFailure6(uint8_t __Fault);
	void SetNormalFailure7(uint8_t __Fault);
	void SetNormalFailure8(uint8_t __Fault);
	void SetNormalFailure9(uint8_t __Fault);
	void SetNormalFailure10(uint8_t __Fault);
	void SetNormalFailure11(uint8_t __Fault);
	void SetNormalFailure12(uint8_t __Fault);
	void SetNormalFailure13(uint8_t __Fault);
	void SetNormalFailure14(uint8_t __Fault);
	void SetNormalFailure15(uint8_t __Fault);
	void SetNormalFailure16(uint8_t __Fault);
	void SetNormalFailure17(uint8_t __Fault);
	void SetNormalFailure18(uint8_t __Fault);
	void SetNormalFailure19(uint8_t __Fault);
	void SetSeriousFailure1(uint8_t __Fault);
	void SetSeriousFailure2(uint8_t __Fault);
	void SetSeriousFailure3(uint8_t __Fault);
	void SetSeriousFailure4(uint8_t __Fault);
	void SetSeriousFailure5(uint8_t __Fault);
	void SetSeriousFailure6(uint8_t __Fault);
	void SetSeriousFailure7(uint8_t __Fault);
	void SetSeriousFailure8(uint8_t __Fault);
	void SetDeadlyFailure1(uint8_t __Fault);
	void SetDeadlyFailure2(uint8_t __Fault);

	void AppendPGWarnPacket(guchar* __vehicleData, guint& __index);
	void AppendPGPeriodWarnPacket(guchar* __vehicleData, guint& __index);
	void AppendPGWarnPacket_Minor(guchar* __vehicleData, guint& __index);
	void AppendPGWarnPacket_normal(guchar* __vehicleData, guint& __index);
	void AppendPGWarnPacket_Serious(guchar* __vehicleData, guint& __index);
	void AppendPGWarnPacket_Deadly(guchar* __vehicleData, guint& __index);
	void AppendPGWarnPacket_Alarm(guchar* __vehicleData, guint& __index);

};

#endif /* CANMESSAGEMANAGEMENT_GB_H_ */
