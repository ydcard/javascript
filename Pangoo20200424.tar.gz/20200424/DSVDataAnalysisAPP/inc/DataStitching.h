/*
 * DataStitching.h
 *
 *  Created on: 2018年3月6日
 *      Author: huangwenchao
 */

#ifndef DATASTITCHING_H_
#define DATASTITCHING_H_

#include <string>
#include <vector>
#include <glib.h>
#include <pthread.h>

class DataStitching
{
public:
	DataStitching();
	virtual ~DataStitching();
	virtual std::string PacketData()=0;
	virtual void DataStitchingMethod(std::string __packetData)=0;
	virtual gboolean IsReady()=0;
protected:
	void LogSysUsecTime(std::string __message) const;
	guint m_newThreadCount;
	guint m_sendController;
	pthread_mutex_t m_mutex;
};

#endif /* DATASTITCHING_H_ */
