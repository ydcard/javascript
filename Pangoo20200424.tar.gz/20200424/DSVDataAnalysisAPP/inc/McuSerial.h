#ifndef DSVMCUSERIAL_H_
#define DSVMCUSERIAL_H_

#include <string>
#include "McuComManager.h"
#include "Common.h"

// 处理MCU数据的结构体
struct ParmStr {
	CommunicateData value;
	bool finish;
};

class McuSerial
{
public:
	McuSerial();
	~McuSerial();
	bool Init();
private:
	void LoopTaskThreadRead();
	void LoopTaskThreadWrite();
	void SentData();
	short GetMCUNO(CommunicateData __confData);
	void SendDataToMCU(PG_CmdData_t __buff);
	McuComManager* m_pCommunicator;
	ParmStr m_parmCommunicate;
};

#endif /* DSVMCUSERIAL_H_ */
