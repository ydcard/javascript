/*
 * AnalysisCanData_Nevs.h
 *
 *  Created on: 2018年2月10日
 *      Author: huangwenchao
 */

#ifndef ANALYSISCANDATA_NEVS_H_
#define ANALYSISCANDATA_NEVS_H_

#include "AnalysisCanData.h"

class AnalysisCanDataPangoo: public AnalysisCanData
{
public:
	virtual ~AnalysisCanDataPangoo();
	static AnalysisCanDataPangoo* GetInstance();
	void AnalysisToPlat(uint8_t __number);//Pangoo--20181128
protected:
	void PG_InitMcuData();//Pangoo
	void HandleMCU(uint8_t __MCUTYPE, uint8_t __MCUNO, uint8_t* __buff, uint8_t __len);//Pangoo
	void Init_data(int __number, int __size);//Pangoo:0827-new_design
	std::map<int,std::vector<uint8_t>> getdata();//Pangoo:0827-new_design
	void Set_data(int __number, uint8_t *buffer, int len);//Pangoo:0827-new_design
	void GetGPSThread();//Pangoo
private:
	AnalysisCanDataPangoo();
	static AnalysisCanDataPangoo* m_instance;
	std::map<int,std::vector<uint8_t>> spi_data;//Pangoo:0827-new_design
//Pangoo:0827-new_design
protected:
	void CheckData_num1();
	void CheckData_num2();
	void CheckData_num3();
	void CheckData_num4();
	void CheckData_num5();
	void CheckData_num6();
	void CheckData_num7();
	void CheckData_num8();
	void CheckData_num9();
	void CheckData_num10();
	void CheckData_num11();
	void CheckData_num12();
	void CheckData_num13();
	void CheckData_num14();
	void CheckData_num15();
	void CheckData_num16();
	void CheckData_num17();
	void CheckData_num18();
	void CheckData_num19();
	void CheckData_num20();
	void CheckData_num21();
	void CheckData_num22();
	void CheckData_num23();
	void CheckData_num24();
	void CheckData_num25();
	void CheckData_num33();
	void CheckData_num34();
	void CheckData_num35();
	void CheckData_num36();
	void CheckData_num37();
	void CheckData_num38();
	void CheckData_num39();
	void CheckData_num40();
	void CheckData_num41();
	void CheckData_num42();
	void CheckData_num43();
	void CheckData_num44();
	void CheckData_num45();
	void CheckData_num50();
	void CheckData_num51();
	void CheckData_num52();

	//20181128
	void CheckData_num100();
	void CheckData_num101();
	void CheckData_num102();
	void CheckData_num103();
	void CheckData_num110();
	void CheckData_num111();
	void CheckData_num112();
	void CheckData_num113();
	void CheckData_num114();
	void CheckData_num115();
	void CheckData_num116();
	void CheckData_num117();
	void CheckData_num118();
	void CheckData_num119();
	void CheckData_num120();
	void CheckData_num121();
	void CheckData_num122();
	void CheckData_num123();
	void CheckData_num124();
	void CheckData_num125();
	void CheckData_num126();
	void CheckData_num127();
	void CheckData_num128();
	void CheckData_num140();
	void CheckData_num141();
	void CheckData_num142();
	void CheckData_num143();
	void CheckData_num144();
	void CheckData_num145();
	void CheckData_num146();
	void CheckData_num147();
	void CheckData_num150();
	void CheckData_num151();
	void CheckData_num160();
	void CheckData_num161();
	void CheckData_num162();
	void CheckData_num163();
	void CheckData_num164();
	void CheckData_num165();
	void CheckData_num166();
};

#endif /* ANALYSISCANDATA_NEVS_H_ */
