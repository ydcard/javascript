/*
 * CANMessageManagement.h
 *
 *  Created on: 2018年3月6日
 *      Author: huangwenchao
 */

#ifndef CANMESSAGEMANAGEMENT_H_
#define CANMESSAGEMANAGEMENT_H_

#include <string>
#include <vector>
#include <glib.h>

class CANMessageManagement
{
public:
	virtual ~CANMessageManagement();
	CANMessageManagement();
	gboolean GetInitState();
	void InitFinish();
	guint GetPacketTimePower();
	void SetPacketTimePower(guint __packetTimePower);
protected:
	gboolean m_init;
	guint m_packetTimePower;
};

#endif /* CANMESSAGEMANAGEMENT_H_ */
