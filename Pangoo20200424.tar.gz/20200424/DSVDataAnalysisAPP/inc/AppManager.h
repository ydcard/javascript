#ifndef APPMANAGER_H_
#define APPMANAGER_H_

#include "McuSerial.h"
#include "Packet.h"
#include <memory>
#include <mutex>

class AppManager
{
public:
	static AppManager* GetInstance() {
		static AppManager instance;
		return &instance;
	}

	~AppManager();
	void StartApp();
private:
	AppManager();
	void InitManager();
	bool InitReadWorker();
	bool InitWriteWorker();
	std::shared_ptr<McuSerial> m_mcuSerial;
	std::shared_ptr<Packet> m_dataPacket;
	std::mutex m_mutex;
};

#endif /* APPMANAGER_H_ */
