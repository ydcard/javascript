/*
 * ToolUtils.h
 *
 *  Created on: 2018年2月8日
 *      Author: huangwenchao
 */

#ifndef TOOLUTILS_H_
#define TOOLUTILS_H_

#include <sys/time.h>
#include <glib.h>
#include <string>
#include <vector>
#include "time.h"
#include "CfgApi.h"
#include "Common.h"

typedef struct timezone TimezoneStr;

class ToolUtils
{
public:
	virtual ~ToolUtils();
	static ToolUtils* GetInstance() {
		static ToolUtils instance;
		return &instance;
	}
	void SysUsecTime(timeval& __tv, tm& __p) const;
	void SysUsecTime(timeval& __tv, tm& __p, gint __buffSec) const;
	void ParseUsecTime(timeval __tv, tm& __p) const;
	std::string ByteToHexStr(guchar* __bytes, guint __size) const;
	std::string ByteToHexStr(gushort __bytes) const;
	glong GetTimeStamp() const;
	gboolean HexStrToByte(const std::string& __hexStr,gchar* __output) const;
	std::string GuidHexStr() const;
private:
	ToolUtils();
};

#endif /* TOOLUTILS_H_ */
