/*
 * TSPBinderCommunication.h
 *
 *  Created on: 2018年3月16日
 *      Author: huangwenchao
 */

#ifndef BINDERCOMMUNICATION_H_
#define BINDERCOMMUNICATION_H_

#include <glib.h>
#include <string>
#include "IInterfaceBinderIPC.h"//TODO
#include "ICallBackBinderIPC.h"//TODO
#include <vector>
#include "Common.h"

#define BinderOnTransact onTransact
#define gulong64 unsigned long long

#define BinderContacts_Send_Common 0
#define BinderContacts_Send_CheckTSPConnected 1
#define BinderContacts_Get_Echo 0
#define BinderContacts_Get_Notify 1
#define BinderContacts_Get_AsyncCallResult 2
#define BinderContacts_Get_PG 4

class BinderContacts: public android::BnInterface<ICallBackBinderIPC>
{
public:
	virtual ~BinderContacts();
	BinderContacts(guint64 __appId);
protected:
	void ASyncCall(gint __methodId, std::string __contentJsonStr);
	virtual void NotifyCallBack(gint __methodId,std::string __notifyJsonStr);
	virtual android::status_t BinderOnTransact(uint32_t __code,const android::Parcel& __data,android::Parcel* __reply,uint32_t __flags = 0);
	virtual void OnASyncCallResult(std::string __resultJsonStr)=0;
	virtual void OnRecvNotify(std::string __notifyJsonStr)=0;
	virtual void OnRecvEchoMessage(std::string __echoJsonStr)=0;
	virtual void OnPGtoTBOX(std::string __pangooJsonStr)=0;//Pangoo
private:
	void CheckTSPConnected();
	android::sp<IInterfaceBinderIPC> m_binderInterface;
	guint64 m_appId;
};

class BinderContactsWorker:public BinderContacts
{
public:
	virtual ~BinderContactsWorker();
	static BinderContactsWorker* GetInstance();
	gboolean IsConnectedIsRun() const; // TSP是否连接成功
	void setPGData(std::string __PGData);//Pangoo ---接收到PG控制数据之后进行数据的解析

	PG_CmdData_t GetPGData() const; // 获取PG控制数据
	gint GetPGFlag() const;	//Pangoo ---是否收到PG控制数据
	gint GetPGNum() const;	//Pangoo ---获取PG控制数据种类+1,当该数值为1的时候表明所有的PG控制消息都已经接收到了应答
	gulong GetPGTime() const;//Pangoo ---获取接收PG控制消息的时间
	gulong waitPGTime();  //Pangoo ---获取从接收到PG控制消息到现在经过的时间
	void InitPGControl();  //Pangoo ---
	void SetPGTime();		//Pangoo ---接受到PG控制消息的时间
 	void SetPGFlag();		//Pangoo ---处理玩PG控制数据将flag复位
	void SetPGNum();		//Pangoo ---每处理完一个控制消息,Num-1
	void SetSerialNum(guchar __number);	//Pangoo ---应答的PG控制消息的number号码
	std::vector<guchar> GetSerial();//Pangoo ---接收到的PG控制消息的number号码集合
	std::vector<guchar> GetSerialNumber();//Pangoo ---获取应答PG控制消息的number集合
	gboolean CheckSerial(guchar number); //Pangoo ---检查应答的消息和接受的PG控制消息的number号能不能对应上

	gboolean DataUpload(std::string __data,std::string __dataType,gboolean __realTime); // 数据上传API
protected:
	// 全部都是NotifyCallBack这个API调用的
	virtual void OnASyncCallResult(std::string __resultJsonStr); // TSP对数据上传的确认
	virtual void OnRecvNotify(std::string __notifyJsonStr); // 确认TSP与后台的连接状态
	virtual void OnRecvEchoMessage(std::string __echoJsonStr); // 目前尚未使用
	virtual void OnPGtoTBOX(std::string __pangooJsonStr);//Pangoo ---PG车辆控制数据的下发
private:
	BinderContactsWorker();
	static BinderContactsWorker* m_instance;
	gboolean m_connectedIsRun; // TSP是否连接到后台

	PG_CmdData_t m_CmdData;  //Pangoo ---PG控制消息
	gint ReqFlag;			//Pangoo ---是否接收到PG控制消息
	gint ReqNum;			//Pangoo ---接收PG控制消息的数量
	gulong PG_time;		//Pangoo ---接收到PG控制消息的时间
	gulong PG_waitTime;      //Pangoo ---接收到PG控制消息后等待的时间
	std::vector<guchar> SerialNum;//Pangoo ---接收到的PG控制消息的number号集合
	std::vector<guchar> GetSerialNum;//Pangoo ---应答的number号集合
};

#endif /* BINDERCOMMUNICATION_H_ */
