/*
 * DataStitching_GB.h
 *
 *  Created on: 2017年3月20日
 *      Author: zhaochao
 *      Editor: huangwenchao
 */

#ifndef DATASTITCHING_GB_H_
#define DATASTITCHING_GB_H_

#include "time.h"
#include "DataStitching.h"
#include "Common.h"
#include "CANMessageManagement_GB.h"

class DataStitching_GB:public DataStitching
{
public:
	DataStitching_GB();
	virtual ~DataStitching_GB();
	virtual std::string PacketData();
	std::string PacketResPGData();//Pangoo
	std::string PacketPGWarnData();//Pangoo--20181210--触发
	std::string PacketPGPeriodWarnData();//Pangoo--20181210--周期
	std::string PacketPGWarnData_Minor();//Pangoo--20181128--触发---1210---取消
	std::string PacketPGWarnData_normal();//Pangoo--20181128--触发---1210---取消
	std::string PacketPGWarnData_Serious();//Pangoo--20181128--触发---1210---取消
	std::string PacketPGWarnData_Deadly();//Pangoo--20181128--触发---1210---取消
	std::string PacketPGWarnData_Alarm();//Pangoo--20181128--触发---1210---取消

	virtual void DataStitchingMethod(std::string __packetData);
	virtual gboolean IsReady();
	void SetTimeValEnable(gboolean __enable, gint __buffSec);
private:
	guint m_erroNumber;
	guint m_errorFirstPower;
	timeval m_timeVal;
	gboolean m_timeValEnable;
	std::vector<std::string> m_bufferContainer;
	std::vector<std::string> m_replenishmentContainer;
	CANMessageManagement_GB* m_messageManagement;
};

#endif /* DATASTITCHING_GB_H_ */
