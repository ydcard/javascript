/*
 * FileOP.h
 *
 *  Created on: 2017年6月5日
 *      Author: ghy
 *      Editor: huangwenchao
 */

#ifndef FILEOP_H_
#define FILEOP_H_

#include <string>
#include <vector>
#include <dirent.h>
#include <pthread.h>
#include <glib.h>
#include <sqlite3.h>

class ReadSql
{
public:
	ReadSql(std::vector<std::string>* __packets);
	~ReadSql();
	void Append(std::string __packet);
private:
	std::vector<std::string>* m_packets;
};

class FileOP
{
public:
	virtual ~FileOP();
	static FileOP* GetInstance();
	void WriteReSentData(std::string __reSentData, guint __hasBeenSend);
	void DelOrOpenReSentData(std::string __dataTime, guint __isDel);
	std::vector<std::string> ReadReSentData();
	void WriteFinishData(std::string __finishData) const;
private:
	FileOP();
	static FileOP* m_instance;
	void TryToDelFinishDataMax7CountFiles() const;
	void TryToTestReSentDirAndDelMax7DayFiles() const;
	void InsertIntoDb(sqlite3* __db, std::string __time, std::string __data, guint __isFinish);
	void DeleteItemFromDb(sqlite3* __db, std::string __time, guint __isDel);
	void SelectItemsFromDb(sqlite3* __db, std::vector<std::string>* __list, gushort __count);
	gint m_canReadCount;
	gint m_canReadCountResetCount;
};

#endif /* FILEOP_H_ */
