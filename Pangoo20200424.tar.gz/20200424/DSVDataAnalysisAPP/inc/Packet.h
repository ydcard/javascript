#ifndef PACKET_H_
#define PACKET_H_

#include <string>
#include <vector>
#include <glib.h>
#include <sys/time.h>
#include <mutex>
#include "DataStitching_GB.h"

class Packet
{
public:
	Packet();
	virtual ~Packet();
	bool Init();
	void StartDataCollection();
private:
	DataStitching_GB* m_DataStitchingGB;
	timer_t m_timer;
	std::mutex m_mutex;
	uint32_t m_timeController{0}; // 计数器,1~100000之间轮询
	static void HandleTimer(sigval __value);
};
#endif  /* PACKET_H_ */
