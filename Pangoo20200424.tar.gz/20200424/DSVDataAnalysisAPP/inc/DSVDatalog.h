/*
 * DSVDatalog.h
 *
 *  Created on: Aug 20, 2018
 *      Author: desay-sv
 */

#ifndef DSVDATALOG_H_
#define DSVDATALOG_H_

#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <memory>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sys/time.h>


typedef enum Log_Level_t
{
	VL_ERR	=	0,
	VL_WARN	= 	1,
	VL_INFO	=	2,
	VL_PERIOD = 3,
	VL_DEBUG=	4,
	VL_ALL	=	5
}Log_Level;

#define STRING_MAX 1024
#define LOG_FILE_NAME "DataLog.log"
extern Log_Level mLogLevel;
extern bool mIsToFile;//全局变量
extern bool mIsPrintf;
//extern std::ofstream mOfs;
#define DLOG_SET(isPrintf,isToFile,logLevel) Log_Level mLogLevel = logLevel; bool mIsToFile = isToFile; bool mIsPrintf = isPrintf;
#define USER_SPRINT_BASE(outstr, format, args...)  sprintf(outstr, format, ##args)
#define USER_SPRINT_0(outstr, format, args... )\
{\
	timeval timeVal;\
	gettimeofday(&timeVal,NULL);\
	time_t timep;\
    time( &timep );\
    timep = timep + 8*3600;\
    struct tm *pTM = gmtime( &timep );\
    USER_SPRINT_BASE(outstr,"[%4d-%02d-%02d %02d:%02d:%02d:%06ld]" format,\
    				 pTM->tm_year+1900, pTM->tm_mon+1, pTM->tm_mday, pTM->tm_hour, pTM->tm_min, pTM->tm_sec,timeVal.tv_usec,##args);\
}
#define USER_SPRINT(outstr, tag, format, args... )  USER_SPRINT_0(outstr, "[%s]" format, tag, ##args)
#define DLOG(logLevel, tag, format, args... )\
{\
	if(logLevel<=mLogLevel){\
		char tempStr[STRING_MAX];\
		USER_SPRINT(tempStr,tag,format,##args);\
		if(mIsPrintf == true){\
			printf("%s",tempStr);\
		}\
		if(mIsToFile == true){\
			std::ofstream mOfs;\
			mOfs.open(LOG_FILE_NAME, std::ofstream::app);\
			mOfs.write(tempStr, strlen(tempStr));\
			mOfs.close();\
		}\
	}\
}

#endif /* DSVDATALOG_H_ */
