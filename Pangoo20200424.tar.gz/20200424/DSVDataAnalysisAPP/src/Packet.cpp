#include "TSPBinderCommunication.h"
#include "Packet.h"
#include "ToolUtils.h"
#include "DSVLog.h"


Packet::Packet()
{
	this->m_timer=NULL;
	this->m_DataStitchingGB=new DataStitching_GB();
}

Packet::~Packet()
{
	if(this->m_timer!=NULL) {
		timer_delete(this->m_timer);
	}
	delete this->m_DataStitchingGB;
}

bool Packet::Init() {
	ToolUtils* _toolUtils=ToolUtils::GetInstance();
	timeval _tv;
	tm _p;
	_toolUtils->SysUsecTime(_tv, _p);
	//　TEST: 为了测试的需求将下面的4行注释，之后的实际处理中将其打开
	if(1900 + _p.tm_year < 2000) {
		char __strTime[128];
		sprintf(__strTime,"ERROR time: %d\n",1900 + _p.tm_year);
		YDLOG(YD_WARN, "Packet", __strTime);
		return false;
	}
	return true;
}

// TODO: 后续考虑用自定义线程池来取代这个
void Packet::StartDataCollection()
{
	YDLOG(YD_INFO, "Packet", "startDataCollect\n");
	std::unique_lock<std::mutex>(m_mutex);
	{
		if(this->m_timer==NULL) {
			sigevent _se;
			memset(&_se, 0, sizeof(sigevent));
			_se.sigev_value.sival_int = 0;
			_se.sigev_value.sival_ptr = this;
			_se.sigev_notify = SIGEV_THREAD;
			_se.sigev_notify_function = Packet::HandleTimer;
			timer_create(CLOCK_REALTIME, &_se, &this->m_timer);
		}
		timeval _tv;
		TimezoneStr _tz;
		gettimeofday(&_tv, &_tz);
		itimerspec _it;
		_it.it_interval.tv_sec = 0;
		_it.it_interval.tv_nsec = 250000000;
		_it.it_value.tv_sec = 3;
		//将开始时间定为500000微秒附近，防止时间边界！
		if(_tv.tv_usec > 500000) {
			_it.it_value.tv_nsec = (1500000-_tv.tv_usec)*1000;
		}
		else {
			_it.it_value.tv_nsec = (500000-_tv.tv_usec)*1000;
		}
		this->m_DataStitchingGB->SetTimeValEnable(true, _it.it_value.tv_sec);
		timer_settime(this->m_timer, 0, &_it, 0);
	}
}

/**
* @param   sigval __value
* @return  null
* @retval  void
* @note    此函数会被线程池中线程以多线程的方式调用，每250ms采集一次
**/
void Packet::HandleTimer(sigval __value) {
	YDLOG(YD_DEBUG, "Packet", "250ms send message to tsp\n");
	Packet* _target=(Packet*)__value.sival_ptr;
	_target->m_timeController++;
	_target->m_timeController=_target->m_timeController>100000?1:_target->m_timeController;
	BinderContactsWorker* __SvBinder = BinderContactsWorker::GetInstance();
	CANMessageManagement_GB* __SvMCUData = CANMessageManagement_GB::GetInstance();
	if (_target->m_DataStitchingGB->IsReady()) {
		if (__SvBinder->GetPGNum() == 1) { // 车辆控制的应答
			YDLOG(YD_INFO, "Packet", "Get response message from mcu\n");
			std::string _packet=_target->m_DataStitchingGB->PacketResPGData();
			__SvBinder->InitPGControl();
		}
		if (__SvBinder->waitPGTime() > 2000 && __SvBinder->waitPGTime() < 2500) { // 超时应答逻辑
			YDLOG(YD_WARN, "Packet", "Overtime get response message from mcu\n");
			std::string _packet=_target->m_DataStitchingGB->PacketResPGData();
			__SvBinder->InitPGControl();
		}

		std::vector<uint8_t> __warnflag = __SvMCUData->GetWarnFlag();
		if (!__warnflag.empty()) {
			YDLOG(YD_INFO, "Packet", "Recv Warning message from mcu\n");
			printf("=================send fault message==================\n");
			std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData();
			__SvMCUData->InitWarn();
		}
		// 20200423:黄守义确认该部分数据不在第一期需求中实现
//		if (_target->m_timeController%40==1) { // 周期预警数据上传---10s为周期上传
//			YDLOG(YD_INFO, "Packet", "Period Warning message from mcu\n");
//			printf("=================send period warn message=============\n");
//			std::string _packet=_target->m_DataStitchingGB->PacketPGPeriodWarnData();
//		}

//			if(!__warnflag.empty()){
//				if(__warnflag == 1){
//					YDLOG(YD_INFO, "Packet", "Period Warning message from mcu1\n");
//					std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData_Minor();
//				}
//				else if(__warnflag == 2){
//					YDLOG(YD_INFO, "Packet", "Period Warning message from mcu2\n");
//					std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData_normal();
//				}
//				else if(__warnflag == 3){
//					YDLOG(YD_INFO, "Packet", "Period Warning message from mcu3\n");
//					std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData_Serious();
//				}
//				else if(__warnflag == 4){
//					YDLOG(YD_INFO, "Packet", "Period Warning message from mcu4\n");
//					std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData_Deadly();
//				}
//				else if(__warnflag == 5){
//					YDLOG(YD_INFO, "Packet", "Period Warning message from mcu5\n");
//					std::string _packet=_target->m_DataStitchingGB->PacketPGWarnData_Alarm();
//				}
//				__SvMCUData->InitWarnFlag();
//			}

		if (_target->m_timeController%4==1) {//0815:按测试需求将4改为了40
			std::string _packet=_target->m_DataStitchingGB->PacketData();
			if(_packet != "") {
				_target->m_DataStitchingGB->DataStitchingMethod(_packet);//打包国标数据
			}
		}
	}
	return;
}

