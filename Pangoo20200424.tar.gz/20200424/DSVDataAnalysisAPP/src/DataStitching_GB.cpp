/*
 * DataStitching_GB.cpp
 *
 *  Created on: 2017年3月20日
 *      Author: zhaochao
 *      Editor: huangwenchao
 */

#include "FileOP.h"
#include "TSPBinderCommunication.h"
#include "DataStitching_GB.h"
#include "ToolUtils.h"
#include <iostream>
#include "DSVLog.h"

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

DataStitching_GB::DataStitching_GB():DataStitching()
{
	this->m_messageManagement=CANMessageManagement_GB::GetInstance();
	this->m_erroNumber=0;
	this->m_errorFirstPower=0;
	this->m_timeValEnable=false;
}

DataStitching_GB::~DataStitching_GB()
{
}


/**
* @param   void
* @return  initState
* @retval  gboolean
* @note
**/
gboolean DataStitching_GB::IsReady()
{
	return this->m_messageManagement->GetInitState();
}

/**
* @param   gboolean __enable
* @return  null
* @retval  void
* @note
**/
void DataStitching_GB::SetTimeValEnable(gboolean __enable, gint __buffSec)
{
	if(__enable) {
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		tm _p;
		_toolUtils->SysUsecTime(this->m_timeVal, _p, (8 * 3600 + __buffSec));
		this->m_timeValEnable=true;
	}
	else {
		this->m_timeValEnable=false;
	}
}

/**
* @param   std::vector<PacketSignals*> __dataPacketSignals,std::string __friendlyName
* @return  data
* @retval  std::string
* @note    此函数会被线程池中线程以多线程的方式调用
**/
std::string DataStitching_GB::PacketData()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100 + 40) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;

		this->m_messageManagement->AppendPGPacket(_vehicleData, _number);
//		this->m_messageManagement->DebugPGPacket(_vehicleData, _number); // 模拟假数据
		this->m_messageManagement->LogPGforMCUTest(); // 进行spi-debug时使用

		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		// TODO: VehicleVIN由TSP配置消息进行静态设置

		// TODO: 0306:改名为heartbeat
		YDLOG(YD_PERIOD, "DataStitching_GB", "every second send heartbeat to server\n");
		std::string _heartBeat = "";
		_binderContactsWorker->DataUpload(_heartBeat,"HeartBeat",true);

		std::string _ret = ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

/**
* @param  Pangoo
* @return  data
* @retval  std::string
* @note    此函数会被线程池中线程以多线程的方式调用
**/
std::string DataStitching_GB::PacketResPGData()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGResPacket(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooResponse",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

/**
* @param   std::string __packetData, gboolean __sendIsRun
* @return  void
* @retval  null
* @note    此函数会被线程池中线程以多线程的方式调用
**/
void DataStitching_GB::DataStitchingMethod(std::string __packetData)
{
	FileOP* _fileOP = FileOP::GetInstance();
	//实时数据处理模块
	//TODO 若SVvehicleDataUploadManager::OnASyncCallResult模块未能通知数据是否发送成功，默认发送成功！
	BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
	pthread_mutex_lock(&this->m_mutex);
	// 下面是上传的倍率，目前的需求是10s上传一次，所以这里的倍率目前设置为10即可
	gboolean _sendController = this->m_sendController % this->m_messageManagement->GetPacketTimePower() == 0?true:false;
	this->m_newThreadCount++;
	this->m_sendController++;
	this->m_sendController=this->m_sendController > 10000?1:this->m_sendController;

	gboolean _threadMaxActualAlarm = this->m_newThreadCount < 5?false:true;
	pthread_mutex_unlock(&this->m_mutex);
	if (_sendController) {
		_fileOP->WriteFinishData(__packetData);//写入所有需要发送数据的文件
		//实时数据，控制最多5个新开线程执行任务
		if (!_binderContactsWorker->IsConnectedIsRun() || _threadMaxActualAlarm) {
			printf("99999999999999999999999999999999\n");

			YDLOG(YD_INFO, "DataStitching_GB", "can't connect to TSP,put data into database\n");
			_fileOP->WriteReSentData(__packetData, 0);//保存数据进发送仓库,下次补发
		}
		else {
			printf("0000000000000000000000000000000\n");
			YDLOG(YD_INFO, "DataStitching_GB", "every 10 seconds send realtime message to servers\n");
			_fileOP->WriteReSentData(__packetData, 1);//保存数据进发送仓库,默认发送成功
			_binderContactsWorker->DataUpload(__packetData,"DataUpload",true);
		}
	}
	//定义临时补发帧文件
	std::vector<std::string> _resendBuffList;
	//缓存最近30帧数据
	pthread_mutex_lock(&this->m_mutex);

	//获取补发数据，控制最多3个新开线程执行任务
	if (this->m_newThreadCount < 3) {
		if (this->m_replenishmentContainer.size()== 0) {
			//获取补发数据
			this->m_replenishmentContainer = _fileOP->ReadReSentData();
		}
		if (this->m_replenishmentContainer.size()!= 0) {
			// 这个函数以6次为周期进行调用
			for (std::vector<std::string>::iterator _iter=this->m_replenishmentContainer.begin(); _iter!=this->m_replenishmentContainer.end();_iter++) {
				_resendBuffList.push_back((std::string)(*_iter));
			}
			this->m_replenishmentContainer.clear();
		}
	}
	else {
	}
	pthread_mutex_unlock(&this->m_mutex);
	//补发30帧数据
	if (_resendBuffList.size()!= 0) {
		printf("YINDI: size is %d\n", _resendBuffList.size());
//		printf("buffer size is %d\n",_resendBuffList.size());
		std::vector<std::string>::iterator _iter;
		for(_iter=_resendBuffList.begin(); _iter!=_resendBuffList.end();_iter++) {
			if(!_binderContactsWorker->IsConnectedIsRun()) {
				printf("YINDI:3\n");
				break;
			}
			std::string _containerData=(std::string)(*_iter);
			_fileOP->DelOrOpenReSentData(_containerData.substr(0, 12), 1);//更新is_finish=1,默认发送成功
			_binderContactsWorker->DataUpload(_containerData,"DataUpload",false);
		}
	}
	//线程退出
	pthread_mutex_lock(&this->m_mutex);
	this->m_newThreadCount--;
	pthread_mutex_unlock(&this->m_mutex);
	this->LogSysUsecTime("xchao_write:GB_finish**********");
}


//--------------------------20181128---------------------------------
std::string DataStitching_GB::PacketPGWarnData()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;

		this->m_messageManagement->AppendPGWarnPacket(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		YDLOG(YD_INFO, "PacketPGWarnData", _ret);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGPeriodWarnData()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGPeriodWarnPacket(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		YDLOG(YD_INFO, "PacketPGPeriodWarnData", _ret);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGWarnData_Minor()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGWarnPacket_Minor(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGWarnData_normal()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGWarnPacket_normal(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGWarnData_Serious()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGWarnPacket_Serious(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGWarnData_Deadly()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGWarnPacket_Deadly(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}

std::string DataStitching_GB::PacketPGWarnData_Alarm()
{
	if(this->m_timeValEnable) {
		guchar* _vehicleData = new guchar[800];
//		ToolUtils* _toolUtils=ToolUtils::GetInstance();
//		tm _p;
//		_toolUtils->ParseUsecTime(this->m_timeVal, _p);
		ToolUtils* _toolUtils=ToolUtils::GetInstance();
		timeval __tv;
		TimezoneStr _tz;
		gettimeofday(&__tv, &_tz);
		__tv.tv_sec = __tv.tv_sec + 8 * 3600;
		tm _p;
		_toolUtils->ParseUsecTime(__tv, _p);
//		this->m_timeVal.tv_sec++;
		guint _number = 0;
		_vehicleData[_number++] = (_p.tm_year-100) & 0xFF;
		_vehicleData[_number++] = (1+_p.tm_mon) & 0xFF;
		_vehicleData[_number++] = _p.tm_mday & 0xFF;
		_vehicleData[_number++] = _p.tm_hour & 0xFF;
		_vehicleData[_number++] = _p.tm_min & 0xFF;
		_vehicleData[_number++] = _p.tm_sec & 0xFF;
		this->m_messageManagement->AppendPGWarnPacket_Alarm(_vehicleData, _number);
		BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
		std::string _ret=ToolUtils::GetInstance()->ByteToHexStr(_vehicleData, _number);
		_binderContactsWorker->DataUpload(_ret,"PangooWarnData",true);
		delete _vehicleData;
		return _ret;
	}
	else {
		return "";
	}
}




//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
