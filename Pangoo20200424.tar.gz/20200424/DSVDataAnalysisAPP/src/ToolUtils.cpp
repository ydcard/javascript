/*
 * ToolUtils.cpp
 *
 *  Created on: 2018年2月8日
 *      Author: huangwenchao
 */

#include "node_type.h"
#include "ToolUtils.h"

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

ToolUtils::~ToolUtils()
{
}


/**
* @param   timeval& __tv, tm& __p
* @return  null
* @retval  void
* @note
**/
void ToolUtils::SysUsecTime(timeval& __tv, tm& __p) const
{
	TimezoneStr _tz;
	gettimeofday(&__tv, &_tz);
	__tv.tv_sec = __tv.tv_sec + 8 * 3600;
	localtime_r(&__tv.tv_sec, &__p);
}

/**
* @param   timeval& __tv, tm& __p, gint __buffSec
* @return  null
* @retval  void
* @note
**/
void ToolUtils::SysUsecTime(timeval& __tv, tm& __p, gint __buffSec) const
{
	TimezoneStr _tz;
	gettimeofday(&__tv, &_tz);
	__tv.tv_sec = __tv.tv_sec + __buffSec;
	localtime_r(&__tv.tv_sec, &__p);
}

/**
* @param   timeval __tv, tm& __p
* @return  null
* @retval  void
* @note
**/
void ToolUtils::ParseUsecTime(timeval __tv, tm& __p) const
{
	localtime_r(&__tv.tv_sec, &__p);
}

/**
* @param   void
* @return  glong
* @retval  TimeStamp
* @note
**/
glong ToolUtils::GetTimeStamp() const
{
	time_t _now;
	time(&_now);
	return (glong)_now;
}

/**
* @param   guchar* __bytes, gint __size
* @return  hex
* @retval  std::string
* @note
**/
std::string ToolUtils::ByteToHexStr(guchar* __bytes, guint __size) const
{
	gchar _hex[16] ={ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	std::string _str;
	for (guint _i = 0; _i < __size; _i++){
		const guchar _ch = __bytes[_i];
		_str.append(&_hex[(_ch & 0xF0) >> 4], 1);
		_str.append(&_hex[_ch & 0xF], 1);
	}
	return _str;
}

/**
* @param   gushort __bytes
* @return  hex
* @retval  std::string
* @note
**/
std::string ToolUtils::ByteToHexStr(gushort __bytes) const
{
	gchar _hex[16] ={ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	std::string _str;
	_str.append(&_hex[(__bytes & 0xF000) >> 12], 1);
	_str.append(&_hex[(__bytes & 0xF00) >> 8], 1);
	_str.append(&_hex[(__bytes & 0xF0) >> 4], 1);
	_str.append(&_hex[__bytes & 0xF], 1);
	return _str;
}

/**
* @param   const std::string& __hexStr,gchar* __output
* @return  true OR false
* @retval  gboolean
* @note
**/
gboolean ToolUtils::HexStrToByte(const std::string& __hexStr,gchar* __output) const
{
	const gchar* const _hex = "0123456789ABCDEF";
	size_t _len = __hexStr.length();
	gint _k = 0;
	if (_len & 1) {
		return false;
	}
	for (size_t _i = 0; _i < _len; _i += 2){
		gchar _a = __hexStr[_i];
		const gchar* _p = std::lower_bound(_hex, _hex + 16, _a);
		if (*_p != _a) {
			return false;
		}
		gchar _b = __hexStr[_i + 1];
		const gchar* _q = std::lower_bound(_hex, _hex + 16, _b);
		if (*_q != _b){
			return false;
		}
		__output[_k++] = ((_p - _hex) << 4) | (_q - _hex);
	}
	return true;
}

/**
* @param   gushort __bytes
* @return  hex
* @retval  std::string
* @note
**/
std::string ToolUtils::GuidHexStr() const
{
	TimezoneStr _tz;
	timeval _tv;
	tm _p;
	gettimeofday(&_tv, &_tz);
	_tv.tv_sec = _tv.tv_sec + 8 * 3600;
	localtime_r(&_tv.tv_sec, &_p);
	gchar _buffer[40];
	sprintf(_buffer, "%04x%02x%02x%02x%02x%02x%06lx%03x%03x%03x%03x", (1900 + _p.tm_year), (1 + _p.tm_mon), _p.tm_mday, _p.tm_hour, _p.tm_min, _p.tm_sec, _tv.tv_usec,(rand()%1000),(rand()%1000),(rand()%1000),(rand()%1000));
	return std::string(_buffer, 32);
}


ToolUtils::ToolUtils()
{
}

