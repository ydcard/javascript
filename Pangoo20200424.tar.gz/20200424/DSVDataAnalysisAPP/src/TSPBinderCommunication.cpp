/*
 * CarSttComm.cpp
 *
 *  Created on: 2018年3月16日
 *      Author: huangwenchao
 */

#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <thread>
#include <sys/prctl.h>
#include "stringbuffer.h"
#include "writer.h"
#include "document.h"
#include "node_type.h"
#include "TSPBinderCommunication.h"
#include "CANMessageManagement_GB.h"
#include "FileOP.h"
#include "ToolUtils.h"
#include <sys/time.h>
#include "DSVLog.h"

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

BinderContacts::~BinderContacts()
{
}

BinderContacts::BinderContacts(guint64 __appId)
{
	this->m_binderInterface = NULL;
	this->m_appId = __appId;
	GThreadFunc _threadFunc=[](gpointer __data)->gpointer{
		BinderContacts* _this=(BinderContacts*)__data;
		android::sp<android::ProcessState> _proc(android::ProcessState::self());
		android::sp<android::IServiceManager> _sm = android::defaultServiceManager();
		android::sp<android::IBinder> _binder;
		while(true) {
			_binder = _sm->getService(android::String16("com.desay.DSVTSPConnectSVC"));
			if(_binder != 0) {
				break;
			}
			sleep(2);
		}
		_this->m_binderInterface = android::interface_cast<IInterfaceBinderIPC>(_binder);//把binder强转为接口
		_this->m_binderInterface->setCallback(_this->m_appId,_this);//注册callback函数接口
		_this->CheckTSPConnected();
		_proc->setThreadPoolMaxThreadCount(30);
		_proc->startThreadPool();
		android::IPCThreadState::self()->joinThreadPool(true);
		return NULL;
	};
	g_thread_new("readthread", _threadFunc, (gpointer)this);
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

void BinderContacts::ASyncCall(gint __methodId, std::string __contentJsonStr)
{
	gboolean _iSentToSerivce = false;
	if(this->m_binderInterface != NULL) {
		android::sp<android::IServiceManager> _sm = android::defaultServiceManager();
		android::sp<android::IBinder> _binder = _sm->checkService(android::String16("com.desay.DSVTSPConnectSVC"));
		if(_binder != 0){
			this->m_binderInterface->ASyncCall(this->m_appId, __methodId ,__contentJsonStr);
			_iSentToSerivce=true;
		}
	}
	if(!_iSentToSerivce) {
		rapidjson::Document _document;
		_document.Parse(__contentJsonStr.c_str());
		if(_document.HasParseError()) {
			return;
		}
		rapidjson::Document::AllocatorType& _allocator= _document.GetAllocator();
		_document.AddMember("ResponseResult",false, _allocator);
		_document.AddMember("ResponseErrorCode", 11, _allocator);//TODO TELEMATICS_RESULT_BINDER_ERROR
		rapidjson::StringBuffer _resultJsonBuffer;
		rapidjson::Writer<rapidjson::StringBuffer> _writer(_resultJsonBuffer);
		_document.Accept(_writer);
		std::string _resultJsonStr = _resultJsonBuffer.GetString();
		this->OnASyncCallResult(_resultJsonStr);
	}
	return;
}

/**
* @param   gint __methodId,std::string __notifyJsonStr
* @return  null
* @retval  void
* @note
**/
void BinderContacts::NotifyCallBack(gint __methodId,std::string __notifyJsonStr)
{
	switch(__methodId) {
		case BinderContacts_Get_Echo: {
			this->OnRecvEchoMessage(__notifyJsonStr);
			break;
		}
		case BinderContacts_Get_Notify: {
			this->OnRecvNotify(__notifyJsonStr);
			break;
		}
		case BinderContacts_Get_AsyncCallResult: {
			this->OnASyncCallResult(__notifyJsonStr);
			break;
		}
		case BinderContacts_Get_PG: {
			this->OnPGtoTBOX(__notifyJsonStr);
			break;
		}
		default:
		break;
	}
}

/**
* @param   uint32_t __code,const android::Parcel& __data,android::Parcel* __reply,uint32_t __flags
* @return  android::status_t
* @retval  int
* @note
**/
android::status_t BinderContacts::BinderOnTransact(uint32_t __code,const android::Parcel& __data,android::Parcel* __reply,uint32_t __flags)
{
	switch (__code) {
		case android::IBinder::FIRST_CALL_TRANSACTION:{
			if (!__data.checkInterface(this)) {
				return android::PERMISSION_DENIED;
			}
			gint _methodId = __data.readInt32();
			const gchar* _notifyJsonStr = __data.readCString();
			this->NotifyCallBack(_methodId,_notifyJsonStr);
			return android::NO_ERROR;
		}
		break;
		default:
		return BBinder::onTransact(__code, __data, __reply, __flags);
	}
}

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------

void BinderContacts::CheckTSPConnected()
{
	if(this->m_binderInterface != NULL) {
		android::sp<android::IServiceManager> _sm = android::defaultServiceManager();
		android::sp<android::IBinder> _binder = _sm->checkService(android::String16("com.desay.DSVTSPConnectSVC"));
		if(_binder != 0){
			this->m_binderInterface->ASyncCall(this->m_appId, BinderContacts_Send_CheckTSPConnected ,"checkTSPConnected");
		}
	}
}

//*************************************************************************
//*************************************************************************
//*************************************************************************

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

BinderContactsWorker::~BinderContactsWorker()
{
}

/**
* @param   std::string __resultJsonStr
* @return  null
* @retval  void
* @note    PGtoTBOX
**/
//Pangoo
void BinderContactsWorker::OnPGtoTBOX(std::string __resultJsonStr)
{
	if(__resultJsonStr.length()>=10)
	{
		while(this->ReqNum>0){
			std::this_thread::yield();
		}
		this->setPGData(__resultJsonStr);
	    usleep(100000);
	}
	else{
		return ;
	}

}

/**
* @param   std::string __echoJsonStr
* @return  null
* @retval  void
* @note    TSP通知Message
**/
void BinderContactsWorker::OnRecvEchoMessage(std::string __echoJsonStr)
{
}

/**
* @param   std::string __notifyJsonStr
* @return  null
* @retval  void
* @note    TSP通知Notify
**/
void BinderContactsWorker::OnRecvNotify(std::string __notifyJsonStr)
{
	rapidjson::Document _document;
	_document.Parse(__notifyJsonStr.c_str());
	if(_document.HasParseError()) {
		return;
	}
	if(!_document.HasMember("NotifyType") || !_document["NotifyType"].IsString()) {
		return;
	}
	std::string _notifyType = _document["NotifyType"].GetString();
	if (_notifyType == "TSPConnectStatus"){
		if(!_document.HasMember("TSPConnectStatus") || !_document["TSPConnectStatus"].IsString()) {
			return;
		}
		std::string _TSPConnectStatus = _document["TSPConnectStatus"].GetString();
		if (_TSPConnectStatus == "online") {
			YDLOG(YD_INFO, "OnRecvNotify", "Tsp: online response\n");
			this->m_connectedIsRun=true;
		}
		else {
			YDLOG(YD_INFO, "OnRecvNotify", "Tsp: offline response\n");
			this->m_connectedIsRun=false;
		}
	}
}

/**
* @param   std::string __resultJsonStr
* @return  null
* @retval  void
* @note    TSP解析Result
**/
void BinderContactsWorker::OnASyncCallResult(std::string __resultJsonStr)
{
	rapidjson::Document _document;
	_document.Parse(__resultJsonStr.c_str());
	if(_document.HasParseError()) {
		return;
	}
	if(!_document.HasMember("ResquestType") || !_document["ResquestType"].IsString()) {
		return;
	}
	std::string _resquestType = _document["ResquestType"].GetString();
	if(_resquestType == "DataUpload"){
		if(!_document.HasMember("ResponseErrorCode") || !_document["ResponseErrorCode"].IsInt()){
			return;
		}
		gint _responseErrorCode = _document["ResponseErrorCode"].GetInt();
		if(!_document.HasMember("RecordBufferHexStr") || !_document["RecordBufferHexStr"].IsString()) {
			return;
		}
		std::string _recordBufferHexStr = _document["RecordBufferHexStr"].GetString();
		FileOP* _fileOP=FileOP::GetInstance();
		if (_responseErrorCode != 0) {
			YDLOG(YD_ERR, "DSVDataAnalysisApp", "xchao_error:sendFailed\n");
			_fileOP->DelOrOpenReSentData(_recordBufferHexStr.substr(0, 12), 0);//更新is_finish=0,下次补发
		}
	}
}

//Pangoo
void BinderContactsWorker::setPGData(std::string __resultJsonStr)
{
	this->InitPGControl();
	this->SerialNum.clear();
	this->GetSerialNum.clear();
	this->SetPGTime();
	ToolUtils* _toolUtils=ToolUtils::GetInstance();
	gchar *_CPGtoTBOX = new gchar[50];
	gboolean _BEStoTBOX = _toolUtils->HexStrToByte(__resultJsonStr,_CPGtoTBOX);
	YDLOG(YD_INFO, "TSPBinderCommunication", "Recieve Server Data\n");
	int yd;
	for(yd = 0;yd<26;yd++){
		printf("data is %#X\n",_CPGtoTBOX[yd]);
	}
	if(_BEStoTBOX)
	{
		if(_CPGtoTBOX[6] < 253)
		{
//			this->ReqNum = _CPGtoTBOX[6]+1;//0823:因为氛围灯是没有回应消息的，所以这里不能完全依照功能总数来进行
			this->ReqNum++;
			int _i=0;
			int _num = 7;
			for(;_i<_CPGtoTBOX[6];_i++)
			{
				if(_CPGtoTBOX[_num] == 0x01){
					this->ReqNum++;
					this->m_CmdData.PG_CmdLock = _CPGtoTBOX[_num+2];
					printf("TSPBinderCommunication, CmdLock is %#X\n", this->m_CmdData.PG_CmdLock);
					this->SerialNum.push_back(0x01);
					_num = _num+3;
				}
				else if(_CPGtoTBOX[_num] == 0x02){
					this->ReqNum++;
					this->m_CmdData.PG_CmdFindCar = _CPGtoTBOX[_num+2];
					printf("TSPBinderCommunication, CmdFindCar is %#X\n", this->m_CmdData.PG_CmdFindCar);
					this->SerialNum.push_back(0x02);
					_num = _num+3;
				}
				else if(_CPGtoTBOX[_num] == 0x03){
					this->ReqNum++;
					this->m_CmdData.PG_CmdAirCon = _CPGtoTBOX[_num+2];
					printf("TSPBinderCommunication, CmdAirCon is %#X\n", this->m_CmdData.PG_CmdAirCon);
					this->SerialNum.push_back(0x03);
					_num = _num+3;
				}
				else if(_CPGtoTBOX[_num] == 0x04){
					// 目前没有这一条控制消息
					// this->ReqNum++;
					this->m_CmdData.PG_CmdLight[0] = _CPGtoTBOX[_num+2];
					this->m_CmdData.PG_CmdLight[1] = _CPGtoTBOX[_num+3];
					this->m_CmdData.PG_CmdLight[2] = _CPGtoTBOX[_num+4];
					this->m_CmdData.PG_CmdLight[3] = _CPGtoTBOX[_num+5];
					printf("TSPBinderCommunication, CmdLight[0] is %#X\n", this->m_CmdData.PG_CmdLight[0]);
					printf("TSPBinderCommunication, CmdLight[1] is %#X\n", this->m_CmdData.PG_CmdLight[1]);
					printf("TSPBinderCommunication, CmdLight[2] is %#X\n", this->m_CmdData.PG_CmdLight[2]);
					printf("TSPBinderCommunication, CmdLight[3] is %#X\n", this->m_CmdData.PG_CmdLight[3]);
					this->SerialNum.push_back(0x04);
					_num = _num+6;
				}
			}
			this->ReqFlag = 1;
		}
		delete []_CPGtoTBOX;
		_CPGtoTBOX = NULL;
		return;
	}
	else
	{
		delete []_CPGtoTBOX;
		_CPGtoTBOX = NULL;
		return;
	}
}

//Pangoo
PG_CmdData_t BinderContactsWorker::GetPGData()const
{
	return this->m_CmdData;
}

//Pangoo
gint BinderContactsWorker::GetPGFlag()const
{
	return this->ReqFlag;
}

//Pangoo
gint BinderContactsWorker::GetPGNum()const
{
	return this->ReqNum;
}

//Pangoo
gulong BinderContactsWorker::GetPGTime()const
{
	return this->PG_time;
}

//Pangoo
void BinderContactsWorker::SetPGTime()
{
	timeval timeVal;
	gettimeofday(&timeVal,NULL);
	time_t timep;
    time( &timep );
    timep = timep + 8*3600;
    struct tm *pTM = gmtime( &timep );
    this->PG_time = pTM->tm_hour * 3600 * 1000 + pTM->tm_min * 60 * 1000 + pTM->tm_sec * 1000 + timeVal.tv_usec/1000;
	return;
}

//Pangoo
gulong BinderContactsWorker::waitPGTime()
{
	timeval timeVal;
	gettimeofday(&timeVal,NULL);
	time_t timep;
    time( &timep );
    timep = timep + 8*3600;
    struct tm *pTM = gmtime( &timep );
    gulong newTime = pTM->tm_hour * 3600 * 1000 + pTM->tm_min * 60 * 1000 + pTM->tm_sec * 1000 + timeVal.tv_usec/1000;
	this->PG_waitTime = newTime - this->PG_time;
	return this->PG_waitTime;
}

//Pangoo
void BinderContactsWorker::InitPGControl(){
	this->PG_waitTime = 0;
	this->PG_time = 0;
	this->ReqNum = 0;
}

//Pangoo
void BinderContactsWorker::SetPGFlag()
{
	this->ReqFlag = 0;
	return;
}

//Pangoo
gboolean BinderContactsWorker::CheckSerial(guchar number)
{
	for(guint _i=0;_i<this->SerialNum.size();_i++) {
		if(SerialNum[_i] == number) {
			return true;
		}
	}
	return false;
}


//Pangoo
void BinderContactsWorker::SetPGNum()
{
	this->ReqNum--;
	return;
}

//Pangoo
void BinderContactsWorker::SetSerialNum(guchar __number)
{
	this->GetSerialNum.push_back(__number);
	return;
}


//Pangoo
std::vector<guchar> BinderContactsWorker::GetSerial(){
	return this->SerialNum;
}

std::vector<guchar> BinderContactsWorker::GetSerialNumber(){
	return GetSerialNum;//Pangoo
}

/**
* @param   std::string __notifyJsonStr
* @return  class
* @retval  BinderContactsWorker*
* @note    单例
**/
BinderContactsWorker* BinderContactsWorker::GetInstance() {
	if(BinderContactsWorker::m_instance==NULL) {
		BinderContactsWorker::m_instance = new BinderContactsWorker();
	}
	return BinderContactsWorker::m_instance;
}

/**
* @param   void
* @return  true or false
* @retval  gboolean
* @note
**/
gboolean BinderContactsWorker::IsConnectedIsRun() const
{
	return this->m_connectedIsRun;
}

/**
* @param   void
* @return  false or true
* @retval  gboolean
* @note    上传数据
**/
gboolean BinderContactsWorker::DataUpload(std::string __data,std::string __dataType, gboolean __realTime)
{
	if (__data.length() == 0) {
		return false;
	}
	if (!this->m_connectedIsRun) {
		YDLOG(YD_WARN, "DataUpload", "disconnected\n");
		return false;
	}
	if(__dataType == "DataUpload") {
		rapidjson::StringBuffer _dateUploadDateUnitJsonStr;
		rapidjson::Writer<rapidjson::StringBuffer> _writer(_dateUploadDateUnitJsonStr);
		_writer.StartObject();
		_writer.Key("ResquestType");
		_writer.String("DataUpload");

		_writer.Key("RecordBufferHexStr");
		_writer.String(__data.c_str());
		_writer.Key("RecordBufferSize");
		_writer.Int(__data.size());

		_writer.Key("RecordRealTime");
		_writer.Bool(__realTime);
		_writer.EndObject();
		std::string _jsonString = _dateUploadDateUnitJsonStr.GetString();
		this->ASyncCall(BinderContacts_Send_Common, _jsonString);
		YDLOG(YD_INFO, "DataUpload", "PeriodDataUpload\n");
		return true;
	}
	else if (__dataType == "HeartBeat") {
		rapidjson::StringBuffer _dateUploadDateUnitJsonStr;
		rapidjson::Writer<rapidjson::StringBuffer> _writer(_dateUploadDateUnitJsonStr);
		_writer.StartObject();
		_writer.Key("ResquestType");
//		_writer.String("RechargeableEnergyStorageSubsystem");
		_writer.String("HeartBeat");
		_writer.EndObject();
		std::string _jsonString = _dateUploadDateUnitJsonStr.GetString();
		this->ASyncCall(BinderContacts_Send_Common, _jsonString);
		YDLOG(YD_INFO, "DataUpload", "HeartBeat\n");
		return true;
	}
	else if(__dataType == "PangooResponse"){
		rapidjson::StringBuffer _dateUploadDateUnitJsonStr;
		rapidjson::Writer<rapidjson::StringBuffer> _writer(_dateUploadDateUnitJsonStr);
		_writer.StartObject();
		_writer.Key("ResquestType");
		_writer.String("PangooResponse");
		_writer.Key("RecordBufferHexStr");
		_writer.String(__data.c_str());
		_writer.Key("RecordBufferSize");
		_writer.Int(__data.size());
		_writer.EndObject();
		std::string _jsonString = _dateUploadDateUnitJsonStr.GetString();
		this->ASyncCall(BinderContacts_Send_Common, _jsonString);
		YDLOG(YD_INFO, "DataUpload", "PangooResponse\n");
		return true;
	}
	else if(__dataType == "PangooWarnData"){
		rapidjson::StringBuffer _dateUploadDateUnitJsonStr;
		rapidjson::Writer<rapidjson::StringBuffer> _writer(_dateUploadDateUnitJsonStr);
		_writer.StartObject();
		_writer.Key("ResquestType");
		_writer.String("PangooWarnData");
		_writer.Key("RecordBufferHexStr");
		_writer.String(__data.c_str());
		_writer.Key("RecordBufferSize");
		_writer.Int(__data.size());
		_writer.EndObject();
		std::string _jsonString = _dateUploadDateUnitJsonStr.GetString();
		this->ASyncCall(BinderContacts_Send_Common, _jsonString);
		YDLOG(YD_INFO, "DataUpload", "PangooWarnData\n");
		return true;
	}
	return false;
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
BinderContactsWorker* BinderContactsWorker::m_instance = NULL;

BinderContactsWorker::BinderContactsWorker():BinderContacts(NODE_APP_DATA_UPLOAD)
{
//	this->m_connectedIsRun=true;
	this->m_connectedIsRun=false;
	this->m_CmdData = {0};
	this->ReqFlag = 0;
	this->ReqNum = 0;
	this->PG_waitTime = 0;
	this->PG_time = 0;
}
