/*
 * DataStitching.cpp
 *
 *  Created on: 2018年3月6日
 *      Author: huangwenchao
 */

#include "DataStitching.h"
#include "ToolUtils.h"

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

DataStitching::DataStitching()
{
	this->m_newThreadCount=0;
	this->m_sendController=0;
	pthread_mutex_init(&this->m_mutex,NULL);
}

DataStitching::~DataStitching()
{
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

/**
* @param   void
* @return  null
* @retval  void
* @note
**/
void DataStitching::LogSysUsecTime(std::string __message) const
{
	ToolUtils* _toolUtils=ToolUtils::GetInstance();
	timeval _tv;
	tm _p;
	_toolUtils->SysUsecTime(_tv, _p);
}

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
