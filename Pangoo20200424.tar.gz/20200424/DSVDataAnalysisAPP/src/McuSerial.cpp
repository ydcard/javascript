#include <time.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include "document.h"
#include "McuSerial.h"
#include "ToolUtils.h"
#include "Common.h"
#include "CANMessageManagement_GB.h"
#include <vector>
#include <thread>
#include "TSPBinderCommunication.h"
#include "DSVLog.h"
#include "AnalysisCanData_Pangoo.h"

#define MAX_SEND_LENGHT 512
#define MCUSERIAL_INIT 0
#define MCUSERIAL_WORKING 1
#define MCUSERIAL_SLEEPING 2


McuSerial::McuSerial()
{
	this->m_pCommunicator=nullptr;
}

McuSerial::~McuSerial()
{
}

bool McuSerial::Init() {
	this->m_pCommunicator = McuComManager::init("DSVDataAnalysisAPP");
	if (this->m_pCommunicator == NULL) {
		YDLOG(YD_ERR, "DSVDataAnalysisApp","xchao_error:Read Worker Init Error\n");
		return false;
	}
	this->m_pCommunicator->registerID(MCU_COM_GET4);//Pangoo
	std::thread startMcuReadThread(&McuSerial::LoopTaskThreadRead, this);
	startMcuReadThread.detach();
	std::thread startMcuWriteThread(&McuSerial::LoopTaskThreadWrite, this);
	startMcuWriteThread.detach();

	return true;
}

// read msg from mcu
void McuSerial::LoopTaskThreadRead()
{
	YDLOG(YD_INFO, "McuSerial", "ReadThread Start!!!\n");
	char _len;
	uint8_t _buff[MAX_SEND_LENGHT] = {0};
	m_parmCommunicate.finish=false;
	AnalysisCanData* _analysis=AnalysisCanDataPangoo::GetInstance();
	while(true) {
		usleep(1000000); // only use for test env , change to 1000 when in real env
		if(!m_parmCommunicate.finish) {
//				m_parmCommunicate.value.Cmd_flag = 0;
//				m_parmCommunicate.value.Cmd_number = 4;
//				m_parmCommunicate.value.Cmd_param[0] = 0x01;
//				m_parmCommunicate.value.Cmd_param[1] = 0xe8;
//				m_parmCommunicate.value.Cmd_param[2] = 0;
//				m_parmCommunicate.value.Cmd_param[3] = 0;
//				m_parmCommunicate.value.Cmd_param[4] = 0;
//				m_parmCommunicate.value.Cmd_param[5] = 0;
//				m_parmCommunicate.value.Cmd_param[6] = 0;
//				m_parmCommunicate.value.Cmd_size = 2;
//				m_parmCommunicate.value.Cmd_type = 1;
//				m_parmCommunicate.value.Component_id = 24;
			//YinDi:添加上面的参数用于使得ready()为true，与MCU调试时讲上面注释，将下面一行解注释
			m_pCommunicator->readMsg(m_parmCommunicate.value);
//				printf("Id is %#X\n",m_parmCommunicate.value.Component_id);
//				printf("Size is %#X\n",m_parmCommunicate.value.Cmd_size);
//				printf("Number is %#X\n",m_parmCommunicate.value.Cmd_number);
//				printf("Data[0] is %#X\n",m_parmCommunicate.value.Cmd_param[0]);
//				printf("Data[1] is %#X\n",m_parmCommunicate.value.Cmd_param[1]);
//				printf("Data[2] is %#X\n",m_parmCommunicate.value.Cmd_param[2]);
//				printf("Data[3] is %#X\n",m_parmCommunicate.value.Cmd_param[3]);
//				printf("Data[4] is %#X\n",m_parmCommunicate.value.Cmd_param[4]);
			char __strId[128],__strSize[128],__strNumber[128],__strData0[128],__strData1[128],__strData2[128],__strData3[128],__strData4[128];
//				sprintf(__strId,"Id is %#X\n",m_parmCommunicate.value.Component_id);
//				sprintf(__strSize,"Size is %#X\n",m_parmCommunicate.value.Cmd_size);
//				sprintf(__strNumber,"Number is %#X\n",m_parmCommunicate.value.Cmd_number);
//				sprintf(__strData0,"Data[0] is %#X\n",m_parmCommunicate.value.Cmd_param[0]);
//				sprintf(__strData1,"Data[1] is %#X\n",m_parmCommunicate.value.Cmd_param[1]);
//				sprintf(__strData2,"Data[2] is %#X\n",m_parmCommunicate.value.Cmd_param[2]);
//				sprintf(__strData3,"Data[3] is %#X\n",m_parmCommunicate.value.Cmd_param[3]);
//				sprintf(__strData4,"Data[4] is %#X\n",m_parmCommunicate.value.Cmd_param[4]);
//				YDLOG(YD_DEBUG, "McuSerial", __strId);
//				YDLOG(YD_DEBUG, "McuSerial", __strSize);
//				YDLOG(YD_DEBUG, "McuSerial", __strNumber);
//				YDLOG(YD_DEBUG, "McuSerial", __strData0);
//				YDLOG(YD_DEBUG, "McuSerial", __strData1);
//				YDLOG(YD_DEBUG, "McuSerial", __strData2);
//				YDLOG(YD_DEBUG, "McuSerial", __strData3);
//				YDLOG(YD_DEBUG, "McuSerial", __strData4);
			m_parmCommunicate.finish=true;
		}
		{
			_len = m_parmCommunicate.value.Cmd_size - 1;
			memset(_buff, 0, MAX_SEND_LENGHT);
			memcpy(_buff, m_parmCommunicate.value.Cmd_param, _len);
			bool PG_analysisFinish=false;
			if (m_parmCommunicate.value.Component_id == MCU_COM_GET4) {
				YDLOG(YD_DEBUG, "McuSerial", "Get message from mcu\n");
				_analysis->AnalysisMCU(m_parmCommunicate.value.Cmd_type,m_parmCommunicate.value.Cmd_number,_buff,_len);
				PG_analysisFinish=true;
			}
			if(PG_analysisFinish){
				YDLOG(YD_DEBUG, "McuSerial", "change to Pangoo Data\n");
				_analysis->AnalysisToPlat(m_parmCommunicate.value.Cmd_number);//转化为盘古数据
			}
			m_parmCommunicate.finish=false;
		}
	}
}

// send data to mcu thread
void McuSerial::LoopTaskThreadWrite()
{
	YDLOG(YD_INFO, "McuSerial", "WriteThread Start!!!\n");
    PG_CmdData_t buff;
	BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();

    while (true) {
		if(_binderContactsWorker->GetPGFlag())
		{
			buff=_binderContactsWorker->GetPGData();
			char __strFlag[128];
			sprintf(__strFlag,"Send To mcu %d\n",_binderContactsWorker->GetPGFlag());
			YDLOG(YD_INFO, "McuSerial", __strFlag);
			SendDataToMCU(buff);
			_binderContactsWorker->SetPGFlag();
		}
		usleep(1000);
    }
}

// send data to mcu function
void McuSerial::SendDataToMCU(PG_CmdData_t __buff)
{
	CommunicateData sentConfData;
	sentConfData.Cmd_type = 5;
	sentConfData.Cmd_flag = 0;
	sentConfData.Component_id = 24;
	BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();

	if(_binderContactsWorker->CheckSerial(0x01))
	{
		sentConfData.Cmd_size = 2;
		sentConfData.Cmd_number = 1;
		sentConfData.Cmd_param[0] = __buff.PG_CmdLock;
		this->m_pCommunicator->sendMsg(&sentConfData);
	}

	if(_binderContactsWorker->CheckSerial(0x02))
	{
		sentConfData.Cmd_size = 2;
		sentConfData.Cmd_number = 2;
		sentConfData.Cmd_param[0] = __buff.PG_CmdFindCar;
		this->m_pCommunicator->sendMsg(&sentConfData);
	}

	if(_binderContactsWorker->CheckSerial(0x03))
	{
		sentConfData.Cmd_size = 2;
		sentConfData.Cmd_number = 3;
		sentConfData.Cmd_param[0] = __buff.PG_CmdAirCon;
		this->m_pCommunicator->sendMsg(&sentConfData);
	}

	if(_binderContactsWorker->CheckSerial(0x04))
	{
		sentConfData.Cmd_size = 5;
		sentConfData.Cmd_number = 4;
		sentConfData.Cmd_param[0] = __buff.PG_CmdLight[0];
		sentConfData.Cmd_param[1] = __buff.PG_CmdLight[1];
		sentConfData.Cmd_param[2] = __buff.PG_CmdLight[2];
		sentConfData.Cmd_param[3] = __buff.PG_CmdLight[3];
		this->m_pCommunicator->sendMsg(&sentConfData);
	}
}
