#include <sstream>
#include <iostream>
#include "CANMessageManagement_GB.h"
#include "AnalysisCanData.h"
#include "ToolUtils.h"
#include "TSPBinderCommunication.h"
#include "DSVLog.h"
#include <stdio.h>

std::ofstream ydfs;

#define YDLog(num,name,tag,variable)\
{\
	if(tag == 'd'){\
		char yd_buffer[100];\
    	sprintf(yd_buffer,"：%d\n",variable);\
    	if(ydfs.is_open() == false){\
    		ydfs.open("/app/bin/ydalllog.txt",fstream::app);\
		}\
		ydfs << std::left << setw(25+num) << name << yd_buffer;\
	}\
    else if(tag == 'x'){\
		char yd_buffer[15];\
    	sprintf(yd_buffer,"：%#X\n",variable);\
    	if(ydfs.is_open() == false){\
    		ydfs.open("/app/bin/ydalllog.txt",fstream::app);\
		}\
		ydfs << std::left << setw(25+num) << name << yd_buffer;\
    }\
}\


//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

CANMessageManagement_GB::~CANMessageManagement_GB()
{
}

/**
* @param   void
* @return  class
* @retval  CANMessageManagement_GB*
* @note    单例
**/
CANMessageManagement_GB* CANMessageManagement_GB::GetInstance() {
	if (CANMessageManagement_GB::m_instance == NULL) {
		CANMessageManagement_GB::m_instance = new CANMessageManagement_GB();
	}
	return CANMessageManagement_GB::m_instance;
}

/**
* @param   uint8_t __vehicleCondition
* @return  void
* @retval  null
* @note    车辆状态
**/
void CANMessageManagement_GB::SetVehicleCondition(uint8_t __vehicleCondition)
{
	this->m_PG_CarStat = __vehicleCondition;
}

/**
* @param   uint8_t __vehicleCondition
* @return  void
* @retval  null
* @note    充电状态
**/
void CANMessageManagement_GB::SetChargingState(uint8_t __chargingState)
{
}

/**
* @param   uint8_t __runingMode
* @return  void
* @retval  null
* @note    运行模式
**/
void CANMessageManagement_GB::SetRuningMode(uint8_t __runingMode)
{
}

/**
* @param   uint16_t __vehicleSpeed
* @return  void
* @retval  null
* @note    车速
**/
void CANMessageManagement_GB::SetVehicleSpeed(uint16_t __vehicleSpeed)
{
	this->m_PG_Speed = __vehicleSpeed;
}

/**
* @param   uint32_t __accumulatedMileage
* @return  void
* @retval  null
* @note    里程
**/
void CANMessageManagement_GB::SetAccumulatedMileage(uint32_t __accumulatedMileage)
{
	this->m_PG_TotalMile = __accumulatedMileage;
}

/**
 * @param   uint16_t __totalVoltage
 * @return  void
 * @retval  null
 * @note    总电压
 **/
void CANMessageManagement_GB::SetTotalVoltage(uint16_t __totalVoltage)
{
}

/**
 * @param   uint16_t __totalCurrent
 * @return  void
 * @retval  null
 * @note    总电流
 **/
void CANMessageManagement_GB::SetTotalCurrent(uint16_t __totalCurrent)
{
}

/**
 * @param   uint8_t __SOCState
 * @return  void
 * @retval  null
 * @note    SOC状态
 **/
void CANMessageManagement_GB::SetSOCState(uint8_t __SOCState)
{
}

/**
 * @param   uint8_t __DCDCState
 * @return  void
 * @retval  null
 * @note    DC-DC状态
 **/
void CANMessageManagement_GB::SetDCDCState(uint8_t __DCDCState)
{
}

/**
 * @param   uint8_t __accelerationPedal
 * @return  void
 * @retval  null
 * @note    加速踏板状态
 **/
void CANMessageManagement_GB::SetAccelerationPedal(uint8_t __accelerationPedal)
{
	this->m_PG_AccPedal = __accelerationPedal;
}

/**
 * @param   uint8_t __brakePedalState
 * @return  void
 * @retval  null
 * @note    制动踏板状态
 **/
void CANMessageManagement_GB::SetBrakePedalState(uint8_t __brakePedalState)
{
	this->m_PG_BrakePedal = __brakePedalState;
}

/**
 * @param   uint8_t __drivelineState
 * @return  void
 * @retval  null
 * @note    齿轮状态 档位状态
 **/
void CANMessageManagement_GB::SetDrivelineState(uint8_t __drivelineState)
{
	this->m_PG_Gear = __drivelineState;
}

/**
 * @param   uint16_t __insulationResistance
 * @return  void
 * @retval  null
 * @note    绝缘电阻
 **/
void CANMessageManagement_GB::SetInsulationResistance(uint16_t __insulationResistance)
{
}

/**
 * @param   uint16_t __numberOfDriveMotorNumber
 * @return  void
 * @retval  null
 * @note    驱动电机个数
 **/
void CANMessageManagement_GB::SetNumberOfDriveMotorNumber(uint16_t __numberOfDriveMotorNumber)
{
}

/**
 * @param   uint16_t __fuelCellVoltage
 * @return  void
 * @retval  null
 * @note    燃料电池电压
 **/
void CANMessageManagement_GB::SetFuelCellVoltage(uint16_t __fuelCellVoltage)
{
}

/**
 * @param   uint16_t __fuelCellCurrent
 * @return  void
 * @retval  null
 * @note    燃料电池电流
 **/
void CANMessageManagement_GB::SetFuelCellCurrent(uint16_t __fuelCellCurrent)
{
}

/**
 * @param   uint16_t __fuelConsumptionRate
 * @return  void
 * @retval  null
 * @note    燃料消耗率
 **/
void CANMessageManagement_GB::SetFuelConsumptionRate(uint16_t __fuelConsumptionRate)
{
}

/**
 * @param   uint16_t __totalNumberOfFuelCellTemperatureProbes
 * @return  void
 * @retval  null
 * @note    燃料电池温度探针总数
 **/
void CANMessageManagement_GB::SetTotalNumberOfFuelCellTemperatureProbes(uint16_t __totalNumberOfFuelCellTemperatureProbes)
{
}

/**
 * @param   uint8_t __probeTemperatureValue
 * @return  void
 * @retval  null
 * @note    探针温度值
 **/
void CANMessageManagement_GB::SetProbeTemperatureValue(uint8_t __probeTemperatureValue)
{
}

/**
 * @param   uint16_t __theHighestTemperatureInAHydrogenSystem
 * @return  void
 * @retval  null
 * @note    氢系统中最高温度
 **/
void CANMessageManagement_GB::SetTheHighestTemperatureInAHydrogenSystem(uint16_t __theHighestTemperatureInAHydrogenSystem)
{
}

/**
 * @param   uint8_t __theHighestTemperatureProbeCodeInTheHydrogenSystem
 * @return  void
 * @retval  null
 * @note    氢系统中最高温度探针代号
 **/
void CANMessageManagement_GB::SetTheHighestTemperatureProbeCodeInTheHydrogenSystem(uint8_t __theHighestTemperatureProbeCodeInTheHydrogenSystem)
{
}

/**
 * @param   uint16_t __theHighestConcentrationOfHydrogen
 * @return  void
 * @retval  null
 * @note    氢气最高浓度
 **/
void CANMessageManagement_GB::SetTheHighestConcentrationOfHydrogen(uint16_t __theHighestConcentrationOfHydrogen)
{
}

/**
 * @param   uint8_t __hydrogenMaximumConcentrationSensorCode
 * @return  void
 * @retval  null
 * @note    氢气最高浓度传感器代号
 **/
void CANMessageManagement_GB::SetHydrogenMaximumConcentrationSensorCode(uint8_t __hydrogenMaximumConcentrationSensorCode)
{
}

/**
 * @param   uint16_t __hydrogenMaximumPressure
 * @return  void
 * @retval  null
 * @note    氢气最高压力
 **/
void CANMessageManagement_GB::SetHydrogenMaximumPressure(uint16_t __hydrogenMaximumPressure)
{
}

/**
 * @param   uint8_t __hydrogenMaximumPressureSensorCode
 * @return  void
 * @retval  null
 * @note    氢气最高压力传感器代号
 **/
void CANMessageManagement_GB::SetHydrogenMaximumPressureSensorCode(uint8_t __hydrogenMaximumPressureSensorCode)
{
}

/**
 * @param   uint8_t __highVoltageDCDCStatus
 * @return  void
 * @retval  null
 * @note    高压DC/DC状态
 **/
void CANMessageManagement_GB::SetHighVoltageDCDCStatus(uint8_t __highVoltageDCDCStatus)
{
}

/**
 * @param   uint8_t __engineState
 * @return  void
 * @retval  null
 * @note    发动机状态
 **/
void CANMessageManagement_GB::SetEngineState(uint8_t __engineState)
{
	this->m_PG_EngineStat = __engineState;
}

/**
 * @param   uint16_t __crankshaftSpeed
 * @return  void
 * @retval  null
 * @note    曲轴转速
 **/
void CANMessageManagement_GB::SetCrankshaftSpeed(uint16_t __crankshaftSpeed)
{
	this->m_PG_QuZhou = __crankshaftSpeed;
}

/**
 * @param   uint8_t __validPosition
 * @return  void
 * @retval  null
 * @note    定位状态
 **/
void CANMessageManagement_GB::SetValidPosition(uint8_t __validPosition)
{
	this->m_PG_ValidPosition = __validPosition;
}

/**
 * @param   uint32_t __longitude
 * @return  void
 * @retval  null
 * @note    经度
 **/
void CANMessageManagement_GB::SetLongitude(uint32_t __longitude)
{
	this->m_PG_Longitude = __longitude;
}

/**
 * @param   uint32_t __latitude
 * @return  void
 * @retval  null
 * @note    纬度
 **/
void CANMessageManagement_GB::SetLatitude(uint32_t __latitude)
{
	this->m_PG_Latitude = __latitude;
}

/**
 * @param   uint8_t __highestVoltageBatterySubsystemNumber
 * @return  void
 * @retval  null
 * @note    最高电压电池子系列号
 **/
void CANMessageManagement_GB::SetHighestVoltageBatterySubsystemNumber(uint8_t __highestVoltageBatterySubsystemNumber)
{
}

/**
 * @param   uint8_t __highestVoltageBatteryCellCode
 * @return  void
 * @retval  null
 * @note    最高电压电池单元代码
 **/
void CANMessageManagement_GB::SetHighestVoltageBatteryCellCode(uint8_t __highestVoltageBatteryCellCode)
{
}

/**
 * @param   uint16_t __highestcellvoltage
 * @return  void
 * @retval  null
 * @note    电池单体电压最高值
 **/
void CANMessageManagement_GB::SetHighestcellvoltage(uint16_t __highestcellvoltage)
{
}

/**
 * @param   uint8_t __lowestVoltageBatterySubsystemNumber
 * @return  void
 * @retval  null
 * @note    最低电压电池子系统号
 **/
void CANMessageManagement_GB::SetLowestVoltageBatterySubsystemNumber(uint8_t __lowestVoltageBatterySubsystemNumber)
{
}

/**
 * @param   uint8_t __lowestVoltageBatteryCellCode
 * @return  void
 * @retval  null
 * @note    最低电压电池单体代号
 **/
void CANMessageManagement_GB::SetLowestVoltageBatteryCellCode(uint8_t __lowestVoltageBatteryCellCode)
{
}

/**
 * @param   uint16_t __lowestCellVoltage
 * @return  void
 * @retval  null
 * @note    电池单体电压最低值
 **/
void CANMessageManagement_GB::SetLowestCellVoltage(uint16_t __lowestCellVoltage)
{
}

/**
 * @param   uint8_t __highestTemperatureSubsystemNumber
 * @return  void
 * @retval  null
 * @note    最高温度子系统号
 **/
void CANMessageManagement_GB::SetHighestTemperatureSubsystemNumber(uint8_t __highestTemperatureSubsystemNumber)
{
}

/**
 * @param   uint8_t __highestTemperatureProbeNumber
 * @return  void
 * @retval  null
 * @note    最高温度探针单体代号
 **/
void CANMessageManagement_GB::SetHighestTemperatureProbeNumber(uint8_t __highestTemperatureProbeNumber)
{
}

/**
 * @param   uint8_t __highestTemperatureValue
 * @return  void
 * @retval  null
 * @note    最高温度值
 **/
void CANMessageManagement_GB::SetHighestTemperatureValue(uint8_t __highestTemperatureValue)
{
}

/**
 * @param   uint8_t __lowestTemperatureSubsystemNumber
 * @return  void
 * @retval  null
 * @note    最低温度子系统号
 **/
void CANMessageManagement_GB::SetLowestTemperatureSubsystemNumber(uint8_t __lowestTemperatureSubsystemNumber)
{
}

/**
 * @param   uint8_t __lowestTemperatureProbeSerialNumber
 * @return  void
 * @retval  null
 * @note    最低温度探针子系统代号
 **/
void CANMessageManagement_GB::SetLowestTemperatureProbeSerialNumber(uint8_t __lowestTemperatureProbeSerialNumber)
{
}

/**
 * @param   uint8_t __lowestTemperatureValue
 * @return  void
 * @retval  null
 * @note    最低温度值
 **/
void CANMessageManagement_GB::SetLowestTemperatureValue(uint8_t __lowestTemperatureValue)
{
}

/**
 * @param   uint8_t __rechargeableEnergyStorageDeviceTemperatureSum
 * @return  void
 * @retval  null
 * @note    可充电储能子系统个数
 **/
void CANMessageManagement_GB::SetRechargeableEnergyStorageDeviceTemperatureSum(uint8_t __rechargeableEnergyStorageDeviceTemperatureSum)
{
}

/**
 * @param   uint8_t __rechargeableEnergyStorageDeviceVolSum
 * @return  void
 * @retval  null
 * @note    可充电储能子系统个数
 **/
void CANMessageManagement_GB::SetRechargeableEnergyStorageDeviceVolSum(uint8_t __rechargeableEnergyStorageDeviceVolSum)
{
}

/**
 * @param	uint8_t __windowMode
 * @return  void
 * @retval  null
 * @note	车窗状态
 **/
void CANMessageManagement_GB::SetWindowMode(uint8_t __windowMode)
{
	this->m_PG_WindowMode = __windowMode;
}

/**
 * @param   uint8_t __lockerMode
 * @return  void
 * @retval  null
 * @note    门锁状态
 **/
void CANMessageManagement_GB::SetLockerMode(uint8_t __lockerMode)
{
	this->m_PG_DoorLockMode = __lockerMode;
}

/**
 * @param	uint32_t __carLightState
 * @return  void
 * @retval  null
 * @note	车灯状态
 **/
void CANMessageManagement_GB::SetCarLightState(uint32_t __carLightState)
{
	this->m_PG_CarLight = __carLightState;
}

/**
 * @param	uint8_t __ACPower
 * @return  void
 * @retval  null
 * @note	空调风速
 **/
void CANMessageManagement_GB::SetACPower(uint8_t __ACPower)
{
}

/**
 * @param	uint8_t __ACTemperature
 * @return  void
 * @retval  null
 * @note	空调温度
 **/
void CANMessageManagement_GB::SetACTemperature(uint8_t __ACTemperature)
{
}

/**
 * @param	uint8_t __ACWindType
 * @return  void
 * @retval  null
 * @note	空调吹风模式
 **/
void CANMessageManagement_GB::SetACWindType(uint8_t __ACWindType)
{
}

/**
 * @param	uint8_t __SetACType
 * @return  void
 * @retval  null
 * @note	空调模式
 **/
void CANMessageManagement_GB::SetACType(uint8_t __ACType)
{
}

/**
 * @param	uint32_t __batteryWaterTemperature
 * @return  void
 * @retval  null
 * @note	电池水温
 **/
void CANMessageManagement_GB::SetBatteryWaterTemperature(uint32_t __batteryWaterTemperature)
{
}

/**
 * @param	uint8_t __machineWaterTemperature
 * @return  void
 * @retval  null
 * @note	电机水温
 **/
void CANMessageManagement_GB::SetMachineWaterTemperature(uint8_t __machineWaterTemperature)
{
}

/**
 * @param	uint8_t __errorLevel
 * @return  void
 * @retval  null
 * @note	故障
 **/
void CANMessageManagement_GB::SetErrorLevel(uint8_t __errorLevel)
{
	this->m_PG_BatteryMode = __errorLevel;
}

/**
 * @param	uint16_t __reAccumulatedMileage
 * @return  void
 * @retval  null
 * @note	续驶里程
 **/
void CANMessageManagement_GB::SetReAccumulatedMileage(uint16_t __reAccumulatedMileage)
{
	this->m_PG_ContinueMile = __reAccumulatedMileage;
}

/**
 * @param	uint8_t __ACPower
 * @return  void
 * @retval  null
 * @note	发动机
 **/
void CANMessageManagement_GB::SetBCMState(uint8_t __BCMstate)
{
	this->m_PG_Engine = __BCMstate;
}

/**
 * @param	uint8_t __ACTemperature
 * @return  void
 * @retval  null
 * @note	水温
 **/
void CANMessageManagement_GB::SetWaterTemperature(uint8_t __waterTemperature)
{
	this->m_PG_WaterTemperature = __waterTemperature;
}

/**
 * @param	uint8_t __ACWindType
 * @return  void
 * @retval  null
 * @note	空调
 **/
void CANMessageManagement_GB::SetAirCondition(uint8_t __AirCondition)
{
	this->m_PG_AirConditioner = __AirCondition;
}
//IMU横摆角速度
void CANMessageManagement_GB::SetIMUYaw(uint16_t __IMUYaw){
	this->m_PG_IMUSpeed = __IMUYaw;;
}

//方向盘转速
void CANMessageManagement_GB::SetWheelSpeed(uint16_t __WheelSpeed){
	this->m_PG_WheelSpeed = __WheelSpeed;;
}

//刹车状态信号
void CANMessageManagement_GB::SetBrakeStatSig(uint8_t __BrakeStatSig){
	this->m_PG_BrakeStateSig = __BrakeStatSig;;
}

//剩余油量
void CANMessageManagement_GB::SetRemainOil(uint16_t __RemainOil){
	this->m_PG_RemainOil = __RemainOil;//剩余油量;
}

/**
 * @param	uint8_t __handbrake
 * @return  void
 * @retval  null
 * @note	手刹
 **/
void CANMessageManagement_GB::SetHandBrake(uint8_t __handbrake)
{
	this->m_PG_HandBrake = __handbrake;
}

/**
 * @param	uint8_t __wiper
 * @return  void
 * @retval  null
 * @note	雨刮
 **/
void CANMessageManagement_GB::SetWiper(uint8_t __wiper)
{
	this->m_PG_Wiper = __wiper;
}

//Pangoo
//门锁响应
void CANMessageManagement_GB::SetLockResponse(uint8_t __LockRes)
{
	this->m_PG_ResLock = __LockRes;
}

//Pangoo
//侧倾角
void CANMessageManagement_GB::SetRollAngle(uint8_t __RollAngle)
{
	this->m_PG_WarnRollAngle = __RollAngle;
}

//Pangoo
//俯仰角
void CANMessageManagement_GB::SetPitchAngle(uint8_t __PitchAngle)
{
	this->m_PG_WarnPitchAngle = __PitchAngle;
}

//Pangoo
//离合器预警
void CANMessageManagement_GB::SetWarnClutch(uint8_t __WarnClutch)
{
	this->m_PG_WarnClutch = __WarnClutch;
}

//Pangoo
//变速箱预警
void CANMessageManagement_GB::SetWarnGearBox(uint8_t __WarnGearBox)
{
	this->m_PG_WarnGearBox = __WarnGearBox;
}

//Pangoo
//刹车过热
void CANMessageManagement_GB::SetWarnBrake(uint8_t __WarnBrake)
{
	this->m_PG_WarnBrake = __WarnBrake;
}

//Pangoo
//发动机后置氧传感器需要诊断援助
void CANMessageManagement_GB::SetWarnOxygen(uint8_t __WarnOxygen)
{
	this->m_PG_WarnOxygen = __WarnOxygen;
}

//Pangoo
//胎压预警
void CANMessageManagement_GB::SetWarnTire(uint8_t __WarnTire)
{
	this->m_PG_WarnTire = __WarnTire;
}

//Pangoo
//瞬时油耗
void CANMessageManagement_GB::SetOilSpeed(uint16_t __OilSpeed)
{
	this->m_PG_oilSpeed = __OilSpeed;
}

//Pangoo
//驾驶员安全带状态
void CANMessageManagement_GB::SetDriverBelt(uint8_t __DriverBelt)
{
	this->m_PG_DriverBelt = __DriverBelt;
}

//Pangoo
//乘客安全带状态
void CANMessageManagement_GB::SetPassengerBelt(uint8_t __PassengerBelt)
{
	this->m_PG_PassBelt = __PassengerBelt;
}

//Pangoo
//怠速状态
void CANMessageManagement_GB::SetDaiSu(uint8_t __DaiSu)
{
	this->m_PG_DaiSu = __DaiSu;
}

//Pangoo
//轮胎低压指示
void CANMessageManagement_GB::SetTirePreLow(uint8_t __TirePreLow)
{
	this->m_PG_TirePreLow = __TirePreLow;
}

//Pangoo
//钥匙档位
void CANMessageManagement_GB::SetKeyGear(uint8_t __KeyGear)
{
	this->m_PG_KeyGear = __KeyGear;
}

//Pangoo
//巡航和限速系统开关状态
void CANMessageManagement_GB::SetSpeedLimitState(uint8_t __SpeedLimitState)
{
	this->m_PG_SpeedLimitStat = __SpeedLimitState;
}

//Pangoo
//防抱死制动系统失败
void CANMessageManagement_GB::SetAbsFailure(uint8_t __AbsFailure)
{
	this->m_PG_AbsFailure = __AbsFailure;
}

//Pangoo
//防抱死制动系统激活
void CANMessageManagement_GB::SetAbsActive(uint8_t __AbsActive)
{
	this->m_PG_AbsActive = __AbsActive;
}

//Pangoo
//车身横摆角速度
void CANMessageManagement_GB::SetYawAcc(uint16_t __YawAcc)
{
	this->m_PG_YawAcc = __YawAcc;
}

//Pangoo
//实际加速度有效
void CANMessageManagement_GB::SetActualAccValid(uint8_t __ActualAccValid)
{
	this->m_PG_ActualAccBool = __ActualAccValid;
}

//Pangoo
//实际加速度
void CANMessageManagement_GB::SetActualAcc(uint16_t __ActualAcc)
{
	this->m_PG_ActualAcc = __ActualAcc;
}

//Pangoo
//方向盘转角
void CANMessageManagement_GB::SetWheelAngle(uint16_t __WheelAngle)
{
	this->m_PG_WheelAngel = __WheelAngle;
}

//Pangoo
//侧向加速度
void CANMessageManagement_GB::SetCrossAcc(uint16_t __CrossAcc)
{
	this->m_PG_CrossAcc = __CrossAcc;
}

//Pangoo
//纵向加速度
void CANMessageManagement_GB::SetVerticalAcc(uint16_t __VerticalAcc)
{
	this->m_PG_VerticalAcc = __VerticalAcc;
}

//Pangoo
//转向灯
void CANMessageManagement_GB::SetTurnLight(uint8_t __TurnLight)
{
	this->m_PG_TurnLight = __TurnLight;
}

//Pangoo
//寻车响应
void CANMessageManagement_GB::SetFindResponse(uint8_t __FindCar)
{
	this->m_PG_ResFind = __FindCar;
}

//Pangoo
//空调响应
void CANMessageManagement_GB::SetAirConditionResponse(uint8_t __AirCond)
{
	this->m_PG_ResAirCond = __AirCond;
}


//Pangoo: 模拟假数据
void CANMessageManagement_GB::DebugPGPacket(guchar* __vehicleData, guint& __index)
{
	//整车数据
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = 0x01;//车辆状态
	__vehicleData[__index++] = 0xFF;//充电状态×--0xFF
	__vehicleData[__index++] = 0x03;//运行模式-燃油
	__vehicleData[__index++] = 3333 >> 8 & 0xFF;//车速
	__vehicleData[__index++] = 3333 & 0xFF;//车速
	__vehicleData[__index++] = 333333 >> 24 & 0xFF;//累计里程
	__vehicleData[__index++] = 333333 >> 16 & 0xFF;//累计里程
	__vehicleData[__index++] = 333333 >> 8 & 0xFF;//累计里程
	__vehicleData[__index++] = 333333 & 0xFF;//累计里程
	__vehicleData[__index++] = 0xFF;//总电压×
	__vehicleData[__index++] = 0xFF;//总电压×
	__vehicleData[__index++] = 0xFF;//总电流×
	__vehicleData[__index++] = 0xFF;//总电流×
	__vehicleData[__index++] = 0xFF;//SOC状态×
	__vehicleData[__index++] = 0xFF;//DC-DC状态×
	__vehicleData[__index++] = 0x01;//档位
	__vehicleData[__index++] = 0xFF;//绝缘电阻×
	__vehicleData[__index++] = 0xFF;//绝缘电阻×
	__vehicleData[__index++] = 33;//加速踏板行程
	__vehicleData[__index++] = 33;//制动踏板行程
	__vehicleData[__index++] = 0x01;//转向灯
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//纵向加速度
	__vehicleData[__index++] = 333 & 0xFF;//纵向加速度
	__vehicleData[__index++] = 333> 8 & 0xFF;//侧向加速度
	__vehicleData[__index++] = 333 & 0xFF;//侧向加速度
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//IMU横摆角速度
	__vehicleData[__index++] = 333 & 0xFF;//IMU横摆角速度
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//方向盘转角
	__vehicleData[__index++] = 333 & 0xFF;//方向盘转角
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//方向盘转速
	__vehicleData[__index++] = 333 & 0xFF;//方向盘转速
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//实际加速度
	__vehicleData[__index++] = 333 & 0xFF;//实际加速度
	__vehicleData[__index++] = 0x00;//实际加速度有效
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//车身横摆角速度
	__vehicleData[__index++] = 333 & 0xFF;//车身横摆角速度
	__vehicleData[__index++] = 0x01;//防抱死制动系统激活
	__vehicleData[__index++] = 0x00;//防抱死制动系统失败
	__vehicleData[__index++] = 0x01;//巡航和限速系统开关状态
	__vehicleData[__index++] = 0x01;//制动状态信号
	__vehicleData[__index++] = 0x02;//钥匙档位
	__vehicleData[__index++] = 0x00;//轮胎低压指示
	__vehicleData[__index++] = 0x01;//怠速状态
	__vehicleData[__index++] = 0x02;//乘客安全带状态
	__vehicleData[__index++] = 0x02;//驾驶员安全带状态

	//发动机
	__vehicleData[__index++] = 0x04;
	__vehicleData[__index++] = 0x01;//发动机状态
	__vehicleData[__index++] = 3333 >> 8 & 0xFF;//曲轴转速
	__vehicleData[__index++] = 3333 & 0xFF;//曲轴转速
	__vehicleData[__index++] = 3333 >> 8 & 0xFF;//瞬时油耗
	__vehicleData[__index++] = 3333 & 0xFF;//瞬时油耗

	//车辆位置
	__vehicleData[__index++] = 0x05;
	__vehicleData[__index++] = 0x00;//定位状态
	__vehicleData[__index++] = 333333 >> 24 & 0xFF;//经度
	__vehicleData[__index++] = 333333 >> 16 & 0xFF;//经度
	__vehicleData[__index++] = 333333 >> 8 & 0xFF;//经度
	__vehicleData[__index++] = 333333 & 0xFF;//经度
	__vehicleData[__index++] = 333333 >> 24 & 0xFF;//纬度
	__vehicleData[__index++] = 333333 >> 16 & 0xFF;//纬度
	__vehicleData[__index++] = 333333 >> 8 & 0xFF;//纬度
	__vehicleData[__index++] = 333333 & 0xFF;//纬度

	//报警数据
	__vehicleData[__index++] = 0x07;
	__vehicleData[__index++] = 0x01;//胎压预警
	__vehicleData[__index++] = 0x01;//发动机后置氧传感器需要诊断援助
	__vehicleData[__index++] = 0x01;//刹车过热
	__vehicleData[__index++] = 0x01;//变速箱预警
	__vehicleData[__index++] = 0x01;//离合器预警
	__vehicleData[__index++] = 33;//俯仰角
	__vehicleData[__index++] = 33;//侧倾角

	//81 Pangoo自定义数据
	__vehicleData[__index++] = 0x81;
	__vehicleData[__index++] = 0x01;//门锁状态
	__vehicleData[__index++] = 0x01;//车窗状态
	__vehicleData[__index++] = 0x01;//车灯状态
	__vehicleData[__index++] = 0x01;//车灯状态
	__vehicleData[__index++] = 0x01;//车灯状态
	__vehicleData[__index++] = 0x01;//车灯状态
	__vehicleData[__index++] = 0x01;//发动机状态
	__vehicleData[__index++] = 33;//水温
	__vehicleData[__index++] = 0x01;//空调
	__vehicleData[__index++] = 0xFF;//电池故障
	__vehicleData[__index++] = 333 >> 8 & 0xFF;//续航里程
	__vehicleData[__index++] = 333 & 0xFF;//续航里程
	__vehicleData[__index++] = 0x01;//手刹状态
	__vehicleData[__index++] = 0x01;//雨刮状态
}

//Pangoo: 记录接收到的数据
void CANMessageManagement_GB::LogPGforMCUTest()
{
	ydfs.open("/app/bin/ydalllog.txt",std::ios::app);
	ydfs << "~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	timeval __tv;
	gettimeofday(&__tv, NULL);
	__tv.tv_sec = __tv.tv_sec + 8 * 3600;
	char tmpbuf[128];
	strftime(tmpbuf,128,"[%F %T] ",localtime(&__tv.tv_sec));
	ydfs << tmpbuf << endl;
    YDLog(4,"车辆状态",'x',this->m_PG_CarStat);
    YDLog(2,"车速",'d',this->m_PG_Speed);
	YDLog(4,"累计里程",'d',this->m_PG_TotalMile);//累计里程
	YDLog(2,"档位",'x',this->m_PG_Gear);//档位
	YDLog(6,"加速踏板行程",'x',this->m_PG_AccPedal);//加速踏板行程
	YDLog(6,"制动踏板行程",'x',this->m_PG_BrakePedal);//制动踏板行程
	YDLog(3,"转向灯",'x',this->m_PG_TurnLight);//转向灯
	YDLog(5,"纵向加速度",'d',this->m_PG_VerticalAcc);//纵向加速度
	YDLog(5,"侧向加速度",'d',this->m_PG_CrossAcc);//侧向加速度
	YDLog(5,"IMU横摆角速度",'d',this->m_PG_IMUSpeed);//IMU横摆角速度
	YDLog(5,"方向盘转角",'d',this->m_PG_WheelAngel);//方向盘转角
	YDLog(5,"方向盘转速",'d',this->m_PG_WheelSpeed);//方向盘转速
	YDLog(5,"实际加速度",'d',this->m_PG_ActualAcc);//实际加速度
	YDLog(7,"实际加速度有效",'x',this->m_PG_ActualAccBool);//实际加速度有效
	YDLog(7,"车身横摆角速度",'d',this->m_PG_YawAcc);//车身横摆角速度
	YDLog(9,"防抱死制动系统激活",'x',this->m_PG_AbsActive);//防抱死制动系统激活
	YDLog(9,"防抱死制动系统失败",'x',this->m_PG_AbsFailure);//防抱死制动系统失败
	YDLog(11,"巡航和限速系统开关状态",'x',this->m_PG_SpeedLimitStat);//巡航和限速系统开关状态
	YDLog(6,"制动状态信号",'x',this->m_PG_BrakeStateSig);//制动状态信号
	YDLog(4,"钥匙档位",'x',this->m_PG_KeyGear);//钥匙档位
	YDLog(6,"轮胎低压指示",'x',this->m_PG_TirePreLow);//轮胎低压指示
	YDLog(4,"怠速状态",'x',this->m_PG_DaiSu);//怠速状态
	YDLog(7,"乘客安全带状态",'x',this->m_PG_PassBelt);//乘客安全带状态
	YDLog(8,"驾驶员安全带状态",'x',this->m_PG_DriverBelt);//驾驶员安全带状态

	//发动机
	YDLog(5,"发动机状态",'x',this->m_PG_EngineStat);//发动机状态
	YDLog(4,"曲轴转速",'d',this->m_PG_QuZhou);//曲轴转速
	YDLog(4,"瞬时油耗",'d',this->m_PG_oilSpeed);//瞬时油耗
	YDLog(4,"剩余油量",'d',this->m_PG_RemainOil);//剩余油量

	//车辆位置
	YDLog(4,"定位状态",'x',this->m_PG_ValidPosition);//定位状态
	YDLog(2,"经度",'d',this->m_PG_Longitude);//经度
	YDLog(2,"纬度",'d',this->m_PG_Latitude);//纬度

	//报警数据
	YDLog(4,"胎压预警",'x',this->m_PG_WarnTire);//胎压预警
	YDLog(9,"发动机后置氧传感器",'x',this->m_PG_WarnOxygen);//发动机后置氧传感器需要诊断援助
	YDLog(4,"刹车过热",'x',this->m_PG_WarnBrake);//刹车过热
	YDLog(5,"变速箱预警",'x',this->m_PG_WarnGearBox);//变速箱预警
	YDLog(5,"离合器预警",'x',this->m_PG_WarnClutch);//离合器预警
	YDLog(3,"俯仰角",'x',this->m_PG_WarnPitchAngle);//俯仰角
	YDLog(3,"侧倾角",'x',this->m_PG_WarnRollAngle);//侧倾角

	//81 Pangoo自定义数据
	YDLog(4,"门锁状态",'x',this->m_PG_DoorLockMode);
	YDLog(4,"车窗状态",'x',this->m_PG_WindowMode);
	YDLog(4,"车灯状态",'d',this->m_PG_CarLight);
	YDLog(5,"发动机状态",'x',this->m_PG_Engine);
	YDLog(2,"水温",'x',this->m_PG_WaterTemperature);
	YDLog(2,"空调",'x',this->m_PG_AirConditioner);
	YDLog(4,"续航里程",'d',this->m_PG_ContinueMile);
	YDLog(4,"手刹状态",'x',this->m_PG_HandBrake);
	YDLog(4,"雨刮状态",'x',this->m_PG_Wiper);

	//轻微故障--20181128
	YDLog(5,"刹车片磨损",'x',this->m_PG_MinorWarn1);//刹车片磨损指示
	YDLog(7,"发动机机油更换",'x',this->m_PG_MinorWarn2);//发动机机油更换指示
	YDLog(6,"发动机机油热",'x',this->m_PG_MinorWarn3);//发动机机油热指示
	YDLog(8,"发动机机油压力低",'x',this->m_PG_MinorWarn4);//发动机机油压力低指示
	//一般故障--20181128
	YDLog(7,"电池系统不稳定",'x',this->m_PG_NormalWarn1);//12伏电池系统不稳定指示
	YDLog(7,"空调压缩机故障",'x',this->m_PG_NormalWarn2);//空调压缩机故障指示
	YDLog(6,"主动振动故障",'x',this->m_PG_NormalWarn3);//主动振动故障指示
	YDLog(7,"巡航暂时不可用",'x',this->m_PG_NormalWarn4);//巡航暂时不可用指示
	YDLog(4,"刹车过热",'x',this->m_PG_NormalWarn5);//刹车过热指示
	YDLog(9,"压缩机驱动故障状态",'x',this->m_PG_NormalWarn6);//压缩机驱动故障状态指示
	YDLog(9,"压缩机高压异常状态",'x',this->m_PG_NormalWarn7);//压缩机高压异常状态指示
	YDLog(8,"压缩机内部可恢复",'x',this->m_PG_NormalWarn8);//压缩机内部可恢复故障指示
	YDLog(9,"压缩机内部关闭故障",'x',this->m_PG_NormalWarn9);//压缩机内部关闭故障指示
	YDLog(9,"压缩机电机性能故障",'x',this->m_PG_NormalWarn10);//压缩机电机性能故障指示
	YDLog(7,"压缩机输出过载",'x',this->m_PG_NormalWarn11);//压缩机输出过载指示
	YDLog(5,"压缩机过热",'x',this->m_PG_NormalWarn12);//压缩机过热指示
	YDLog(4,"过温警告",'x',this->m_PG_NormalWarn13);//过温警告指示
	YDLog(7,"发动机扭矩减小",'x',this->m_PG_NormalWarn14);//发动机扭矩减小故障
	YDLog(8,"电动驻车系统警告",'x',this->m_PG_NormalWarn15);//电动驻车系统警告指示
	YDLog(9,"燃油非排放相关故障",'x',this->m_PG_NormalWarn16);//燃油系统非排放相关故障指示
	YDLog(7,"变速离合器故障",'x',this->m_PG_NormalWarn17);//变速离合器故障指示
	YDLog(8,"变速箱液力变矩器",'x',this->m_PG_NormalWarn18);//变速箱液力变矩器离合器命令模式故障指示
	YDLog(6,"变速箱热管理",'x',this->m_PG_NormalWarn19);//变速箱热管理
	//严重故障--20181128
	YDLog(9,"变速器换挡方向故障",'x',this->m_PG_SeriousWarn1);//自动变速器换挡方向故障指示
	YDLog(9,"电池传感器内部故障",'x',this->m_PG_SeriousWarn2);//智能电池传感器内部故障指示
	YDLog(8,"碰撞准备系统失败",'x',this->m_PG_SeriousWarn3);//碰撞准备系统失败指示
	YDLog(9,"碰撞准备系统不可用",'x',this->m_PG_SeriousWarn4);//碰撞准备系统不可用指示
	YDLog(7,"驾驶员油门超驰",'x',this->m_PG_SeriousWarn5);//检测到驾驶员油门超驰
	YDLog(8,"燃油控制系统故障",'x',this->m_PG_SeriousWarn6);//燃油控制系统故障指示
	YDLog(8,"喷射器控注入故障",'x',this->m_PG_SeriousWarn7);//燃油喷射器控制模块注入故障指示
	YDLog(8,"燃油系统排放故障",'x',this->m_PG_SeriousWarn8);//燃油系统排放相关故障指示
	//致命故障
	YDLog(6,"制动系统故障",'x',this->m_PG_DeadlyWarn1);//制动系统故障指示
	YDLog(5,"发动机失败",'x',this->m_PG_DeadlyWarn2);//发动机失败指示

	ydfs.close();
}

/**
 * @param   gchar* __vehicleData, gint __index
 * @return  data
 * @retval  gchar*
 * @note    获得Pangoo数据包
 **/
void CANMessageManagement_GB::AppendPGResPacket(guchar* __vehicleData, guint& __index)
{
	BinderContactsWorker* _binderContactsWorker = BinderContactsWorker::GetInstance();
	__vehicleData[__index++] = _binderContactsWorker->GetSerial().size();
	int __flag = 0;
	if(_binderContactsWorker->CheckSerial(0x01)){
		__vehicleData[__index++] = 0x01;
		__vehicleData[__index++] = 0x02;
//		if(__resflag == 1){
//			this->m_PG_ResLock = this->m_PG_ResLock | 0x02;
//			__vehicleData[__index++] = this->m_PG_ResLock;
//		}
//		else if(__resflag == 0){
		for(guint _i=0;_i<_binderContactsWorker->GetSerialNumber().size();_i++) {
			if(_binderContactsWorker->GetSerialNumber()[_i] == 0x01) {
				__flag = 1;
				break;
			}
		}
		if(__flag == 1){
			this->m_PG_ResLock = this->m_PG_ResLock | 0x02;
			__flag = 0;
		}
		else{
			this->m_PG_ResLock = this->m_PG_ResLock & 0xFD;
		}
		__vehicleData[__index++] = this->m_PG_ResLock;
//		}
		__vehicleData[__index++] = this->m_PG_WindowMode;
	}
	if(_binderContactsWorker->CheckSerial(0x02)){
			__vehicleData[__index++] = 0x02;
			__vehicleData[__index++] = 0x01;
//			if(__resflag == 1){
//				__vehicleData[__index++] = this->m_PG_ResFind;
//			}
//			else if(__resflag == 0){
				for(guint _i=0;_i<_binderContactsWorker->GetSerialNumber().size();_i++) {
					if(_binderContactsWorker->GetSerialNumber()[_i] == 0x02) {
						__flag = 1;
						break;
					}
				}
				if(__flag == 1){
					__vehicleData[__index++] = this->m_PG_ResFind;
					__flag = 0;
				}
				else{
					__vehicleData[__index++] = 0x02;
				}
//			}
	}
	if(_binderContactsWorker->CheckSerial(0x03)){
			__vehicleData[__index++] = 0x03;
			__vehicleData[__index++] = 0x02;
//			if(__resflag == 1){
//				__vehicleData[__index++] = this->m_PG_ResAirCond;
//			}
//			else if(__resflag == 0){
				for(guint _i=0;_i<_binderContactsWorker->GetSerialNumber().size();_i++) {
					if(_binderContactsWorker->GetSerialNumber()[_i] == 0x03) {
						__flag = 1;
						break;
					}
				}
				if(__flag == 1){
					__vehicleData[__index++] = this->m_PG_ResAirCond;
					__flag = 0;
				}
				else{
					__vehicleData[__index++] = 0x09;
				}
//			}
			__vehicleData[__index++] = this->m_PG_AirConditioner;
	}
}


//----------------------------------------------------------------------------------
//--------------------------20181128------------------------------------------------
//----------------------------------------------------------------------------------
//轻微故障--20181128
void CANMessageManagement_GB::SetMinorFailure1(uint8_t __Fault)
{
	printf("100-2 is %2X\n",__Fault);
	this->m_PG_MinorWarn1 = __Fault;
}

void CANMessageManagement_GB::SetMinorFailure2(uint8_t __Fault)
{
	this->m_PG_MinorWarn2 = __Fault;
}

void CANMessageManagement_GB::SetMinorFailure3(uint8_t __Fault)
{
	this->m_PG_MinorWarn3 = __Fault;
}

void CANMessageManagement_GB::SetMinorFailure4(uint8_t __Fault)
{
	this->m_PG_MinorWarn4 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure1(uint8_t __Fault)
{
	this->m_PG_NormalWarn1 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure2(uint8_t __Fault)
{
	this->m_PG_NormalWarn2 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure3(uint8_t __Fault)
{
	this->m_PG_NormalWarn3 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure4(uint8_t __Fault)
{
	this->m_PG_NormalWarn4 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure5(uint8_t __Fault)
{
	this->m_PG_NormalWarn5 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure6(uint8_t __Fault)
{
	this->m_PG_NormalWarn6 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure7(uint8_t __Fault)
{
	this->m_PG_NormalWarn7 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure8(uint8_t __Fault)
{
	this->m_PG_NormalWarn8 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure9(uint8_t __Fault)
{
	this->m_PG_NormalWarn9 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure10(uint8_t __Fault)
{
	this->m_PG_NormalWarn10 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure11(uint8_t __Fault)
{
	this->m_PG_NormalWarn11 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure12(uint8_t __Fault)
{
	this->m_PG_NormalWarn12 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure13(uint8_t __Fault)
{
	this->m_PG_NormalWarn13 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure14(uint8_t __Fault)
{
	this->m_PG_NormalWarn14 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure15(uint8_t __Fault)
{
	this->m_PG_NormalWarn15 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure16(uint8_t __Fault)
{
	this->m_PG_NormalWarn16 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure17(uint8_t __Fault)
{
	this->m_PG_NormalWarn17 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure18(uint8_t __Fault)
{
	this->m_PG_NormalWarn18 = __Fault;
}

void CANMessageManagement_GB::SetNormalFailure19(uint8_t __Fault)
{
	this->m_PG_NormalWarn19 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure1(uint8_t __Fault)
{
	this->m_PG_SeriousWarn1 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure2(uint8_t __Fault)
{
	this->m_PG_SeriousWarn2 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure3(uint8_t __Fault)
{
	this->m_PG_SeriousWarn3 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure4(uint8_t __Fault)
{
	this->m_PG_SeriousWarn4 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure5(uint8_t __Fault)
{
	this->m_PG_SeriousWarn5 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure6(uint8_t __Fault)
{
	this->m_PG_SeriousWarn6 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure7(uint8_t __Fault)
{
	this->m_PG_SeriousWarn7 = __Fault;
}

void CANMessageManagement_GB::SetSeriousFailure8(uint8_t __Fault)
{
	this->m_PG_SeriousWarn8 = __Fault;
}

void CANMessageManagement_GB::SetDeadlyFailure1(uint8_t __Fault)
{
	this->m_PG_DeadlyWarn1 = __Fault;
}

void CANMessageManagement_GB::SetDeadlyFailure2(uint8_t __Fault)
{
	this->m_PG_DeadlyWarn2 = __Fault;
}

/**
 * @param   gchar* __vehicleData, gint __index
 * @return  data
 * @retval  gchar*
 * @note    获得Pangoo数据包
 **/
void CANMessageManagement_GB::AppendPGPacket(guchar* __vehicleData, guint& __index)
{
	//整车数据
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = this->m_PG_CarStat;//车辆状态
	__vehicleData[__index++] = this->m_PG_ChargeStat;//充电状态×--0xFF
	__vehicleData[__index++] = 0x03;//运行模式-燃油---2020:固定值0x01
	__vehicleData[__index++] = this->m_PG_Speed >> 8 & 0xFF;//车速
	__vehicleData[__index++] = this->m_PG_Speed & 0xFF;//车速
	__vehicleData[__index++] = this->m_PG_TotalMile >> 24 & 0xFF;//累计里程
	__vehicleData[__index++] = this->m_PG_TotalMile >> 16 & 0xFF;//累计里程
	__vehicleData[__index++] = this->m_PG_TotalMile >> 8 & 0xFF;//累计里程
	__vehicleData[__index++] = this->m_PG_TotalMile & 0xFF;//累计里程
	__vehicleData[__index++] = this->m_PG_TotalVol >> 8 & 0xFF;//总电压×
	__vehicleData[__index++] = this->m_PG_TotalVol & 0xFF;//总电压×
	__vehicleData[__index++] = this->m_PG_TotalEle >> 8 & 0xFF;//总电流×
	__vehicleData[__index++] = this->m_PG_TotalEle & 0xFF;//总电流×
	__vehicleData[__index++] = this->m_PG_SOC;//SOC状态×
	__vehicleData[__index++] = this->m_PG_DC2;//DC-DC状态×
	__vehicleData[__index++] = this->m_PG_Gear;//档位
	__vehicleData[__index++] = this->m_PG_Resis >> 8 & 0xFF;//绝缘电阻×
	__vehicleData[__index++] = this->m_PG_Resis & 0xFF;//绝缘电阻×
	__vehicleData[__index++] = this->m_PG_AccPedal;//加速踏板行程
	__vehicleData[__index++] = this->m_PG_BrakePedal;//制动踏板行程
	__vehicleData[__index++] = this->m_PG_TurnLight;//转向灯
	__vehicleData[__index++] = this->m_PG_VerticalAcc >> 8 & 0xFF;//纵向加速度
	__vehicleData[__index++] = this->m_PG_VerticalAcc & 0xFF;//纵向加速度
	__vehicleData[__index++] = this->m_PG_CrossAcc >> 8 & 0xFF;//侧向加速度
	__vehicleData[__index++] = this->m_PG_CrossAcc & 0xFF;//侧向加速度
	__vehicleData[__index++] = this->m_PG_IMUSpeed >> 8 & 0xFF;//IMU横摆角速度×
	__vehicleData[__index++] = this->m_PG_IMUSpeed & 0xFF;//IMU横摆角速度×
	__vehicleData[__index++] = this->m_PG_WheelAngel >> 8 & 0xFF;//方向盘转角
	__vehicleData[__index++] = this->m_PG_WheelAngel & 0xFF;//方向盘转角
	__vehicleData[__index++] = this->m_PG_WheelSpeed >> 8 & 0xFF;//方向盘转速×
	__vehicleData[__index++] = this->m_PG_WheelSpeed & 0xFF;//方向盘转速×
	__vehicleData[__index++] = this->m_PG_ActualAcc >> 8 & 0xFF;//实际加速度
	__vehicleData[__index++] = this->m_PG_ActualAcc & 0xFF;//实际加速度
	__vehicleData[__index++] = this->m_PG_ActualAccBool;//实际加速度有效
	__vehicleData[__index++] = this->m_PG_YawAcc >> 8 & 0xFF;//车身横摆角速度
	__vehicleData[__index++] = this->m_PG_YawAcc & 0xFF;//车身横摆角速度
	__vehicleData[__index++] = this->m_PG_AbsActive;//防抱死制动系统激活
	__vehicleData[__index++] = this->m_PG_AbsFailure;//防抱死制动系统失败
	__vehicleData[__index++] = this->m_PG_SpeedLimitStat;//巡航和限速系统开关状态
	__vehicleData[__index++] = this->m_PG_BrakeStateSig;//制动状态信号×
	__vehicleData[__index++] = this->m_PG_KeyGear;//钥匙档位
	__vehicleData[__index++] = this->m_PG_TirePreLow;//轮胎低压指示
	__vehicleData[__index++] = this->m_PG_DaiSu;//怠速状态
	__vehicleData[__index++] = this->m_PG_PassBelt;//乘客安全带状态
	__vehicleData[__index++] = this->m_PG_DriverBelt;//驾驶员安全带状态

	//发动机
	__vehicleData[__index++] = 0x04;
	__vehicleData[__index++] = this->m_PG_EngineStat;//发动机状态
	__vehicleData[__index++] = this->m_PG_QuZhou >> 8 & 0xFF;//曲轴转速
	__vehicleData[__index++] = this->m_PG_QuZhou & 0xFF;//曲轴转速
	__vehicleData[__index++] = this->m_PG_oilSpeed >> 8 & 0xFF;//瞬时油耗
	__vehicleData[__index++] = this->m_PG_oilSpeed & 0xFF;//瞬时油耗
	__vehicleData[__index++] = this->m_PG_RemainOil >> 8 & 0xFF;//剩余油量
	__vehicleData[__index++] = this->m_PG_RemainOil & 0xFF;//剩余油量

	//车辆位置
	__vehicleData[__index++] = 0x05;
	__vehicleData[__index++] = this->m_PG_ValidPosition;//定位状态
	__vehicleData[__index++] = this->m_PG_Longitude >> 24 & 0xFF;//经度
	__vehicleData[__index++] = this->m_PG_Longitude >> 16 & 0xFF;//经度
	__vehicleData[__index++] = this->m_PG_Longitude >> 8 & 0xFF;//经度
	__vehicleData[__index++] = this->m_PG_Longitude & 0xFF;//经度
	__vehicleData[__index++] = this->m_PG_Latitude >> 24 & 0xFF;//纬度
	__vehicleData[__index++] = this->m_PG_Latitude >> 16 & 0xFF;//纬度
	__vehicleData[__index++] = this->m_PG_Latitude >> 8 & 0xFF;//纬度
	__vehicleData[__index++] = this->m_PG_Latitude & 0xFF;//纬度

	//报警数据--20181128
//	__vehicleData[__index++] = 0x07;
//	__vehicleData[__index++] = this->m_PG_WarnTire;//胎压预警
//	__vehicleData[__index++] = this->m_PG_WarnOxygen;//发动机后置氧传感器需要诊断援助
//	__vehicleData[__index++] = this->m_PG_WarnBrake;//刹车过热
//	__vehicleData[__index++] = this->m_PG_WarnGearBox;//变速箱预警
//	__vehicleData[__index++] = this->m_PG_WarnClutch;//离合器预警
//	__vehicleData[__index++] = this->m_PG_WarnPitchAngle;//俯仰角
//	__vehicleData[__index++] = this->m_PG_WarnRollAngle;//侧倾角

	//81 Pangoo自定义数据
	__vehicleData[__index++] = 0x81;
	__vehicleData[__index++] = this->m_PG_DoorLockMode;
	__vehicleData[__index++] = this->m_PG_WindowMode;
	__vehicleData[__index++] = this->m_PG_CarLight >> 24 & 0xFF;
	__vehicleData[__index++] = this->m_PG_CarLight >> 16 & 0xFF;
	__vehicleData[__index++] = this->m_PG_CarLight >> 8 & 0xFF;
	__vehicleData[__index++] = this->m_PG_CarLight &0xFF;
	__vehicleData[__index++] = this->m_PG_Engine;
	__vehicleData[__index++] = this->m_PG_WaterTemperature;
	__vehicleData[__index++] = this->m_PG_AirConditioner;
	__vehicleData[__index++] = this->m_PG_BatteryMode;//动力电池状态×
	__vehicleData[__index++] = this->m_PG_ContinueMile >> 8 & 0xFF;
	__vehicleData[__index++] = this->m_PG_ContinueMile & 0xFF;
	__vehicleData[__index++] = this->m_PG_HandBrake;
	__vehicleData[__index++] = this->m_PG_Wiper;
}


void CANMessageManagement_GB::AppendPGWarnPacket(guchar* __vehicleData, guint& __index)
{
	std::unique_lock<std::mutex>(m_mutex);
	for(guint _i=0;_i<this->m_PG_WarnFlag.size();_i++) {
		if(m_PG_WarnFlag[_i] == 1) {
			YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 1\n");
			//轻微故障
			__vehicleData[__index++] = 0xF1;
			__vehicleData[__index++] = 0x01;
			__vehicleData[__index++] = this->m_PG_MinorWarn1;//刹车片磨损指示
			__vehicleData[__index++] = 0x02;
			__vehicleData[__index++] = this->m_PG_MinorWarn2;//发动机机油更换指示
			__vehicleData[__index++] = 0x03;
			__vehicleData[__index++] = this->m_PG_MinorWarn3;//发动机机油热指示
			__vehicleData[__index++] = 0x04;
			__vehicleData[__index++] = this->m_PG_MinorWarn4;//发动机机油压力低指示
		}
		else if(m_PG_WarnFlag[_i] == 2) {
			YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 2\n");
			//一般故障
			__vehicleData[__index++] = 0xF2;
			__vehicleData[__index++] = 0x01;
			__vehicleData[__index++] = this->m_PG_NormalWarn1;//12伏电池系统不稳定指示
			__vehicleData[__index++] = 0x02;
			__vehicleData[__index++] = this->m_PG_NormalWarn2;//空调压缩机故障指示
			__vehicleData[__index++] = 0x03;
			__vehicleData[__index++] = this->m_PG_NormalWarn3;//主动振动故障指示
			__vehicleData[__index++] = 0x04;
			__vehicleData[__index++] = this->m_PG_NormalWarn4;//巡航暂时不可用指示
			__vehicleData[__index++] = 0x05;
			__vehicleData[__index++] = this->m_PG_NormalWarn5;//刹车过热指示
			__vehicleData[__index++] = 0x06;
			__vehicleData[__index++] = this->m_PG_NormalWarn6;//压缩机驱动故障状态指示
			__vehicleData[__index++] = 0x07;
			__vehicleData[__index++] = this->m_PG_NormalWarn7;//压缩机高压异常状态指示
			__vehicleData[__index++] = 0x08;
			__vehicleData[__index++] = this->m_PG_NormalWarn8;//压缩机内部可恢复故障指示
			__vehicleData[__index++] = 0x09;
			__vehicleData[__index++] = this->m_PG_NormalWarn9;//压缩机内部关闭故障指示
			__vehicleData[__index++] = 0x0A;
			__vehicleData[__index++] = this->m_PG_NormalWarn10;//压缩机电机性能故障指示
			__vehicleData[__index++] = 0x0B;
			__vehicleData[__index++] = this->m_PG_NormalWarn11;//压缩机输出过载指示
			__vehicleData[__index++] = 0x0C;
			__vehicleData[__index++] = this->m_PG_NormalWarn12;//压缩机过热指示
			__vehicleData[__index++] = 0x0D;
			__vehicleData[__index++] = this->m_PG_NormalWarn13;//过温警告指示
			__vehicleData[__index++] = 0x0E;
			__vehicleData[__index++] = this->m_PG_NormalWarn14;//发动机扭矩减小故障
			__vehicleData[__index++] = 0x0F;
			__vehicleData[__index++] = this->m_PG_NormalWarn15;//电动驻车系统警告指示
			__vehicleData[__index++] = 0x10;
			__vehicleData[__index++] = this->m_PG_NormalWarn16;//燃油系统非排放相关故障指示
			__vehicleData[__index++] = 0x11;
			__vehicleData[__index++] = this->m_PG_NormalWarn17;//变速离合器故障指示
			__vehicleData[__index++] = 0x12;
			__vehicleData[__index++] = this->m_PG_NormalWarn18;//变速箱液力变矩器离合器命令模式故障指示
			__vehicleData[__index++] = 0x13;
			__vehicleData[__index++] = this->m_PG_NormalWarn19;//变速箱热管理
		}
		else if(m_PG_WarnFlag[_i] == 3) {
			YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 3\n");
			//严重故障
			__vehicleData[__index++] = 0xF3;
			__vehicleData[__index++] = 0x01;
			__vehicleData[__index++] = this->m_PG_SeriousWarn1;//自动变速器换挡方向故障指示
			__vehicleData[__index++] = 0x02;
			__vehicleData[__index++] = this->m_PG_SeriousWarn2;//智能电池传感器内部故障指示
			__vehicleData[__index++] = 0x03;
			__vehicleData[__index++] = this->m_PG_SeriousWarn3;//碰撞准备系统失败指示
			__vehicleData[__index++] = 0x04;
			__vehicleData[__index++] = this->m_PG_SeriousWarn4;//碰撞准备系统不可用指示
			__vehicleData[__index++] = 0x05;
			__vehicleData[__index++] = this->m_PG_SeriousWarn5;//检测到驾驶员油门超驰
			__vehicleData[__index++] = 0x06;
			__vehicleData[__index++] = this->m_PG_SeriousWarn6;//燃油控制系统故障指示
			__vehicleData[__index++] = 0x07;
			__vehicleData[__index++] = this->m_PG_SeriousWarn7;//燃油喷射器控制模块注入故障指示
			__vehicleData[__index++] = 0x08;
			__vehicleData[__index++] = this->m_PG_SeriousWarn8;//燃油系统排放相关故障指示
		}
		else if(m_PG_WarnFlag[_i] == 4) {
			YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 4\n");
			//致命故障
			__vehicleData[__index++] = 0xF4;
			__vehicleData[__index++] = 0x01;
			__vehicleData[__index++] = this->m_PG_DeadlyWarn1;//制动系统故障指示
			__vehicleData[__index++] = 0x02;
			__vehicleData[__index++] = this->m_PG_DeadlyWarn2;//发动机失败指示
		}
//		else if(m_PG_WarnFlag[_i] == 5) {
//			YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 5\n");
//			//报警数据
//			__vehicleData[__index++] = 0xF5;
//			__vehicleData[__index++] = this->m_PG_WarnTire;//胎压预警
//			__vehicleData[__index++] = this->m_PG_WarnOxygen;//发动机后置氧传感器需要诊断援助
//		//	__vehicleData[__index++] = this->m_PG_WarnBrake;//刹车过热
//			__vehicleData[__index++] = this->m_PG_WarnGearBox;//变速箱预警
//		//	__vehicleData[__index++] = this->m_PG_WarnClutch;//离合器预警
//			__vehicleData[__index++] = this->m_PG_WarnPitchAngle;//俯仰角
//			__vehicleData[__index++] = this->m_PG_WarnRollAngle;//侧倾角
//		}
	}
}

void CANMessageManagement_GB::AppendPGPeriodWarnPacket(guchar* __vehicleData, guint& __index)
{
	YDLOG(YD_DEBUG, "CANMessage_GB", "warn level 5\n");
	//报警数据
	__vehicleData[__index++] = 0xF5;
	__vehicleData[__index++] = this->m_PG_WarnTire;//胎压预警
	__vehicleData[__index++] = this->m_PG_WarnOxygen;//发动机后置氧传感器需要诊断援助
//	__vehicleData[__index++] = this->m_PG_WarnBrake;//刹车过热
	__vehicleData[__index++] = this->m_PG_WarnGearBox;//变速箱预警
//	__vehicleData[__index++] = this->m_PG_WarnClutch;//离合器预警
	__vehicleData[__index++] = this->m_PG_WarnPitchAngle;//俯仰角
	__vehicleData[__index++] = this->m_PG_WarnRollAngle;//侧倾角
}

void CANMessageManagement_GB::AppendPGWarnPacket_Minor(guchar* __vehicleData, guint& __index)
{
	//轻微故障
	__vehicleData[__index++] = 0xF1;
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = this->m_PG_MinorWarn1;//刹车片磨损指示
	__vehicleData[__index++] = 0x02;
	__vehicleData[__index++] = this->m_PG_MinorWarn2;//发动机机油更换指示
	__vehicleData[__index++] = 0x03;
	__vehicleData[__index++] = this->m_PG_MinorWarn3;//发动机机油热指示
	__vehicleData[__index++] = 0x04;
	__vehicleData[__index++] = this->m_PG_MinorWarn4;//发动机机油压力低指示
}

void CANMessageManagement_GB::AppendPGWarnPacket_normal(guchar* __vehicleData, guint& __index)
{
	//一般故障
	__vehicleData[__index++] = 0xF2;
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = this->m_PG_NormalWarn1;//12伏电池系统不稳定指示
	__vehicleData[__index++] = 0x02;
	__vehicleData[__index++] = this->m_PG_NormalWarn2;//空调压缩机故障指示
	__vehicleData[__index++] = 0x03;
	__vehicleData[__index++] = this->m_PG_NormalWarn3;//主动振动故障指示
	__vehicleData[__index++] = 0x04;
	__vehicleData[__index++] = this->m_PG_NormalWarn4;//巡航暂时不可用指示
	__vehicleData[__index++] = 0x05;
	__vehicleData[__index++] = this->m_PG_NormalWarn5;//刹车过热指示
	__vehicleData[__index++] = 0x06;
	__vehicleData[__index++] = this->m_PG_NormalWarn6;//压缩机驱动故障状态指示
	__vehicleData[__index++] = 0x07;
	__vehicleData[__index++] = this->m_PG_NormalWarn7;//压缩机高压异常状态指示
	__vehicleData[__index++] = 0x08;
	__vehicleData[__index++] = this->m_PG_NormalWarn8;//压缩机内部可恢复故障指示
	__vehicleData[__index++] = 0x09;
	__vehicleData[__index++] = this->m_PG_NormalWarn9;//压缩机内部关闭故障指示
	__vehicleData[__index++] = 0x0A;
	__vehicleData[__index++] = this->m_PG_NormalWarn10;//压缩机电机性能故障指示
	__vehicleData[__index++] = 0x0B;
	__vehicleData[__index++] = this->m_PG_NormalWarn11;//压缩机输出过载指示
	__vehicleData[__index++] = 0x0C;
	__vehicleData[__index++] = this->m_PG_NormalWarn12;//压缩机过热指示
	__vehicleData[__index++] = 0x0D;
	__vehicleData[__index++] = this->m_PG_NormalWarn13;//过温警告指示
	__vehicleData[__index++] = 0x0E;
	__vehicleData[__index++] = this->m_PG_NormalWarn14;//发动机扭矩减小故障
	__vehicleData[__index++] = 0x0F;
	__vehicleData[__index++] = this->m_PG_NormalWarn15;//电动驻车系统警告指示
	__vehicleData[__index++] = 0x10;
	__vehicleData[__index++] = this->m_PG_NormalWarn16;//燃油系统非排放相关故障指示
	__vehicleData[__index++] = 0x11;
	__vehicleData[__index++] = this->m_PG_NormalWarn17;//变速离合器故障指示
	__vehicleData[__index++] = 0x12;
	__vehicleData[__index++] = this->m_PG_NormalWarn18;//变速箱液力变矩器离合器命令模式故障指示
	__vehicleData[__index++] = 0x13;
	__vehicleData[__index++] = this->m_PG_NormalWarn19;//变速箱热管理
}

void CANMessageManagement_GB::AppendPGWarnPacket_Serious(guchar* __vehicleData, guint& __index)
{
	//严重故障
	__vehicleData[__index++] = 0xF3;
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = this->m_PG_SeriousWarn1;//自动变速器换挡方向故障指示
	__vehicleData[__index++] = 0x02;
	__vehicleData[__index++] = this->m_PG_SeriousWarn2;//智能电池传感器内部故障指示
	__vehicleData[__index++] = 0x03;
	__vehicleData[__index++] = this->m_PG_SeriousWarn3;//碰撞准备系统失败指示
	__vehicleData[__index++] = 0x04;
	__vehicleData[__index++] = this->m_PG_SeriousWarn4;//碰撞准备系统不可用指示
	__vehicleData[__index++] = 0x05;
	__vehicleData[__index++] = this->m_PG_SeriousWarn5;//检测到驾驶员油门超驰
	__vehicleData[__index++] = 0x06;
	__vehicleData[__index++] = this->m_PG_SeriousWarn6;//燃油控制系统故障指示
	__vehicleData[__index++] = 0x07;
	__vehicleData[__index++] = this->m_PG_SeriousWarn7;//燃油喷射器控制模块注入故障指示
	__vehicleData[__index++] = 0x08;
	__vehicleData[__index++] = this->m_PG_SeriousWarn8;//燃油系统排放相关故障指示
}

void CANMessageManagement_GB::AppendPGWarnPacket_Deadly(guchar* __vehicleData, guint& __index)
{
	//致命故障
	__vehicleData[__index++] = 0xF4;
	__vehicleData[__index++] = 0x01;
	__vehicleData[__index++] = this->m_PG_DeadlyWarn1;//制动系统故障指示
	__vehicleData[__index++] = 0x02;
	__vehicleData[__index++] = this->m_PG_DeadlyWarn2;//发动机失败指示
}

void CANMessageManagement_GB::AppendPGWarnPacket_Alarm(guchar* __vehicleData, guint& __index)
{
	//报警数据
	__vehicleData[__index++] = 0xF5;
	__vehicleData[__index++] = this->m_PG_WarnTire;//胎压预警
	__vehicleData[__index++] = this->m_PG_WarnOxygen;//发动机后置氧传感器需要诊断援助
//	__vehicleData[__index++] = this->m_PG_WarnBrake;//刹车过热
	__vehicleData[__index++] = this->m_PG_WarnGearBox;//变速箱预警
//	__vehicleData[__index++] = this->m_PG_WarnClutch;//离合器预警
	__vehicleData[__index++] = this->m_PG_WarnPitchAngle;//俯仰角
	__vehicleData[__index++] = this->m_PG_WarnRollAngle;//侧倾角
}

void CANMessageManagement_GB::SetWarnFlag(uint8_t __WarnFlag)
{
	for(guint _i=0;_i<this->m_PG_WarnFlag.size();_i++) {
		if(m_PG_WarnFlag[_i] == __WarnFlag) {
			return;
		}
	}
	{
		std::unique_lock<std::mutex>(m_mutex);
		this->m_PG_WarnFlag.push_back(__WarnFlag);
	}
}

std::vector<uint8_t> CANMessageManagement_GB::GetWarnFlag()
{
	return this->m_PG_WarnFlag;
}

void CANMessageManagement_GB::InitWarn()
{
	std::unique_lock<std::mutex>(m_mutex);
	this->m_PG_WarnFlag.clear();
//	//轻微故障--20181128
//	this->m_PG_MinorWarn1 = 0xFF;//刹车片磨损指示
//	this->m_PG_MinorWarn2 = 0xFF;//发动机机油更换指示
//	this->m_PG_MinorWarn3 = 0xFF;//发动机机油热指示
//	this->m_PG_MinorWarn4 = 0xFF;//发动机机油压力低指示
//	//一般故障--20181128
//	this->m_PG_NormalWarn1 = 0xFF;//12伏电池系统不稳定指示
//	this->m_PG_NormalWarn2 = 0xFF;//空调压缩机故障指示
//	this->m_PG_NormalWarn3 = 0xFF;//主动振动故障指示
//	this->m_PG_NormalWarn4 = 0xFF;//巡航暂时不可用指示
//	this->m_PG_NormalWarn5 = 0xFF;//刹车过热指示
//	this->m_PG_NormalWarn6 = 0xFF;//压缩机驱动故障状态指示
//	this->m_PG_NormalWarn7 = 0xFF;//压缩机高压异常状态指示
//	this->m_PG_NormalWarn8 = 0xFF;//压缩机内部可恢复故障指示
//	this->m_PG_NormalWarn9 = 0xFF;//压缩机内部关闭故障指示
//	this->m_PG_NormalWarn10 = 0xFF;//压缩机电机性能故障指示
//	this->m_PG_NormalWarn11 = 0xFF;//压缩机输出过载指示
//	this->m_PG_NormalWarn12 = 0xFF;//压缩机过热指示
//	this->m_PG_NormalWarn13 = 0xFF;//过温警告指示
//	this->m_PG_NormalWarn14 = 0xFF;//发动机扭矩减小故障
//	this->m_PG_NormalWarn15 = 0xFF;//电动驻车系统警告指示
//	this->m_PG_NormalWarn16 = 0xFF;//燃油系统非排放相关故障指示
//	this->m_PG_NormalWarn17 = 0xFF;//变速离合器故障指示
//	this->m_PG_NormalWarn18 = 0xFF;//变速箱液力变矩器离合器命令模式故障指示
//	this->m_PG_NormalWarn19 = 0xFF;//变速箱热管理
//	//严重故障--20181128
//	this->m_PG_SeriousWarn1 = 0xFF;//自动变速器换挡方向故障指示
//	this->m_PG_SeriousWarn2 = 0xFF;//智能电池传感器内部故障指示
//	this->m_PG_SeriousWarn3 = 0xFF;//碰撞准备系统失败指示
//	this->m_PG_SeriousWarn4 = 0xFF;//碰撞准备系统不可用指示
//	this->m_PG_SeriousWarn5 = 0xFF;//检测到驾驶员油门超驰
//	this->m_PG_SeriousWarn6 = 0xFF;//燃油控制系统故障指示
//	this->m_PG_SeriousWarn7 = 0xFF;//燃油喷射器控制模块注入故障指示
//	this->m_PG_SeriousWarn8 = 0xFF;//燃油系统排放相关故障指示
//	//致命故障
//	this->m_PG_DeadlyWarn1 = 0xFF;//制动系统故障指示
//	this->m_PG_DeadlyWarn2 = 0xFF;//发动机失败指示

	//1210成都修改协议，下方的预警采用周期上报而非原有的触发式上报
//	this->m_PG_WarnTire = 0xFF;//胎压预警
//	this->m_PG_WarnOxygen = 0xFF;//发动机后置氧传感器需要诊断援助
//	this->m_PG_WarnBrake = 0xFF;//刹车过热
//	this->m_PG_WarnGearBox = 0xFF;//变速箱预警
//	this->m_PG_WarnClutch = 0xFF;//离合器预警
//	this->m_PG_WarnPitchAngle = 0xFF;//俯仰角
//	this->m_PG_WarnRollAngle = 0xFF;//侧倾角
}

// Test: dataupload
void CANMessageManagement_GB::DataUploadTest()
{
	this->m_PG_CarStat = 0x01;//车辆状态
	this->m_PG_ChargeStat = 0xFF;//充电状态×
	this->m_PG_Speed = 100;//车速
	this->m_PG_TotalMile = 10000;//累计里程
	this->m_PG_TotalVol = 0xFFFF;//总电压×
	this->m_PG_TotalEle = 0xFFFF;//总电流×
	this->m_PG_SOC = 0xFF;//SOC状态×
	this->m_PG_DC2 = 0xFF;//DC-DC状态×
	this->m_PG_Gear = 3;//档位
	this->m_PG_Resis = 0xFFFF;//绝缘电阻×
	this->m_PG_AccPedal = 50;//加速踏板行程
	this->m_PG_BrakePedal = 50;//制动踏板行程
	this->m_PG_TurnLight = 1;//转向灯
	this->m_PG_VerticalAcc = 10;//纵向加速度
	this->m_PG_CrossAcc = 10;//侧向加速度
	this->m_PG_IMUSpeed = 0xFFFF;//IMU横摆角速度×
	this->m_PG_WheelAngel = 100;//方向盘转角
	this->m_PG_WheelSpeed = 100;//方向盘转速
	this->m_PG_ActualAcc = 0xFFFF;//实际加速度×
	this->m_PG_ActualAccBool = 0xFF;//实际加速度有效×
	this->m_PG_YawAcc = 100;//车身横摆角速度
	this->m_PG_AbsActive = 1;//防抱死制动系统激活
	this->m_PG_AbsFailure = 1;//防抱死制动系统失败
	this->m_PG_SpeedLimitStat = 1;//巡航和限速系统开关状态
	this->m_PG_BrakeStateSig = 1;//制动状态信号
	this->m_PG_KeyGear = 0xFF;//钥匙档位×
	this->m_PG_TirePreLow = 1;//轮胎低压指示
	this->m_PG_DaiSu = 0xFF;//怠速状态×
	this->m_PG_PassBelt = 0xFF;//乘客安全带状态×
	this->m_PG_DriverBelt = 1;//驾驶员安全带状态
	this->m_PG_ValidPosition = 0;//定位状态
	this->m_PG_Longitude = 12345;//经度
	this->m_PG_Latitude = 12345;//纬度
	this->m_PG_EngineStat = 2;//发动机状态
	this->m_PG_QuZhou = 0xFFFF;//曲轴转速×
	this->m_PG_oilSpeed = 0xFFFF;//瞬时油耗×
	this->m_PG_RemainOil = 0xFFFF;//剩余油量×
	this->m_PG_DoorLockMode = 0xFF;//门锁状态
	this->m_PG_WindowMode = 0xFF;//门窗状态×
	this->m_PG_CarLight = 1;//车灯
	this->m_PG_Engine = 1;//发动机
	this->m_PG_WaterTemperature = 0xFF;//水温×
	this->m_PG_AirConditioner = 0xFF;//空调×
	this->m_PG_BatteryMode = 0xFF;//动力电池故障严重状态×
	this->m_PG_ContinueMile = 0xFF;//续航里程×
	this->m_PG_HandBrake = 0xFF;//手刹×
	this->m_PG_Wiper = 0xFF;//雨刮×
}



//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
CANMessageManagement_GB* CANMessageManagement_GB::m_instance = NULL;

CANMessageManagement_GB::CANMessageManagement_GB():CANMessageManagement()
{
	this->m_PG_CarStat = 0xFF;//车辆状态
	this->m_PG_ChargeStat = 0xFF;//充电状态×
	this->m_PG_Speed = 0xFFFF;//车速
	this->m_PG_TotalMile = 0xFFFFFFFF;//累计里程
	this->m_PG_TotalVol = 0xFFFF;//总电压×
	this->m_PG_TotalEle = 0xFFFF;//总电流×
	this->m_PG_SOC = 0xFF;//SOC状态×
	this->m_PG_DC2 = 0xFF;//DC-DC状态×
	this->m_PG_Gear = 0xFF;//档位
	this->m_PG_Resis = 0xFFFF;//绝缘电阻×
	this->m_PG_AccPedal = 0xFF;//加速踏板行程
	this->m_PG_BrakePedal = 0xFF;//制动踏板行程
	this->m_PG_TurnLight = 0xFF;//转向灯
	this->m_PG_VerticalAcc = 0xFFFF;//纵向加速度
	this->m_PG_CrossAcc = 0xFFFF;//侧向加速度
	this->m_PG_IMUSpeed = 0xFFFF;//IMU横摆角速度×
	this->m_PG_WheelAngel = 0xFFFF;//方向盘转角
	this->m_PG_WheelSpeed = 0xFFFF;//方向盘转速
	this->m_PG_ActualAcc = 0xFFFF;//实际加速度×
	this->m_PG_ActualAccBool = 0xFF;//实际加速度有效×
	this->m_PG_YawAcc = 0xFFFF;//车身横摆角速度
	this->m_PG_AbsActive = 0xFF;//防抱死制动系统激活
	this->m_PG_AbsFailure = 0xFF;//防抱死制动系统失败
	this->m_PG_SpeedLimitStat = 0xFF;//巡航和限速系统开关状态
	this->m_PG_BrakeStateSig = 0xFF;//制动状态信号
	this->m_PG_KeyGear = 0xFF;//钥匙档位×
	this->m_PG_TirePreLow = 0xFF;//轮胎低压指示
	this->m_PG_DaiSu = 0xFF;//怠速状态×
	this->m_PG_PassBelt = 0xFF;//乘客安全带状态×
	this->m_PG_DriverBelt = 0xFF;//驾驶员安全带状态
	this->m_PG_ValidPosition = 0xFF;//定位状态
	this->m_PG_Longitude = 0xFFFFFFFF;//经度
	this->m_PG_Latitude = 0xFFFFFFFF;//纬度
	this->m_PG_EngineStat = 0xFF;//发动机状态
	this->m_PG_QuZhou = 0xFF;//曲轴转速×
	this->m_PG_oilSpeed = 0xFF;//瞬时油耗×
	this->m_PG_RemainOil = 0xFFFF;//剩余油量×
	this->m_PG_DoorLockMode = 0xFF;//门锁状态
	this->m_PG_WindowMode = 0xFF;//门窗状态×
	this->m_PG_CarLight = 0xFF;//车灯
	this->m_PG_Engine = 0xFF;//发动机
	this->m_PG_WaterTemperature = 0xFF;//水温×
	this->m_PG_AirConditioner = 0xFF;//空调×
	this->m_PG_BatteryMode = 0xFF;//动力电池故障严重状态
	this->m_PG_ContinueMile = 0xFF;//续航里程×
	this->m_PG_HandBrake = 0xFF;//手刹×
	this->m_PG_Wiper = 0xFF;//雨刮×

	this->m_PG_ResLock = 0xFF;//门锁响应
	this->m_PG_ResFind = 0xFF;//寻车响应
	this->m_PG_ResAirCond = 0xFF;//空调响应

	//20181128新增
	//轻微故障--20181128
	this->m_PG_MinorWarn1 = 0xFF;//刹车片磨损指示
	this->m_PG_MinorWarn2 = 0xFF;//发动机机油更换指示
	this->m_PG_MinorWarn3 = 0xFF;//发动机机油热指示
	this->m_PG_MinorWarn4 = 0xFF;//发动机机油压力低指示
	//一般故障--20181128
	this->m_PG_NormalWarn1 = 0xFF;//12伏电池系统不稳定指示
	this->m_PG_NormalWarn2 = 0xFF;//空调压缩机故障指示
	this->m_PG_NormalWarn3 = 0xFF;//主动振动故障指示
	this->m_PG_NormalWarn4 = 0xFF;//巡航暂时不可用指示
	this->m_PG_NormalWarn5 = 0xFF;//刹车过热指示
	this->m_PG_NormalWarn6 = 0xFF;//压缩机驱动故障状态指示
	this->m_PG_NormalWarn7 = 0xFF;//压缩机高压异常状态指示
	this->m_PG_NormalWarn8 = 0xFF;//压缩机内部可恢复故障指示
	this->m_PG_NormalWarn9 = 0xFF;//压缩机内部关闭故障指示
	this->m_PG_NormalWarn10 = 0xFF;//压缩机电机性能故障指示
	this->m_PG_NormalWarn11 = 0xFF;//压缩机输出过载指示
	this->m_PG_NormalWarn12 = 0xFF;//压缩机过热指示
	this->m_PG_NormalWarn13 = 0xFF;//过温警告指示
	this->m_PG_NormalWarn14 = 0xFF;//发动机扭矩减小故障
	this->m_PG_NormalWarn15 = 0xFF;//电动驻车系统警告指示
	this->m_PG_NormalWarn16 = 0xFF;//燃油系统非排放相关故障指示
	this->m_PG_NormalWarn17 = 0xFF;//变速离合器故障指示
	this->m_PG_NormalWarn18 = 0xFF;//变速箱液力变矩器离合器命令模式故障指示
	this->m_PG_NormalWarn19 = 0xFF;//变速箱热管理
	//严重故障--20181128
	this->m_PG_SeriousWarn1 = 0xFF;//自动变速器换挡方向故障指示
	this->m_PG_SeriousWarn2 = 0xFF;//智能电池传感器内部故障指示
	this->m_PG_SeriousWarn3 = 0xFF;//碰撞准备系统失败指示
	this->m_PG_SeriousWarn4 = 0xFF;//碰撞准备系统不可用指示
	this->m_PG_SeriousWarn5 = 0xFF;//检测到驾驶员油门超驰
	this->m_PG_SeriousWarn6 = 0xFF;//燃油控制系统故障指示
	this->m_PG_SeriousWarn7 = 0xFF;//燃油喷射器控制模块注入故障指示
	this->m_PG_SeriousWarn8 = 0xFF;//燃油系统排放相关故障指示
	//致命故障
	this->m_PG_DeadlyWarn1 = 0xFF;//制动系统故障指示
	this->m_PG_DeadlyWarn2 = 0xFF;//发动机失败指示

	this->m_PG_WarnTire = 0xFF;//胎压预警
	this->m_PG_WarnOxygen = 0xFF;//发动机后置氧传感器需要诊断援助
	this->m_PG_WarnBrake = 0xFF;//刹车过热
	this->m_PG_WarnGearBox = 0xFF;//变速箱预警
	this->m_PG_WarnClutch = 0xFF;//离合器预警
	this->m_PG_WarnPitchAngle = 0xFF;//俯仰角
	this->m_PG_WarnRollAngle = 0xFF;//侧倾角

	m_PG_WarnFlag.clear();
//	this->m_PG_WarnFlag = 0;

	// Test: 本地联调Tbox时使用
//	DataUploadTest(); // 20200424在模拟服务器上自测成功
}

