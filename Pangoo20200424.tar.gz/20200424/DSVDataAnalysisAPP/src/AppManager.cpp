#include <unistd.h>
#include "AppManager.h"
#include "DSVLog.h"

AppManager::AppManager()
{
}

AppManager::~AppManager()
{
}

void AppManager::StartApp()
{
	this->m_mcuSerial = std::make_shared<McuSerial>();
	this->m_dataPacket = std::make_shared<Packet>();
	this->InitManager();
}


// init handle from mcu, if failed wait for 5s
void AppManager::InitManager()
{
	while (true) {
		std::unique_lock<std::mutex>(m_mutex);
		int retSum = 0;
		if (InitReadWorker()) {
			retSum += 1;
		}
		if (InitWriteWorker()) {
			retSum += 1;
		}
		if (retSum == 2) {
			YDLOG(YD_INFO, "AppManager", "Init success\n");
			break;
		}
		YDLOG(YD_INFO, "AppManager", "Init fail, Wait 5s,Init again\n");
		sleep(5);
	}
}

// read data from mcu
bool AppManager::InitReadWorker()
{
	if(this->m_mcuSerial->Init()) {
		return true;
	}
	return false;
}

// package data from mcu
bool AppManager::InitWriteWorker()
{
	if(this->m_dataPacket->Init()) {
		this->m_dataPacket->StartDataCollection();
		return true;
	}
	return false;
}
