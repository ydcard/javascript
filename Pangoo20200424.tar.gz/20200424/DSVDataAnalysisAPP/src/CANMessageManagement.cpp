#include "CANMessageManagement.h"

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

CANMessageManagement::CANMessageManagement()
{
	this->m_init=false;
	this->m_packetTimePower = 10; // 表示上传周期为10s
}

CANMessageManagement::~CANMessageManagement()
{
}

/**
 * @param   void
 * @return  true or false
 * @retval  gboolean
 * @note
 **/
gboolean CANMessageManagement::GetInitState()
{
	// Test
	InitFinish();
	return this->m_init;
}

/**
 * @param   void
 * @return  null
 * @retval  void
 * @note
 **/
void CANMessageManagement::InitFinish()
{
	this->m_init=true;
}

/**
 * @param
 * @return  timePower
 * @retval  guint
 * @note    获得打包时间倍率
 **/
guint CANMessageManagement::GetPacketTimePower()
{
	return this->m_packetTimePower;
}

/**
 * @param   guint __packetTimePower
 * @return  null
 * @retval  void
 * @note    设置打包时间倍率
 **/
void CANMessageManagement::SetPacketTimePower(guint __packetTimePower)
{
	this->m_packetTimePower=__packetTimePower;
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
