/*
 * FileOP.cpp
 *
 *  Created on: 2017年6月5日
 *      Author: ghy
 *      Editor: huangwenchao
 */

#include <fstream>
#include <algorithm>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sqlite3.h>
#include "FileOP.h"
#include "ToolUtils.h"

//#define FINISH_DIR "/media/card/SAVEDFILE/"
//#define RESEND_DIR "/media/card/RESENTFILE/"
#define FINISH_DIR "/app/card/SAVEDFILE/"     // YINDI:改变存储位置
#define RESEND_DIR "/app/card/RESENTFILE/"    // YINDI:改变存储位置
#define RESEND_COUNT 10
#define RESEND_COUNT_RESET_COUNT 5

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

FileOP::~FileOP()
{
}

/**
* @param   void
* @return  class
* @retval  FileOP*
* @note    单例
**/
FileOP* FileOP::GetInstance() {
	if(FileOP::m_instance==NULL) {
		FileOP::m_instance = new FileOP();
	}
	return FileOP::m_instance;
}

/**
* @param   std::string __reSentData
* @return  void
* @retval  null
* @note    补发数据写入文件
**/
void FileOP::WriteReSentData(std::string __reSentData, guint __hasBeenSend)
{
	printf("YINDI:write\n");
	//每次运行会清除7天之前的文件,FIXME: 这里因为Tbox的时间同步有问题,暂时将这里注释
//	this->TryToTestReSentDirAndDelMax7DayFiles();
	gchar _fileName[50] = {0};
	std::string _writefileName(__reSentData,0,6);
	if(_writefileName>"63FFFF") {
		printf("YINDI:end\n");
		//不保存年份后两位大于99的年
		return;
	}
	std::string _createTime(__reSentData,0,12);
	sprintf(_fileName, "%s%s",RESEND_DIR,_writefileName.c_str());
	sqlite3* _db;
	gchar* _zErrMsg = 0;
	gint _rc;
	if(access(_fileName, 0) == -1) {
		_rc = sqlite3_open(_fileName, &_db);
//		chmod(_fileName, 0777);
		if(_rc == SQLITE_OK){
			_rc = sqlite3_exec(_db, "CREATE TABLE resend_data(id INTEGER PRIMARY KEY AUTOINCREMENT,create_time VARCHAR(32),data VARCHAR(512),send_count INTEGER(11) DEFAULT 0,is_finish VARCHAR(1) DEFAULT 0)",NULL,NULL, &_zErrMsg);
			if(_rc == SQLITE_OK ){
				_rc = sqlite3_exec(_db, "CREATE INDEX create_time_index ON resend_data(create_time)",NULL,NULL, &_zErrMsg);
				_rc = sqlite3_exec(_db, "CREATE INDEX is_finsh_index ON resend_data(is_finish)",NULL,NULL, &_zErrMsg);
				if(_rc == SQLITE_OK){
					this->InsertIntoDb(_db, _createTime, __reSentData, __hasBeenSend);
				}
				else {
					sqlite3_free(_zErrMsg);
				}
			}
			else {
				sqlite3_free(_zErrMsg);
			}
		}
		else {
		}
		sqlite3_close(_db);
	}
	else {
		_rc = sqlite3_open(_fileName, &_db);
		if(_rc == SQLITE_OK){
			this->InsertIntoDb(_db, _createTime, __reSentData, __hasBeenSend);
		}
		else {
			printf("DSVDataAnalysisApp, error:FileOP db create fail in every open%d", _rc);
		}
		sqlite3_close(_db);
	}
}

/**
* @param   void
* @return  0～30行数据
* @retval  std::vector<std::string>
* @note    从文件读取30行补发数据
**/
std::vector<std::string> FileOP::ReadReSentData()
{
	std::vector<std::string> _vecUnSentData;
	DIR* _dir;
	if ((_dir = opendir(RESEND_DIR)) == NULL){
		printf("YINDI:fail to read database\n");
		return _vecUnSentData;
	}
	dirent* _dirp;
	std::vector<std::string> _listDirFile;
	while (((_dirp = readdir(_dir)) != NULL)) {
		if (strcmp(_dirp->d_name, ".") == 0 || strcmp(_dirp->d_name, "..") == 0) {
			continue;
		}
		_listDirFile.push_back(_dirp->d_name);
	}
	closedir(_dir);
	std::sort(_listDirFile.begin(), _listDirFile.end());
	std::vector<std::string>::iterator _iter;
	if(this->m_canReadCountResetCount>=1) { // 被连续调用6次之后进行一次调用
		this->m_canReadCountResetCount--;
	}
	else {
		this->m_canReadCount=RESEND_COUNT;
		this->m_canReadCountResetCount=RESEND_COUNT_RESET_COUNT;
		for(_iter=_listDirFile.begin(); _iter!=_listDirFile.end(); _iter++) {
			std::string _name=(std::string)*_iter;
			gchar _fileName[32] = {0};
			sprintf(_fileName, "%s%s", RESEND_DIR, _name.c_str());
			if(access(_fileName, 0) != -1) {
				printf("YINDI: read data\n");
				sqlite3* _db;
				gint _rc = sqlite3_open(_fileName, &_db);
				if(_rc == SQLITE_OK){
					if(this->m_canReadCount<1) {
						sqlite3_close(_db);
						break;
					}
					SelectItemsFromDb(_db, &_vecUnSentData, (gushort)this->m_canReadCount);
					this->m_canReadCount=this->m_canReadCount-_vecUnSentData.size();
				}
				else {
					printf("DSVDataAnalysisApp, xchao_error:FileOP db read fail in open%d", _rc);
				}
				sqlite3_close(_db);
			}
			else {
				printf("DSVDataAnalysisApp, xchao_error:FileOP db read fail in null");
			}
		}
	}
	return _vecUnSentData;
}

/**
* @param   std::string dataTime
* @return  void
* @retval  null
* @note    删除补发的数据
**/
void FileOP::DelOrOpenReSentData(std::string __dataTime, guint __isDel)
{
	std::string _fileNameDate(__dataTime,0,6);
	gchar _fileName[50];
	sprintf(_fileName,"%s%s",RESEND_DIR,_fileNameDate.c_str());
	if(access(_fileName, 0) != -1) {
		sqlite3* _db;
		gint _rc = sqlite3_open(_fileName, &_db);
		if(_rc == SQLITE_OK){
			std::string _createTime(__dataTime,0,12);
			this->DeleteItemFromDb(_db, _createTime, __isDel);
		}
		else {
			printf("DSVDataAnalysisApp, xchao_error:FileOP db delete fail in open%d", _rc);
		}
		sqlite3_close(_db);
	}
	else {
		printf("DSVDataAnalysisApp, xchao_error:FileOP db delete fail in null");
	}
}

/**
* @param   std::string __finishData
* @return  void
* @retval  null
* @note    已发数据写入文件
**/
void FileOP::WriteFinishData(std::string __finishData) const
{
	gchar _fileName[50];
	std::string _writefileName(__finishData,0,6);
	if(_writefileName>"63FFFF") {
		//不保存年份后两位大于99的年
		return;
	}
	sprintf(_fileName, "%s%s",FINISH_DIR,_writefileName.c_str());
	//这边不能用std::ofstream方式，遇到意外断电将不会及时更新磁盘文件
	gint _fd = -1;
	__finishData.append("\n");
	_fd = open(_fileName,O_WRONLY|O_CREAT|O_SYNC|O_APPEND,S_IRWXU|S_IRWXG|S_IRWXO);
	write(_fd,__finishData.c_str(),__finishData.size());
	close(_fd);
	//每次运行会清除7个之前的文件
	this->TryToDelFinishDataMax7CountFiles();
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
FileOP* FileOP::m_instance=NULL;

FileOP::FileOP()
{
	this->m_canReadCount=RESEND_COUNT;
	this->m_canReadCountResetCount=RESEND_COUNT_RESET_COUNT;
	this->TryToTestReSentDirAndDelMax7DayFiles();
	this->TryToDelFinishDataMax7CountFiles();
}

/**
* @param   DIR* __dp, const gchar* __dirPath
* @return  void
* @retval  null
* @note    清除7个之前的入库文件
**/
void FileOP::TryToDelFinishDataMax7CountFiles() const
{
	std::vector<std::string> _fileNameArray;
	dirent* _dirp;
	DIR* _dir;
	if ((_dir = opendir(FINISH_DIR)) == NULL){
		gint _isCreate = mkdir(FINISH_DIR,S_IRUSR | S_IWUSR | S_IXUSR | S_IRWXG | S_IRWXO);
		if(_isCreate!=0) {
			printf("DSVDataAnalysisApp, xchao_error:FileOP can't create %s", FINISH_DIR);
			return;
		}
		_dir = opendir(FINISH_DIR);
	}
	while (((_dirp = readdir(_dir)) != NULL)) {
		if (strcmp(_dirp->d_name, ".") == 0 || strcmp(_dirp->d_name, "..") == 0) {
			continue;
		}
		std::string _p=_dirp->d_name;
		if(_p >"63FFFF") {
			//删除错误的文件年份后两位大于99的年
			std::string _delFileName = FINISH_DIR + _p;
			remove(_delFileName.c_str());
			continue;
		}
		_fileNameArray.push_back(_p);
	}
	closedir(_dir);
	if(_fileNameArray.size() > 7){
		std::sort(_fileNameArray.begin(),_fileNameArray.end());
		std::vector<std::string>::iterator _iter = _fileNameArray.begin();
		std::string _delFileName = FINISH_DIR + (std::string)(*_iter);
		remove(_delFileName.c_str());
	}
}

/**
* @param   const gchar* __dirPath
* @return  0 or 1
* @retval  gboolean
* @note    清除7天之前的补发文件
**/
void FileOP::TryToTestReSentDirAndDelMax7DayFiles() const
{
	std::vector<std::string> _fileNameArray;
	dirent* _dirp;
	DIR* _dir;
	if ((_dir = opendir(RESEND_DIR)) == NULL){
		gint _isCreate = mkdir(RESEND_DIR,S_IRUSR | S_IWUSR | S_IXUSR | S_IRWXG | S_IRWXO);
		if(_isCreate!=0) {
			printf("DSVDataAnalysisApp, xchao_error:FileOP can't create %s", RESEND_DIR);
			return;
		}
		_dir = opendir(RESEND_DIR);
	}
	while (((_dirp = readdir(_dir)) != NULL)) {
		if (strcmp(_dirp->d_name, ".") == 0 || strcmp(_dirp->d_name, "..") == 0) {
			continue;
		}
		gchar* _p = _dirp->d_name;
		_fileNameArray.push_back(_p);
	}
	closedir(_dir);
	ToolUtils* _toolUtils=ToolUtils::GetInstance();
	timeval _tv;
	tm _p;
	_toolUtils->SysUsecTime(_tv, _p, 8*3600-7*3600*24);
	guint _number = 0;
	guchar* _minDay = new guchar[10];
	_minDay[_number++] = (_p.tm_year-100) & 0xFF;
	_minDay[_number++] = (1+_p.tm_mon) & 0xFF;
	_minDay[_number++] = _p.tm_mday & 0xFF;
	_minDay[_number++] = _p.tm_hour & 0xFF;
	std::string _minDayName=ToolUtils::GetInstance()->ByteToHexStr(_minDay, _number);
	delete _minDay;
	std::vector<std::string>::iterator _iter;
	for(_iter=_fileNameArray.begin(); _iter!=_fileNameArray.end(); _iter++) {
		std::string _tryDelFileName=(std::string)(*_iter);
		//删除7天前的和名称不为6个长度的错误文件
		if(_tryDelFileName<_minDayName||_tryDelFileName.length()!=6) {
			gchar _delFileName[50];
			sprintf(_delFileName,"%s%s",RESEND_DIR,_tryDelFileName.c_str());
			remove(_delFileName);
		}
	}
}

/**
* @param   sqlite3* __db, std::string __time, std::string __data
* @return  null
* @retval  void
* @note    条目插入数据库
**/
void FileOP::InsertIntoDb(sqlite3* __db, std::string __time, std::string __data, guint __isFinish)
{
	printf("insert db\n");
	gchar _sqlPacket[__data.length() + 256] = {0};
	sprintf(_sqlPacket, "INSERT INTO resend_data (create_time,data,send_count,is_finish) VALUES (\"%s\",\"%s\",%d,%d)",__time.c_str(),__data.c_str(), 0, __isFinish);
	gchar* _zErrMsg = 0;
	guint _retryCount = 0;
	while(_retryCount < 20) {//重试20次，20次后丢弃该操作
		_retryCount++;
		gint _rc = sqlite3_exec(__db, _sqlPacket, NULL, NULL, &_zErrMsg);
		if(_rc == SQLITE_OK) {
			printf("success insert\n");
			return;
		}
		printf("DSVDataAnalysisApp, xchao_alarm:FileOP db insert into fail%d readyToRedo_Count%d", _rc, _retryCount);
		usleep(5000 * _retryCount * _retryCount);//指数方式递增重试等待
	}
	printf("DSVDataAnalysisApp, xchao_error:FileOP db insert into fail");
}

/**
* @param   sqlite3* __db, std::string __time
* @return  null
* @retval  void
* @note    删除数据库中某一条目
**/
void FileOP::DeleteItemFromDb(sqlite3* __db, std::string __time, guint __isDel)
{
	gchar _sqlPacket[__time.length() + 128] = {0};
	sprintf(_sqlPacket, "UPDATE resend_data SET is_finish=%d WHERE create_time=\"%s\"", __isDel,__time.c_str());
	gchar* _zErrMsg = 0;
	guint _retryCount = 0;
	while(_retryCount < 20) {//重试20次，20次后丢弃该操作
		_retryCount++;
		gint _rc = sqlite3_exec(__db, _sqlPacket, NULL, NULL, &_zErrMsg);
		if(_rc == SQLITE_OK) {
			return;
		}
		printf("DSVDataAnalysisApp, xchao_alarm:FileOP db delete fail%d readyToRedo_Count%d", _rc, _retryCount);
		usleep(5000 * _retryCount * _retryCount);//指数方式递增重试等待
	}
	printf("DSVDataAnalysisApp, xchao_error:FileOP db delete fail");
}

/**
* @param   sqlite3* __db, std::vector<std::string>& __list, guint __count
* @return  null
* @retval  void
* @note    获取数据库中N条以内的数据
**/
void FileOP::SelectItemsFromDb(sqlite3* __db, std::vector<std::string>* __list, gushort __count)
{
	auto _callback=[](void* __data, gint __argc, gchar** __argv, gchar** __azColName)->gint{
		ReadSql* _readSql=(ReadSql*)__data;
		for(gint _i=0; _i<__argc; _i++){
			if(strcmp(__azColName[_i], "data") == 0) {
				_readSql->Append(__argv[_i]);
			}
		}
		return 0;
	};
	gchar _sqlPacket[128] = {0};
	sprintf(_sqlPacket, "SELECT id,data,send_count FROM resend_data WHERE is_finish=0 LIMIT 0,%d",__count);
	gchar* _zErrMsg = 0;
	ReadSql* _readSql=new ReadSql(__list);
	gint _rc = sqlite3_exec(__db, _sqlPacket, _callback, (void *)_readSql, &_zErrMsg);
	if(_rc != SQLITE_OK) {
		printf("DSVDataAnalysisApp, xchao_alarm:FileOP db select fail%d", _rc);
		return;
	}
	delete _readSql;
}

//*************************************************************************
//*************************************************************************
//*************************************************************************

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

ReadSql::ReadSql(std::vector<std::string>* __packets)
{
	this->m_packets=__packets;
}

ReadSql::~ReadSql()
{
}

/**
* @param   std::string __packet
* @return  null
* @retval  void
* @note
**/
void ReadSql::Append(std::string __packet)
{
	this->m_packets->push_back(__packet);
}

//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------

