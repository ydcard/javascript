/*
 * DSVLog.cpp
 *
 *  Created on: Sep 17, 2018
 *      Author: desay-sv
 */

#include "DSVLog.h"


DSVYdLog *DSVYdLog::m_instance = NULL;

DSVYdLog::DSVYdLog(){
	FileFlag = 0;

	//below only use in config module
	m_loglevel = LogLevel::YD_ALL;
	m_logFilePrefix = "data_log_";
	m_logFileName = "data_log.log";
	m_logPath = "/sdcard/log/ydlog/";
	m_logFileAmount = 10;
	m_logFileMaxBytes = 10240000;
	this->readConfig();

//	this->GetSumOfLogfile((std::string)LOG_PATH);
	this->GetSumOfLogfile(m_logPath);
}

DSVYdLog::~DSVYdLog(){
	printf("end of log");
}

DSVYdLog* DSVYdLog::GetInstance(){
	if(m_instance == NULL)
	{
		m_instance = new DSVYdLog();
	}
	return m_instance;
}

void DSVYdLog::resetFileSerial(std::set<int> Set){
	std::set<int>::iterator it = Set.begin();
	char *old_serial = new char[2];
	char *new_serial = new char[2];
	for(int _i = 1; _i <= Set.size(); _i++){
		sprintf(old_serial,"%02d",(*it));
		sprintf(new_serial,"%02d",_i);
		std::string old_name = m_logFilePrefix + old_serial + ".log";
		std::string new_name = m_logFilePrefix + new_serial + ".log";
		rename((char*)old_name.c_str(),(char*)new_name.c_str());
		it++;
	}
	delete []old_serial;
	delete []new_serial;
	old_serial = NULL;
	new_serial = NULL;
}

void DSVYdLog::SortRule(){
	int __flag = 0;
	int it = this->FileFlag;
	char *old_serial = new char[2];
	char *new_serial = new char[2];
	for(int _i = 1; _i <= this->FileFlag; _i++){
		sprintf(old_serial,"%02d",it);
		__flag = it+1;
		sprintf(new_serial,"%02d",__flag);
		std::string old_name = m_logPath + m_logFilePrefix + old_serial + ".log";
		std::string new_name = m_logPath + m_logFilePrefix + new_serial + ".log";
		rename((char*)old_name.c_str(),(char*)new_name.c_str());
		it--;
	}
	sprintf(new_serial,"%02d",it+1);
	std::string _new_name = m_logPath + m_logFilePrefix + new_serial + ".log";
	std::string log_name = m_logPath + m_logFileName;
	rename(log_name.c_str(),_new_name.c_str());
	delete []old_serial;
	delete []new_serial;
	old_serial = NULL;
	new_serial = NULL;
}

int DSVYdLog::GetSumOfLogfile(std::string __path)
{
	DIR *dir;
	struct dirent * ptr;
	int total = 0;
	char path[FILE_SIZE];
	std::set<int> Set;
	Set.clear();
	dir = opendir(__path.c_str()); /* 打开目录*/
	if(dir == NULL)
	{
		perror("fail to open dir");
		exit(1);
	}

	errno = 0;
	while((ptr = readdir(dir)) != NULL)
	{
		//顺序读取每一个目录项；
		//跳过“..”和“.”两个目录
		if(strcmp(ptr->d_name,".") == 0 || strcmp(ptr->d_name,"..") == 0)
		{
			continue;
		}

//		if(ptr->d_type == DT_DIR)
//		{
//			sprintf(path,"%s%s\n",__path.c_str(),ptr->d_name);
//			total += GetSumOfLogfile(path);
//		}

//		if(ptr->d_type == DT_REG)
//		{
//			if(strncmp(ptr->d_name,m_logFilePrefix.c_str(),m_logFilePrefix.length()) == 0){
//				std::string a = ptr->d_name;
//				std::string b;
//				if(a[m_logFilePrefix.length()+2]=='.'){
//					b = a.substr(m_logFilePrefix.length(),2);
//					int c = atoi(b.c_str());
//					if(c<=this->m_logFileAmount){
//						total++;
//						Set.insert(c);
//						printf("%s%s\n",__path.c_str(),ptr->d_name);
//					}
//				}
//			}
//		}
		//尝试加入正则表达式来进行
		if(ptr->d_type == DT_REG)
		{
			std::string str_regex = this->m_logFilePrefix + "(\\d{2}).log$";
			std::regex my_regex(str_regex);
			std::smatch my_match;
			std::string a = ptr->d_name;
			if(regex_search(a,my_match,my_regex)){
				int c = stoi(my_match[1],nullptr,10);
				if(c <= this->m_logFileAmount){
					total++;
					Set.insert(c);
					printf("%s%s\n",__path.c_str(),ptr->d_name);
				}
			}
		}
	}

	if((!Set.empty()) && (*(--Set.end()) != Set.size())){
		resetFileSerial(Set);
	}
	if(errno != 0)
	{
		printf("fail to read dir"); //失败则输出提示信息
		exit(1);
	}
	closedir(dir);
	FileFlag = total;
	return total;
}

void DSVYdLog::addNewLog(){
//	printf("FileFlag is %d\n",this->FileFlag);
//	printf("FileAmount is %d\n",this->m_logFileAmount);
	if(this->FileFlag >= m_logFileAmount){
		char *last_serial = new char[2];
		sprintf(last_serial,"%02d",m_logFileAmount);
		std::string old_name = m_logFilePrefix + last_serial + ".log";
		remove(old_name.c_str());
		this->FileFlag--;
		SortRule();
		delete []last_serial;
		last_serial = NULL;
	}
	else{
		SortRule();
	}
	this->FileFlag++;
}


void DSVYdLog::DDLOG(int __loglevel, std::string tag, std::string __logstr){
	my_mutex.lock();
	std::string log_name = m_logPath + m_logFileName;
//	std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now(); //test for log run time
	if(__loglevel <= m_loglevel){
//      时间使用chrono来进行处理
//		auto tt = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
//		struct tm* ptm = localtime(&tt);
//		char date[60] = {0};
//		sprintf(date, "[%4d-%02d-%02d %02d:%02d:%02d]",
//			(int)ptm->tm_year + 1900,(int)ptm->tm_mon + 1,(int)ptm->tm_mday,
//			(int)ptm->tm_hour,(int)ptm->tm_min,(int)ptm->tm_sec);
//		cout<<date<<endl;
		std::ofstream sfs;
		sfs.open(log_name.c_str(), std::ofstream::app);
		timeval timeVal;
		gettimeofday(&timeVal,NULL);
		time_t timep;
	    time( &timep );
	    timep = timep + 8*3600;
	    struct tm *pTM = gmtime( &timep );//gtime获取世界时间，localtime获取本地时间
	    char outstr[1024];
	    sprintf(outstr,"[%4d-%02d-%02d %02d:%02d:%02d:%06ld]",pTM->tm_year+1900, pTM->tm_mon+1, pTM->tm_mday, pTM->tm_hour, pTM->tm_min, pTM->tm_sec,timeVal.tv_usec);
	    sfs<<outstr<<"<"<<std::setfill('-')<<std::left<<std::setw(20)<<tag<<">"<<" "<<__logstr;
		sfs.close();
//	    std::cout<< sfs.str()<<std::endl;//打印log数据
	}
    struct stat statbuf;
    stat(log_name.c_str(),&statbuf);
    long size=statbuf.st_size;
	if(size > m_logFileMaxBytes){//暂定最大存储存储空间为10M
		addNewLog();
	}
//	std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
//    std::cout << "log cost time is "
//              << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count()
//              << "us.\n";
	my_mutex.unlock();
}


void DSVYdLog::readConfig()
{
    struct stat statbuf;
    stat("/app/bin/DLogConfig.json",&statbuf);
    long jsonFileSize=statbuf.st_size;
	if(jsonFileSize > 0)
	{
		FILE * pConfigJsonFile = fopen ("/app/bin/DLogConfig.json" , "r"); // 非 Windows 平台使用 "r"
		if(pConfigJsonFile != NULL)
		{
			char *readBuffer = NULL;
			readBuffer = (char *)malloc(sizeof(char)*jsonFileSize);
			//读取文件进行解析成json
			rapidjson::FileReadStream inputFileReadStream(pConfigJsonFile,readBuffer,jsonFileSize);
			rapidjson::Document document;
			document.ParseStream(inputFileReadStream);
			fclose(pConfigJsonFile);

			if(document.IsObject() && document.IsNull() == false)
			{
				if(document.HasMember("DSVDataLogFilePrefix"))
				{
					rapidjson::Value & DSVLogFilePrefixValue = document["DSVDataLogFilePrefix"];
					if (DSVLogFilePrefixValue.IsString())
					{
						m_logFilePrefix = DSVLogFilePrefixValue.GetString();
					}
				}

				if(document.HasMember("DSVDataLogFileName"))
				{
					rapidjson::Value & DSVLogFileNameValue = document["DSVDataLogFileName"];
					if (DSVLogFileNameValue.IsString())
					{
						m_logFileName = DSVLogFileNameValue.GetString();
					}
				}

				if(document.HasMember("DSVLogPath"))
				{
					rapidjson::Value & DSVLogPathValue = document["DSVLogPath"];
					if (DSVLogPathValue.IsString())
					{
						m_logPath = DSVLogPathValue.GetString();
					}
				}

				if(document.HasMember("DSVLogPriority"))
				{
					rapidjson::Value & DSVLogPriorityValue = document["DSVLogPriority"];
					if (DSVLogPriorityValue.IsInt())
					{
						m_loglevel = DSVLogPriorityValue.GetInt();
					}
				}

				if(document.HasMember("DSVLogFileAmount"))
				{
					rapidjson::Value & DSVLogFileAmountValue = document["DSVLogFileAmount"];
					if (DSVLogFileAmountValue.IsInt())
					{
						m_logFileAmount = DSVLogFileAmountValue.GetInt();
					}
				}

				if(document.HasMember("DSVLogSingleFileMaxBytes"))
				{
					rapidjson::Value & DSVLogSingleFileMaxBytesValue = document["DSVLogSingleFileMaxBytes"];
					if (DSVLogSingleFileMaxBytesValue.IsInt64())
					{
						m_logFileMaxBytes = DSVLogSingleFileMaxBytesValue.GetInt64();
					}
				}
			}
			else
			{
				std::cout<<"read error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
			}
			if(readBuffer != NULL)
			{
				free(readBuffer);
			}
		}
	}
}





