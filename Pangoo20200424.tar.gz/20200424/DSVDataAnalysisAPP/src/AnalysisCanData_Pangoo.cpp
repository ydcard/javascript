#include <thread>
#include <chrono>
#include "AnalysisCanData_Pangoo.h"
#include "TSPBinderCommunication.h"
#include "DSVLog.h"
#include "GPSInfoShareMemory.h"

////Pangoo
//enum PG_CmdRes{
//	PG_CMDLOCKRES = 1,
//	PG_CMDFINDCARRES = 2,
//	PG_CMDAIRCONRES = 3
//};

#define CAN_FRESH_COUNT 10;

uint8_t PG_CarStat;       		//车辆状态
//uint8_t PG_ChargeStat;    	//充电状态
uint8_t PG_Speed[2];       		//车速
uint8_t PG_TotalMile[4];   		//累计里程
//uint8_t PG_TotalVol[2];		//总电压
//uint8_t PG_TotalEle[2];		//总电流
//uint8_t PG_SOC;				//SOC状态
//uint8_t PG_DC2;				//DC-DC状态
uint8_t PG_Gear;				//档位
//uint8_t PG_Resis[2];			//绝缘电阻
uint8_t PG_AccPedal;			//加速踏板行程
uint8_t PG_BrakePedal;			//制动踏板行程
uint8_t	PG_TurnLight;			//转向灯
uint8_t PG_VerticalAcc[2];		//纵向加速度
uint8_t PG_CrossAcc[2];			//侧向加速度
uint8_t PG_WheelAngel[2];		//方向盘转角
uint8_t PG_ActualAcc[2];		//实际加速度
uint8_t PG_ActualAccBool;		//实际加速度有效
uint8_t PG_YawAcc[2];			//车身横摆角速度
uint8_t PG_AbsActive;			//防抱死制动系统激活
uint8_t PG_AbsFailure;			//防抱死制动系统失败
uint8_t PG_SpeedLimitStat;		//巡航和限速系统开关状态
uint8_t PG_KeyGear;				//钥匙档位
uint8_t PG_TirePreLow;			//轮胎低压指示
uint8_t PG_DaiSu;				//怠速状态
uint8_t PG_PassBelt;			//乘客安全带状态
uint8_t PG_DriverBelt;			//驾驶员安全带状态
uint8_t PG_EngineStat;			//发动机状态
uint8_t PG_QuZhou[2];			//曲轴转速
uint8_t PG_oilSpeed[2];			//瞬时油耗
//uint8_t PG_MotorStat;			//驱动电机状态
//uint8_t PG_MotorConTemp;		//驱动电机控制器温度
//uint8_t PG_MotorSpeed[2];		//驱动电机转速
//uint8_t PG_MotorTorque[2];	//驱动电机转矩
//uint8_t PG_MotorTemp;			//驱动电机温度
//uint8_t PG_MotorVol[2];		//电机控制器输入电压
//uint8_t PG_MotorEle[2];		//电机控制器直流母线电流
uint8_t PG_Pos[9];				//车辆位置
//uint8_t PG_CellHighVol[3];	//最高电压电池单体代号以及最高电压值
//uint8_t PG_CellLowVol[3];		//最低电压电池单体代号以及最低电压值
//uint8_t PG_HighTemp[2];		//最高温度单体代号以及温度值
//uint8_t PG_LowTemp[2];		//最低温度单体代号以及温度值
//uint8_t PG_HighAlarm;			//最高报警等级
//uint8_t PG_AlarmSign[4];		//通用报警标志
//uint8_t PG_CellNum[2];		//单体电池总数
uint8_t PG_WarnTire;			//胎压预警
uint8_t PG_WarnOxygen;			//发动机后置氧传感器需要诊断援助
uint8_t PG_WarnBrake;			//刹车过热
uint8_t PG_WarnGearBox;			//变速箱预警
uint8_t PG_WarnClutch;			//离合器预警
uint8_t PG_PitchAngle;			//俯仰角
uint8_t PG_RollAngle;			//侧倾角
uint8_t PG_LockStat;			//门锁状态
uint8_t PG_DoorStat;			//门窗状态
uint8_t PG_light[4];			//车灯
uint8_t PG_BCMStat;				//发动机
uint8_t	PG_WaterTemp;			//水温
uint8_t PG_AirCondit;			//空调
//uint8_t PG_CellWrong;			//动力电池严重状态
uint8_t PG_RemainMile[2];		//剩余里程
uint8_t PG_HandBrake;			//手刹
uint8_t PG_Wiper;				//雨刮
uint8_t PG_CmdLockRes;			//门锁响应
uint8_t PG_CmdFindRes;			//寻车响应
uint8_t PG_CmdAirConRes;		//空调响应
//20180808 新增
uint8_t PG_IMUYaw[2];			//IMU横摆角速度
uint8_t PG_WheelSpeed[2];		//方向盘转速
uint8_t PG_BrakeStatSig;		//刹车状态信号


//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------

AnalysisCanDataPangoo::~AnalysisCanDataPangoo()
{
}

/**
* @param   void
* @return  class
* @retval  AnalysisCanData*
* @note    单例
**/
AnalysisCanDataPangoo* AnalysisCanDataPangoo::GetInstance() {
	if(AnalysisCanDataPangoo::m_instance==NULL) {
		AnalysisCanDataPangoo::m_instance = new AnalysisCanDataPangoo();
	}
	return AnalysisCanDataPangoo::m_instance;
}


void AnalysisCanDataPangoo::CheckData_num1(){
	//车辆状态
	//0x01：车辆启动状态；0x02：熄火；0x03：其他状态；“0xFE”表示异常，“0xFF”表示无效。
	guchar _vc = 0xFF;
	if((spi_data[1][0] > 0) && (spi_data[1][0] < 4)){
		_vc = spi_data[1][0];
	}
	else{
		_vc = 0xFE;
	}
	this->m_canMessageManagementGB->SetVehicleCondition(_vc);
}

void AnalysisCanDataPangoo::CheckData_num2(){
	//车速
	//有效值范围：0～2200（表示0 km/h～220 km/h），最小计量单元：0.1km/h，“0xFF,0xFE”表示异常，“0xFF,0xFF”表示无效。
	gushort _vs = 0xFFFF;
	_vs= (spi_data[2][0]<<8)+spi_data[2][1];
	if(_vs > 2200) {
		_vs = 0xFFFE;
	}
	this->m_canMessageManagementGB->SetVehicleSpeed(_vs);
}

void AnalysisCanDataPangoo::CheckData_num3(){
	//累计里程
	//有效值范围：0～9999999（表示0km～999999.9km），最小计量单元：0.1km。“0xFF, 0xFF, 0xFF,0xFE”表示异常，“0xFF,0xFF,0xFF,0xFF”表示无效。
	guint _vi = 0xFFFFFFFF;
	_vi = (spi_data[3][0]<<24)+(spi_data[3][1]<<16)+(spi_data[3][2]<<8)+spi_data[3][3];
	if(_vi>9999999)
		_vi=0xFFFFFFFE;
	this->m_canMessageManagementGB->SetAccumulatedMileage(_vi);
}

void AnalysisCanDataPangoo::CheckData_num4(){
	//档位
	guchar _vc = 0xFF;
	_vc = spi_data[4][0];
	this->m_canMessageManagementGB->SetDrivelineState(_vc);
}

void AnalysisCanDataPangoo::CheckData_num5(){
	//加速踏板
	//有效值范围：0～100（表示0%～100%），最小计量单元：1%，“0xFE”表示异常，“0xFF”表示无效。
	guchar _vc = 0xFF;
	_vc = spi_data[5][0];
	if(_vc > 100)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetAccelerationPedal(_vc);
}

void AnalysisCanDataPangoo::CheckData_num6(){
	//制动踏板状态
	//有效值范围：0～100（表示0%～100%），最小计量单元：1%，“0”表示制动关的状态；在无具体行程值情况下，用“0x65”即“101”表示制动有效状态，“0xFE”表示异常，“0xFF”表示无效。
	guchar _vc = 0xFF;
	_vc = spi_data[6][0];
	if(_vc > 101)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetBrakePedalState(_vc);
}

void AnalysisCanDataPangoo::CheckData_num7(){
	//转向灯
	guchar _vc = 0xFF;
	_vc = spi_data[7][0];
	if(_vc > 2)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetTurnLight(_vc);
}

void AnalysisCanDataPangoo::CheckData_num8(){
	//纵向加速度
	gushort _vs = 0xFFFF;
	_vs = (spi_data[8][0]<<8) + spi_data[8][1];
	if(_vs > 3200)//0815:根据谢鹏洲定的CAN信号列表进行处理;1012:根据守义最新需求更改
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetVerticalAcc(_vs);
}

void AnalysisCanDataPangoo::CheckData_num9(){
	//侧向加速度
	gushort _vs = 0xFFFF;
	_vs = (spi_data[9][0]<<8) + spi_data[9][1];
	if(_vs > 6400)//0815:根据谢鹏洲定的CAN信号列表进行处理
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetCrossAcc(_vs);
}

void AnalysisCanDataPangoo::CheckData_num10(){
	//方向盘转角
	gushort _vs = 0xFFFF;
	_vs = (spi_data[10][0]<<8) + spi_data[10][1];
	if(_vs > 40960)
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetWheelAngle(_vs);
}

void AnalysisCanDataPangoo::CheckData_num11(){
	//实际加速度
	gushort _vs = 0xFFFF;
	_vs = (spi_data[11][0]<<8) + spi_data[11][1];
	if(_vs > 42000)//1012:根据守义最新需求更改
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetActualAcc(_vs);
}

void AnalysisCanDataPangoo::CheckData_num12(){
	//实际加速度有效
	guchar _vc = 0xFF;
	_vc = spi_data[12][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetActualAccValid(_vc);
}

void AnalysisCanDataPangoo::CheckData_num13(){
	//车身横摆角速度
	gushort _vs = 0xFFFF;
	_vs = (spi_data[13][0]<<8) + spi_data[13][1];
	if(_vs > 25600)
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetYawAcc(_vs);
}

void AnalysisCanDataPangoo::CheckData_num14(){
	//防抱死制动系统激活
	guchar _vc = 0xFF;
	_vc = spi_data[14][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetAbsActive(_vc);
}

void AnalysisCanDataPangoo::CheckData_num15(){
	//防抱死制动系统失败
	guchar _vc = 0xFF;
	_vc = spi_data[15][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetAbsFailure(_vc);
}

void AnalysisCanDataPangoo::CheckData_num16(){
	//巡航和限速系统开关状态
	guchar _vc = 0xFF;
	_vc = spi_data[16][0];
	if(_vc > 9)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetSpeedLimitState(_vc);
}

void AnalysisCanDataPangoo::CheckData_num17(){
	//钥匙档位
	guchar _vc = 0xFF;
	_vc = spi_data[17][0];
	if(_vc > 3)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetKeyGear(_vc);
}

void AnalysisCanDataPangoo::CheckData_num18(){
	//轮胎低压指示
	guchar _vc = 0xFF;
	_vc = spi_data[18][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetTirePreLow(_vc);
}

void AnalysisCanDataPangoo::CheckData_num19(){
	//怠速状态
	guchar _vc = 0xFF;
	_vc = spi_data[19][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetDaiSu(_vc);
}

void AnalysisCanDataPangoo::CheckData_num20(){
	//乘客安全带状态
	guchar _vc = 0xFF;
	_vc = spi_data[20][0];
	if(_vc > 3)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetPassengerBelt(_vc);
}

void AnalysisCanDataPangoo::CheckData_num21(){
	//驾驶员安全带状态
	guchar _vc = 0xFF;
	_vc = spi_data[21][0];
	if(_vc > 3)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetDriverBelt(_vc);
}

void AnalysisCanDataPangoo::CheckData_num22(){
	//发动机状态
	guchar _vc = 0xFF;
	_vc = spi_data[22][0];
	if(_vc > 2)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetEngineState(_vc);
}

void AnalysisCanDataPangoo::CheckData_num23(){
	//曲轴转速
	gushort _vs = 0xFFFF;
	_vs = (spi_data[23][0]<<8) + (spi_data[23][1]);
	if(_vs > 60000)
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetCrankshaftSpeed(_vs);
}

void AnalysisCanDataPangoo::CheckData_num24(){
	//瞬时油耗
	gushort _vs = 0xFFFF;
	_vs = (spi_data[24][0]<<8) + (spi_data[24][1]);
	if(_vs > 60000)
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetOilSpeed(_vs);
}

// 20200424:　MCU反馈无法获取gps数据，目前定位数据直接从SOC获取
void AnalysisCanDataPangoo::CheckData_num25(){
	//定位状态
	guchar _vc = 0xFF;
	guint _vi = 0xFFFFFFFF;
	guint _vg = 0xFFFFFFFF;
	_vc = spi_data[25][0];
	_vi = (spi_data[25][1]<<24)+(spi_data[25][2]<<16)+(spi_data[25][3]<<8)+spi_data[25][4];
	_vg = (spi_data[25][5]<<24)+(spi_data[25][6]<<16)+(spi_data[25][7]<<8)+spi_data[25][8];
	uint8_t ydd = _vc << 7;
	if(ydd){
		this->m_canMessageManagementGB->SetValidPosition(_vc);
		this->m_canMessageManagementGB->SetLongitude(0xFFFFFFFF);
		this->m_canMessageManagementGB->SetLatitude(0xFFFFFFFF);
	}
	else{
		this->m_canMessageManagementGB->SetValidPosition(_vc);
		this->m_canMessageManagementGB->SetLongitude(_vi);
		this->m_canMessageManagementGB->SetLatitude(_vg);

	}
}


void AnalysisCanDataPangoo::CheckData_num33(){
	//门锁状态
	guchar _vc = 0xFF;
	_vc = spi_data[33][0];
	this->m_canMessageManagementGB->SetLockerMode(_vc);
}

void AnalysisCanDataPangoo::CheckData_num34(){
	//车窗状态
	guchar _vc = 0xFF;
	_vc = spi_data[34][0];
	this->m_canMessageManagementGB->SetWindowMode(_vc);
}

void AnalysisCanDataPangoo::CheckData_num35(){
	//车灯状态
	guint _vi = 0xFFFFFFFF;
	_vi = (spi_data[35][0]<<24) + (spi_data[35][1]<<16) + (spi_data[35][2]<<8) + spi_data[35][3];
	this->m_canMessageManagementGB->SetCarLightState(_vi);
}

void AnalysisCanDataPangoo::CheckData_num36(){
	//发动机
	guchar _vc = 0xFF;
	_vc = spi_data[36][0];
	this->m_canMessageManagementGB->SetBCMState(_vc);
}

void AnalysisCanDataPangoo::CheckData_num37(){
	//电池水温
	guchar _vc = 0xFF;
	_vc = spi_data[37][0];
	this->m_canMessageManagementGB->SetWaterTemperature(_vc);
}

void AnalysisCanDataPangoo::CheckData_num38(){
	//空调
	guchar _vc = 0xFF;
	_vc = spi_data[38][0];
	this->m_canMessageManagementGB->SetAirCondition(_vc);
}

void AnalysisCanDataPangoo::CheckData_num39(){
	//续驶里程
	gushort _vs = 0xFFFF;
	_vs = (spi_data[39][0]<<8) + spi_data[39][1];
	this->m_canMessageManagementGB->SetReAccumulatedMileage(_vs);
}

void AnalysisCanDataPangoo::CheckData_num40(){
	//手刹
	guchar _vc = 0xFF;
	_vc = spi_data[40][0];
	this->m_canMessageManagementGB->SetHandBrake(_vc);
}

void AnalysisCanDataPangoo::CheckData_num41(){
	//雨刮
	guchar _vc = 0xFF;
	_vc = spi_data[41][0];
	this->m_canMessageManagementGB->SetWiper(_vc);
}

void AnalysisCanDataPangoo::CheckData_num42(){
	//IMU横摆角速度
	gushort _vs = 0xFFFF;
	_vs = (spi_data[42][0]<<8) + spi_data[42][1];
	if(_vs>25600)//0815:根据谢鹏洲定的CAN信号列表进行处理
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetIMUYaw(_vs);
}

void AnalysisCanDataPangoo::CheckData_num43(){
	//方向盘转速
	gushort _vs = 0xFFFF;
	_vs = (spi_data[43][0]<<8) + spi_data[43][1];
	if(_vs>40960)
		_vs = 0xFFFE;
	this->m_canMessageManagementGB->SetWheelSpeed(_vs);
}

void AnalysisCanDataPangoo::CheckData_num44(){
	//刹车状态信号
	guchar _vc = 0xFF;
	_vc = spi_data[44][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetBrakeStatSig(_vc);
}

void AnalysisCanDataPangoo::CheckData_num45(){
	//剩余油量
	gushort _vs = 0xFFFF;
	_vs = (spi_data[45][0]<<8) + spi_data[45][1];
	this->m_canMessageManagementGB->SetRemainOil(_vs);

//	this->m_canMessageManagementGB->InitFinish();
}

void AnalysisCanDataPangoo::CheckData_num50(){
	//门锁响应
	guchar _vc = 0xFF;
	_vc = spi_data[50][0];
	this->m_canMessageManagementGB->SetLockResponse(_vc);
}

void AnalysisCanDataPangoo::CheckData_num51(){
	//寻车响应
	guchar _vc = 0xFF;
	_vc = spi_data[51][0];
	this->m_canMessageManagementGB->SetFindResponse(_vc);
}

void AnalysisCanDataPangoo::CheckData_num52(){
	//空调响应
	guchar _vc = 0xFF;
	_vc = spi_data[52][0];
	this->m_canMessageManagementGB->SetAirCondition(_vc);
}


//-------------------------------------------------------------------------
//---------------------------------protected-------------------------------
//-------------------------------------------------------------------------

//Pangoo:0827-new_design
void AnalysisCanDataPangoo::PG_InitMcuData()
{
	this->Init_data(1,1);      		//车辆状态
	this->Init_data(2,2);       	//车速
	this->Init_data(3,4);    		//累计里程
	this->Init_data(4,1); 			//档位
	this->Init_data(5,1); 			//加速踏板行程
	this->Init_data(6,1); 			//制动踏板行程
	this->Init_data(7,1);			//转向灯
	this->Init_data(8,2); 			//纵向加速度
	this->Init_data(9,2); 			//侧向加速度
	this->Init_data(10,2); 			//方向盘转角
	this->Init_data(11,2); 			//实际加速度
	this->Init_data(12,1); 			//实际加速度有效
	this->Init_data(13,2); 			//车身横摆角速度
	this->Init_data(14,1); 			//防抱死制动系统激活
	this->Init_data(15,1); 			//防抱死制动系统失败
	this->Init_data(16,1);			//巡航和限速系统开关状态
	this->Init_data(17,1); 			//钥匙档位
	this->Init_data(18,1); 			//轮胎低压指示
	this->Init_data(19,1); 			//怠速状态
	this->Init_data(20,1); 			//乘客安全带状态
	this->Init_data(21,1); 			//驾驶员安全带状态
	this->Init_data(22,1); 			//发动机状态
	this->Init_data(23,2); 			//曲轴转速
	this->Init_data(24,2); 			//瞬时油耗
	this->Init_data(25,9); 			//车辆位置
	this->Init_data(33,1); 			//门锁状态
	this->Init_data(34,1); 			//门窗状态
	this->Init_data(35,4);			//车灯
	this->Init_data(36,1); 			//发动机
	this->Init_data(37,1);			//水温
	this->Init_data(38,1);			//空调
	this->Init_data(39,2);			//剩余里程
	this->Init_data(40,1); 			//手刹
	this->Init_data(41,1); 			//雨刮
	//20180808新增
	this->Init_data(42,2); 			//IMU横摆角速度
	this->Init_data(43,2); 			//方向盘转速
	this->Init_data(44,1); 			//刹车状态信号
	//20181120新增
	this->Init_data(45,2);			//剩余油量
	//20181128新增
	this->Init_data(100,1); 			//胎压预警
	this->Init_data(101,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(102,1); 			//刹车过热
	this->Init_data(103,1); 			//变速箱预警
	this->Init_data(110,1); 			//离合器预警
	this->Init_data(111,1); 			//俯仰角
	this->Init_data(112,1); 			//侧倾角
	this->Init_data(113,1); 			//胎压预警
	this->Init_data(114,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(115,1); 			//刹车过热
	this->Init_data(116,1); 			//变速箱预警
	this->Init_data(117,1); 			//离合器预警
	this->Init_data(118,1); 			//俯仰角
	this->Init_data(119,1); 			//侧倾角
	this->Init_data(120,1); 			//胎压预警
	this->Init_data(121,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(122,1); 			//刹车过热
	this->Init_data(123,1); 			//变速箱预警
	this->Init_data(124,1); 			//离合器预警
	this->Init_data(125,1); 			//俯仰角
	this->Init_data(126,1); 			//侧倾角
	this->Init_data(127,1); 			//胎压预警
	this->Init_data(128,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(140,1); 			//刹车过热
	this->Init_data(141,1); 			//变速箱预警
	this->Init_data(142,1); 			//离合器预警
	this->Init_data(143,1); 			//俯仰角
	this->Init_data(144,1); 			//侧倾角
	this->Init_data(145,1); 			//胎压预警
	this->Init_data(146,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(147,1); 			//刹车过热
	this->Init_data(150,1); 			//变速箱预警
	this->Init_data(151,1); 			//离合器预警
	this->Init_data(160,1); 			//胎压预警
	this->Init_data(161,1); 			//发动机后置氧传感器需要诊断援助
	this->Init_data(162,1); 			//刹车过热
	this->Init_data(163,1); 			//变速箱预警
	this->Init_data(164,1); 			//离合器预警
	this->Init_data(165,1); 			//俯仰角
	this->Init_data(166,1); 			//侧倾角

	//应答数据
	this->Init_data(50,1); 			//门锁响应
	this->Init_data(51,1); 			//寻车响应
	this->Init_data(52,1); 			//空调响应
}

//Pangoo:0827-new_design
void AnalysisCanDataPangoo::Init_data(int __number, int __size){
	vector<uint8_t> b(__size,0xFF);
	this->spi_data.insert(pair<int,vector<uint8_t>>(__number,b));
}

//Pangoo:0827-new_design
void AnalysisCanDataPangoo::HandleMCU(uint8_t __MCUTYPE, uint8_t __MCUNO, uint8_t *__buff, uint8_t __len)
{
	//0808:根据谢鹏洲提供的spi_type要求进行更改，数据上传为0x01，数据应答为0x04，数据下发为0x03
	if(__MCUTYPE == 1){
		this->Set_data(__MCUNO,__buff,__len);				//通用
	}
	else if(__MCUTYPE == 4){
		BinderContactsWorker* __SvBinder = BinderContactsWorker::GetInstance();
		this->Set_data(__MCUNO,__buff,__len);				//通用
		__SvBinder->SetPGNum();
		__SvBinder->SetSerialNum(__MCUNO);
	}
	//20181128--Pangoo---20181210--取消
	else if(__MCUTYPE == 2){
		//		CANMessageManagement_GB* __SvMCUData = CANMessageManagement_GB::GetInstance();
//		if(__MCUNO >= 100 && __MCUNO<110){
//			__SvMCUData->SetWarnFlag(1);
//		}
//		else if(__MCUNO >= 110 && __MCUNO<140){
//			__SvMCUData->SetWarnFlag(2);
//		}
//		else if(__MCUNO >= 140 && __MCUNO<150){
//			__SvMCUData->SetWarnFlag(3);
//		}
//		else if(__MCUNO >= 150 && __MCUNO<160){
//			__SvMCUData->SetWarnFlag(4);
//		}
//		else if(__MCUNO >= 160 && __MCUNO<180){
//			__SvMCUData->SetWarnFlag(5);
//		}
		this->Set_data(__MCUNO,__buff,__len);				//通用
	}
}

//Pangoo:0827-new_design
void AnalysisCanDataPangoo::Set_data(int __number, uint8_t *buffer, int len){
	for(int _i=0; _i<len; _i++){
//		spi_data[__number].insert(spi_data[__number].begin()+_i,*buffer);
		spi_data[__number][_i] = *buffer++;
	}
}

//Pangoo:0827-new_design
std::map<int,std::vector<uint8_t>> AnalysisCanDataPangoo::getdata(){
	return spi_data;
}

//-------------------------------------------------------------------------
//-----------------------------------20181128------------------------------
//-------------------------------------------------------------------------
//---------------------------20181128-----------------------------
void AnalysisCanDataPangoo::CheckData_num100(){
	guchar _vc = 0xFF;
	printf("100-1 is %2X\n",spi_data[100][0]);
	_vc = spi_data[100][0];
	if(_vc == 0x01){
		this->m_canMessageManagementGB->SetWarnFlag(1);
	}
	this->m_canMessageManagementGB->SetMinorFailure1(_vc);
}

void AnalysisCanDataPangoo::CheckData_num101(){
	guchar _vc = 0xFF;
	_vc = spi_data[101][0];
	if(_vc == 0x01){
		this->m_canMessageManagementGB->SetWarnFlag(1);
	}
	this->m_canMessageManagementGB->SetMinorFailure2(_vc);
}

void AnalysisCanDataPangoo::CheckData_num102(){
	guchar _vc = 0xFF;
	_vc = spi_data[102][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(1);
	}
	this->m_canMessageManagementGB->SetMinorFailure3(_vc);
}

void AnalysisCanDataPangoo::CheckData_num103(){
	guchar _vc = 0xFF;
	_vc = spi_data[103][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(1);
	}
	this->m_canMessageManagementGB->SetMinorFailure4(_vc);
}

void AnalysisCanDataPangoo::CheckData_num110(){
	guchar _vc = 0xFF;
	_vc = spi_data[110][0];
	char aaa[1024];
	sprintf(aaa,"num110 is %d\n",_vc);
	YDLOG(YD_DEBUG, "PacketPGWarnData", aaa);
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure1(_vc);
}

void AnalysisCanDataPangoo::CheckData_num111(){
	guchar _vc = 0xFF;
	_vc = spi_data[111][0];
	char aaa[1024];
	sprintf(aaa,"num111 is %d\n",_vc);
	YDLOG(YD_DEBUG, "PacketPGWarnData", aaa);
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure2(_vc);
}

void AnalysisCanDataPangoo::CheckData_num112(){
	guchar _vc = 0xFF;
	_vc = spi_data[112][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure3(_vc);
}

void AnalysisCanDataPangoo::CheckData_num113(){
	guchar _vc = 0xFF;
	_vc = spi_data[113][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure4(_vc);
}

void AnalysisCanDataPangoo::CheckData_num114(){
	guchar _vc = 0xFF;
	_vc = spi_data[114][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure5(_vc);
}

void AnalysisCanDataPangoo::CheckData_num115(){
	guchar _vc = 0xFF;
	_vc = spi_data[115][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure6(_vc);
}

void AnalysisCanDataPangoo::CheckData_num116(){
	guchar _vc = 0xFF;
	_vc = spi_data[116][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure7(_vc);
}

void AnalysisCanDataPangoo::CheckData_num117(){
	guchar _vc = 0xFF;
	_vc = spi_data[117][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure8(_vc);
}

void AnalysisCanDataPangoo::CheckData_num118(){
	guchar _vc = 0xFF;
	_vc = spi_data[118][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure9(_vc);
}

void AnalysisCanDataPangoo::CheckData_num119(){
	guchar _vc = 0xFF;
	_vc = spi_data[119][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure10(_vc);
}

void AnalysisCanDataPangoo::CheckData_num120(){
	guchar _vc = 0xFF;
	_vc = spi_data[120][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure11(_vc);
}

void AnalysisCanDataPangoo::CheckData_num121(){
	guchar _vc = 0xFF;
	_vc = spi_data[121][0];
	if(_vc == 0x01 || _vc == 0x02){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure12(_vc);
}

void AnalysisCanDataPangoo::CheckData_num122(){
	guchar _vc = 0xFF;
	_vc = spi_data[122][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure13(_vc);
}

void AnalysisCanDataPangoo::CheckData_num123(){
	guchar _vc = 0xFF;
	_vc = spi_data[123][0];
	if(_vc == 0x01 || _vc == 0x02 || _vc == 0x03 || _vc == 0x04 || _vc == 0x05){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure14(_vc);
}

void AnalysisCanDataPangoo::CheckData_num124(){
	guchar _vc = 0xFF;
	_vc = spi_data[124][0];
	if(_vc == 0x01 || _vc == 0x02 || _vc == 0x03){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure15(_vc);
}

void AnalysisCanDataPangoo::CheckData_num125(){
	guchar _vc = 0xFF;
	_vc = spi_data[125][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure16(_vc);
}

void AnalysisCanDataPangoo::CheckData_num126(){
	guchar _vc = 0xFF;
	_vc = spi_data[126][0];
	if(_vc == 0x01 || _vc == 0x02 || _vc == 0x03 || _vc == 0x04 || _vc == 0x05){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure17(_vc);
}

void AnalysisCanDataPangoo::CheckData_num127(){
	guchar _vc = 0xFF;
	_vc = spi_data[127][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure18(_vc);
}

void AnalysisCanDataPangoo::CheckData_num128(){
	guchar _vc = 0xFF;
	_vc = spi_data[128][0];
	if(_vc == 0x01 || _vc == 0x02 || _vc == 0x03){

		this->m_canMessageManagementGB->SetWarnFlag(2);
	}
	this->m_canMessageManagementGB->SetNormalFailure19(_vc);
}

void AnalysisCanDataPangoo::CheckData_num140(){
	guchar _vc = 0xFF;
	_vc = spi_data[140][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure1(_vc);
}

void AnalysisCanDataPangoo::CheckData_num141(){
	guchar _vc = 0xFF;
	_vc = spi_data[141][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure2(_vc);
}

void AnalysisCanDataPangoo::CheckData_num142(){
	guchar _vc = 0xFF;
	_vc = spi_data[142][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure3(_vc);
}

void AnalysisCanDataPangoo::CheckData_num143(){
	guchar _vc = 0xFF;
	_vc = spi_data[143][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure4(_vc);
}

void AnalysisCanDataPangoo::CheckData_num144(){
	guchar _vc = 0xFF;
	_vc = spi_data[144][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure5(_vc);
}

void AnalysisCanDataPangoo::CheckData_num145(){
	guchar _vc = 0xFF;
	_vc = spi_data[145][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure6(_vc);
}

void AnalysisCanDataPangoo::CheckData_num146(){
	guchar _vc = 0xFF;
	_vc = spi_data[146][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure7(_vc);
}

void AnalysisCanDataPangoo::CheckData_num147(){
	guchar _vc = 0xFF;
	_vc = spi_data[147][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(3);
	}
	this->m_canMessageManagementGB->SetSeriousFailure8(_vc);
}

void AnalysisCanDataPangoo::CheckData_num150(){
	guchar _vc = 0xFF;
	_vc = spi_data[150][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(4);
	}
	this->m_canMessageManagementGB->SetDeadlyFailure1(_vc);
}

void AnalysisCanDataPangoo::CheckData_num151(){
	guchar _vc = 0xFF;
	_vc = spi_data[151][0];
	if(_vc == 0x01){

		this->m_canMessageManagementGB->SetWarnFlag(4);
	}
	this->m_canMessageManagementGB->SetDeadlyFailure2(_vc);
}

void AnalysisCanDataPangoo::CheckData_num160(){
	//胎压预警
	guchar _vc = 0xFF;
	_vc = spi_data[160][0];
	this->m_canMessageManagementGB->SetWarnTire(_vc);
}

void AnalysisCanDataPangoo::CheckData_num161(){
	//发动机后置氧传感
	guchar _vc = 0xFF;
	_vc = spi_data[161][0];
	this->m_canMessageManagementGB->SetWarnOxygen(_vc);
}

void AnalysisCanDataPangoo::CheckData_num162(){
	//刹车过热
	guchar _vc = 0xFF;
	_vc = spi_data[162][0];
	if(_vc > 1)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetWarnBrake(_vc);
}

void AnalysisCanDataPangoo::CheckData_num163(){
	//变速箱预警
	guchar _vc = 0xFF;
	_vc = spi_data[163][0];
	this->m_canMessageManagementGB->SetWarnGearBox(_vc);
}

void AnalysisCanDataPangoo::CheckData_num164(){
	//离合器预警
	guchar _vc = 0xFF;
	_vc = spi_data[164][0];
	if(_vc > 5)//1012:根据守义最新需求更改
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetWarnClutch(_vc);
}

void AnalysisCanDataPangoo::CheckData_num165(){
	//俯仰角
	guchar _vc = 0xFF;
	_vc = spi_data[165][0];
	if(_vc > 90)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetPitchAngle(_vc);
}

void AnalysisCanDataPangoo::CheckData_num166(){
	//侧倾角
	guchar _vc = 0xFF;
	_vc = spi_data[166][0];
	if(_vc > 90)
		_vc = 0xFE;
	this->m_canMessageManagementGB->SetRollAngle(_vc);
}




void AnalysisCanDataPangoo::AnalysisToPlat(uint8_t __number)
{
	char aaa[1024];
	sprintf(aaa,"number is %d\n",__number);
	YDLOG(YD_DEBUG, "AnalysisCanDataPangoo", aaa);
	switch(__number){
	case 1:{
		this->CheckData_num1();
		break;
	}
	case 2:{
		this->CheckData_num2();
		break;
	}
	case 3:{
		this->CheckData_num3();
		break;
	}
	case 4:{
		this->CheckData_num4();
		break;
	}
	case 5:{
		this->CheckData_num5();
		break;
	}
	case 6:{
		this->CheckData_num6();
		break;
	}
	case 7:{
		this->CheckData_num7();
		break;
	}
	case 8:{
		this->CheckData_num8();
		break;
	}
	case 9:{
		this->CheckData_num9();
		break;
	}
	case 10:{
		this->CheckData_num10();
		break;
	}
	case 11:{
		this->CheckData_num11();
		break;
	}
	case 12:{
		this->CheckData_num12();
		break;
	}
	case 13:{
		this->CheckData_num13();
		break;
	}
	case 14:{
		this->CheckData_num14();
		break;
	}
	case 15:{
		this->CheckData_num15();
		break;
	}
	case 16:{
		this->CheckData_num16();
		break;
	}
	case 17:{
		this->CheckData_num17();
		break;
	}
	case 18:{
		this->CheckData_num18();
		break;
	}
	case 19:{
		this->CheckData_num19();
		break;
	}
	case 20:{
		this->CheckData_num20();
		break;
	}
	case 21:{
		this->CheckData_num21();
		break;
	}
	case 22:{
		this->CheckData_num22();
		break;
	}
	case 23:{
		this->CheckData_num23();
		break;
	}
	case 24:{
		this->CheckData_num24();
		break;
	}
	case 25:{
		this->CheckData_num25();
		break;
	}
	case 33:{
		this->CheckData_num33();
		break;
	}
	case 34:{
		this->CheckData_num34();
		break;
	}
	case 35:{
		this->CheckData_num35();
		break;
	}
	case 36:{
		this->CheckData_num36();
		break;
	}
	case 37:{
		this->CheckData_num37();
		break;
	}
	case 38:{
		this->CheckData_num38();
		break;
	}
	case 39:{
		this->CheckData_num39();
		break;
	}
	case 40:{
		this->CheckData_num40();
		break;
	}
	case 41:{
		this->CheckData_num41();
		break;
	}
	case 42:{
		this->CheckData_num42();
		break;
	}
	case 43:{
		this->CheckData_num43();
		break;
	}
	case 44:{
		this->CheckData_num44();
		break;
	}
	case 45:{
		this->CheckData_num45();
		break;
	}
	case 50:{
		this->CheckData_num50();
		break;
	}
	case 51:{
		this->CheckData_num51();
		break;
	}
	case 52:{
		this->CheckData_num52();
		break;
	}
	case 100:{
		this->CheckData_num100();
		break;
	}
	case 101:{
		this->CheckData_num101();
		break;
	}
	case 102:{
		this->CheckData_num102();
		break;
	}
	case 103:{
		this->CheckData_num103();
		break;
	}
	case 110:{
		this->CheckData_num110();
		break;
	}
	case 111:{
		this->CheckData_num111();
		break;
	}
	case 112:{
		this->CheckData_num112();
		break;
	}
	case 113:{
		this->CheckData_num113();
		break;
	}
	case 114:{
		this->CheckData_num114();
		break;
	}
	case 115:{
		this->CheckData_num115();
		break;
	}
	case 116:{
		this->CheckData_num116();
		break;
	}
	case 117:{
		this->CheckData_num117();
		break;
	}
	case 118:{
		this->CheckData_num118();
		break;
	}
	case 119:{
		this->CheckData_num119();
		break;
	}
	case 120:{
		this->CheckData_num120();
		break;
	}
	case 121:{
		this->CheckData_num121();
		break;
	}
	case 122:{
		this->CheckData_num122();
		break;
	}
	case 123:{
		this->CheckData_num123();
		break;
	}
	case 124:{
		this->CheckData_num124();
		break;
	}
	case 125:{
		this->CheckData_num125();
		break;
	}
	case 126:{
		this->CheckData_num126();
		break;
	}
	case 127:{
		this->CheckData_num127();
		break;
	}
	case 128:{
		this->CheckData_num128();
		break;
	}
	case 140:{
		this->CheckData_num140();
		break;
	}
	case 141:{
		this->CheckData_num141();
		break;
	}
	case 142:{
		this->CheckData_num142();
		break;
	}
	case 143:{
		this->CheckData_num143();
		break;
	}
	case 144:{
		this->CheckData_num144();
		break;
	}
	case 145:{
		this->CheckData_num145();
		break;
	}
	case 146:{
		this->CheckData_num146();
		break;
	}
	case 147:{
		this->CheckData_num147();
		break;
	}
	case 150:{
		this->CheckData_num150();
		break;
	}
	case 151:{
		this->CheckData_num151();
		break;
	}
	case 160:{
		this->CheckData_num160();
		break;
	}
	case 161:{
		this->CheckData_num161();
		break;
	}
	case 162:{
		this->CheckData_num162();
		break;
	}
	case 163:{
		this->CheckData_num163();
		break;
	}
	case 164:{
		this->CheckData_num164();
		break;
	}
	case 165:{
		this->CheckData_num165();
		break;
	}
	case 166:{
		this->CheckData_num166();
		break;
	}
	default:{
		break;
	}
	}
//	this->m_canMessageManagementGB->InitFinish();
	return;
}


// 20200424:　GPS数据无法从mcu获取,增加SOC获取GPS的线程，每1s采集一次数据
void AnalysisCanDataPangoo::GetGPSThread()
{
	while (1) {
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		DeflectGPSInfo GPSInfo = {0};
		int iRet = GPSInfoShareMemory::getInstance("DSVDataAnalysisAPP", false)->readVehiclePositionData(GPSInfo);
		if (iRet == RET::SUCCESS) {
			this->m_canMessageManagementGB->SetValidPosition(0x00);
			double dlongitude = GPSInfo.LocationLongitude;
			double dlatitude = GPSInfo.LocationLatitude;
			uint32_t ilongitude = (uint32_t)(dlongitude * 10e6);
			uint32_t ilatitude = (uint32_t)(dlatitude * 10e6);
			this->m_canMessageManagementGB->SetLongitude(ilongitude);
			this->m_canMessageManagementGB->SetLatitude(ilatitude);
			std::cout << ">>>>>>longitude is : " << dlongitude << std::endl;
			std::cout << ">>>>>>latitude is : " << dlatitude << std::endl;
		}
	}
}

//-------------------------------------------------------------------------
//---------------------------------private---------------------------------
//-------------------------------------------------------------------------
AnalysisCanDataPangoo* AnalysisCanDataPangoo::m_instance=NULL;

AnalysisCanDataPangoo::AnalysisCanDataPangoo():AnalysisCanData()
{
	this->spi_data.clear();
	this->PG_InitMcuData();
	std::thread startGetGPSDataThread(&AnalysisCanDataPangoo::GetGPSThread, this);
	startGetGPSDataThread.detach();
}

