#include "AnalysisCanData.h"
#include "McuComManager.h"
#include "ToolUtils.h"

#define DEBUG_MESSAGE_TAG 0

//-------------------------------------------------------------------------
//---------------------------------public----------------------------------
//-------------------------------------------------------------------------
AnalysisCanData::~AnalysisCanData()
{
}

AnalysisCanData::AnalysisCanData()
{
	this->m_canMessageManagementGB=CANMessageManagement_GB::GetInstance();
}

/**
* @param   uint8_t* __buff,uint8_t __len
* @return  null
* @retval  void
* @note    开始解析Pangoo的MCU数据
**/
void AnalysisCanData::AnalysisMCU(uint8_t __MCUTYPE, uint8_t __MCUNO, uint8_t* __buff, uint8_t __len)
{
	this->HandleMCU(__MCUTYPE, __MCUNO, __buff, __len);
	return;
}

