#include "TelematicsServices.h"
#include <stdio.h>
#include "logging.h"

int main(void)
{
	LOG_CONFIG_FILE("./LogConfig.json");
	sleep(1);
	TelematicsServices *svr = TelematicsServices::getInstance();
	svr->StartApp();
	LOG_INFO << "============DSVTSPConnectSVC BEGIN=========";
	while (true) {
		sleep(10);
	}
	return 0;
}
