/*
 * ConfigInfo.cpp
 *
 *  Created on: 2017年7月20日
 *      Author: wsong
 */

#include "ConfigInfo.h"
#include "prettywriter.h"
#include "document.h"
#include "stringbuffer.h"
#include "filereadstream.h"
#include "filewritestream.h"
using namespace rapidjson;
#include <iostream>
using namespace std;
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <iomanip>
#include <ostream>
#include <time.h>
#include <string>
#include <sstream>
#include <fstream>
#include "logging.h"

ConfigInfo::ConfigInfo()
{
	LOG_INFO << "Config BEGIN";
	tokenStr_ = "";
	RSAKeyStr_ = "";
	platformLoginSerialNumber_ = 0;
	username_ = "desay";
	userPassword_ = "123456";
	TBOX_VERSION_ = "TT00040000";
	TSPServerIp_ = "iov.eastoneauto.com";
	TSPServerPort_ = 9000;
	TBOX_VIN_ = "AAAAAAAAAA3222073";
	TBOX_ICCID_ = "89860041191673222073";
	TSPLoginSerialNumberDate_ = 0;
	TSPLoginSerialNumber_ = 0;

	readConfigInfo();
}

void ConfigInfo::readConfigInfo()
{
	LOG_INFO << "read Config BEGIN";
	long jsonFileSize = 0;
	struct stat statbuff;
	if (stat("./TelematicsServicesConfig.json", &statbuff) < 0) {
		return;
	}
	else {
		jsonFileSize = statbuff.st_size;
	}
	if(jsonFileSize > 0)
	{
		FILE * pConfigJsonFile = fopen ("./TelematicsServicesConfig.json" , "r"); // 非 Windows 平台使用 "r"
		if(pConfigJsonFile != NULL)
		{
			char *readBuffer = NULL;
			readBuffer = (char *)malloc(sizeof(char)*jsonFileSize);
			//读取文件进行解析成json
			FileReadStream inputFileReadStream(pConfigJsonFile,readBuffer,jsonFileSize);
			Document document;
			document.ParseStream(inputFileReadStream);
			fclose(pConfigJsonFile);

			if(document.IsObject() && document.IsNull() == false)
			{
				if(document.HasMember("TSPServerIp"))
				{
					Value & TSPServerIpValue = document["TSPServerIp"];
					if (TSPServerIpValue.IsString())
					{
						TSPServerIp_ = TSPServerIpValue.GetString();
					}
				}

				if(document.HasMember("TSPServerPort"))
				{
					Value & TSPServerPortValue = document["TSPServerPort"];
					if (TSPServerPortValue.IsInt())
					{
						TSPServerPort_ = TSPServerPortValue.GetInt();
					}
				}

				if(document.HasMember("TBOX_VIN"))
				{
					Value & TBOX_VINValue = document["TBOX_VIN"];
					if (TBOX_VINValue.IsString())
					{
						TBOX_VIN_ = TBOX_VINValue.GetString();
					}
				}

				if(document.HasMember("TBOX_ICCID"))
				{
					Value & TBOX_ICCIDValue = document["TBOX_ICCID"];
					if (TBOX_ICCIDValue.IsString())
					{
						TBOX_ICCID_ = TBOX_ICCIDValue.GetString();
					}
				}

				if(document.HasMember("TBOX_VERSION"))
				{
					Value & TBOX_VERSIONValue = document["TBOX_VERSION"];
					if (TBOX_VERSIONValue.IsString())
					{
						TBOX_VERSION_ = TBOX_VERSIONValue.GetString();
					}
				}

				if(document.HasMember("TSPLoginSerialNumberDate"))
				{
					Value & TSPLoginSerialNumberDateValue = document["TSPLoginSerialNumberDate"];
					if (TSPLoginSerialNumberDateValue.IsInt64())
					{
						TSPLoginSerialNumberDate_ = TSPLoginSerialNumberDateValue.GetInt64();
					}
				}

				if(document.HasMember("PlatformLoginSerialNumber"))//Pangoo:add in 0817
				{
					Value & PlatformLoginSerialNumberValue = document["PlatformLoginSerialNumber"];
					if (PlatformLoginSerialNumberValue.IsInt())
					{
						platformLoginSerialNumber_ = PlatformLoginSerialNumberValue.GetInt();
					}
				}

				if(document.HasMember("PG_username"))//Pangoo:add in 0817
				{
					Value & PG_usernameValue = document["PG_username"];
					if (PG_usernameValue.IsString())
					{
						username_= PG_usernameValue.GetString();
					}
				}

				if(document.HasMember("PG_userpassword"))//Pangoo:add in 0817
				{
					Value & PG_userpasswordValue = document["PG_userpassword"];
					if (PG_userpasswordValue.IsString())
					{
						userPassword_ = PG_userpasswordValue.GetString();
					}
				}

				if(document.HasMember("TSPLoginSerialNumber"))
				{
					Value & TSPLoginSerialNumberValue = document["TSPLoginSerialNumber"];
					if (TSPLoginSerialNumberValue.IsInt())
					{
						TSPLoginSerialNumber_ = TSPLoginSerialNumberValue.GetInt();
					}
				}

			}
			else
			{
//				printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() parse config error readBuffer:%s\n",readBuffer);
			}
			if(readBuffer != NULL)
			{
				free(readBuffer);
			}
		}
	}

//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TSPServerIp_:%s\n",TSPServerIp_.c_str());
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TSPServerPort_:%d\n",TSPServerPort_);
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TBOX_VIN_:%s\n",TBOX_VIN_.c_str());
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TBOX_ICCID_:%s\n",TBOX_ICCID_.c_str());
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TSPLoginSerialNumberDate_:%ld\n",TSPLoginSerialNumberDate_);
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TSPLoginSerialNumber_:%d\n",TSPLoginSerialNumber_);
//	printf("DSVTSPConnectSVC ConfigInfo::readConfigInfo() TBOX_VERSION_:%s\n",TBOX_VERSION_.c_str());

	if(TSPLoginSerialNumberDate_ <= 0)
	{
		time_t now;  //实例化time_t结构
		time(&now);  //time函数读取现在的时间(国际标准时间非北京时间)，然后传值给now
		now = now + 8 * 3600;  //GMT+8*3600，等于北京时间
		struct tm *timenow;  //实例化tm结构指针
		struct tm timenowInstance;
		timenow = gmtime_r(&now,&timenowInstance);

		TSPLoginSerialNumberDate_ = (timenow->tm_year + 1900)*10000 + (timenow->tm_mon + 1)*100 + timenow->tm_mday;
		TSPLoginSerialNumber_ = 1;
		writeConfigInfo();
	}
	else if(TSPLoginSerialNumber_ <= 0)
	{
		TSPLoginSerialNumber_ = 1;
		writeConfigInfo();
	}
}

void ConfigInfo::writeConfigInfo()
{
	StringBuffer configJsonStrBuffer;
	PrettyWriter<StringBuffer> writer(configJsonStrBuffer);
	writer.StartObject();
	writer.Key("TSPServerIp");
	writer.String(TSPServerIp_.c_str());
	writer.Key("TSPServerPort");
	writer.Int(TSPServerPort_);
	writer.Key("TBOX_VIN");
	writer.String(TBOX_VIN_.c_str());
	writer.Key("TBOX_ICCID");
	writer.String(TBOX_ICCID_.c_str());
	writer.Key("TBOX_VERSION");
	writer.String(TBOX_VERSION_.c_str());
	writer.Key("TSPLoginSerialNumberDate");
	writer.Int64(TSPLoginSerialNumberDate_);
	writer.Key("TSPLoginSerialNumber");
	writer.Int(TSPLoginSerialNumber_);
	writer.Key("PG_username");
	writer.String(username_.c_str());
	writer.Key("PG_userpassword");
	writer.String(userPassword_.c_str());
	writer.Key("PlatformLoginSerialNumber");
	writer.Int(platformLoginSerialNumber_);
	writer.EndObject();

	string configJsonStr = configJsonStrBuffer.GetString();

	int fd = -1;
	fd = open("./TelematicsServicesConfig.json",O_WRONLY|O_TRUNC|O_CREAT|O_SYNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);
	int write_length = write(fd,configJsonStr.c_str(),configJsonStr.size());
	close(fd);
}
