/*
 * ConnectionPGSocket.h
 *
 *  Created on: Mar 13, 2020
 *      Author: yindi
 * Description: 
 */

#ifndef CONNECTIONPGSOCKET_H_
#define CONNECTIONPGSOCKET_H_

#include <atomic>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <vector>
#include <string>
#include <memory>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "Common.h"

class ConnectionManagerApp;

class ConnectionPGSocket
{
public:
	ConnectionPGSocket();
	~ConnectionPGSocket();

	// tcp connnect
	void connectServer();
	void connnectSocketThread();
	bool getSocketAddr(sockaddr_in &_socketaddr);
	bool setExtraSocketConfig();
	void closeSocket();
	void ConnectSocketThread();

	// logic flow with backend
	bool blockForRSA();
	bool blockForPlatformLogin();
	bool blockForAES();
	bool blockForCarLogin();

	void SendRSARequest();
	void PlatformLogin();
	void SendAESKey();
	void CarLogin();
	void SendMsgToCloud(DataUpload _dataUpload); // 打包DataAPP发送过来的数据

	void HandleMsgToCloud(DataUpload &_dataUpload); // 发送前数据的预处理
	void SendPackage(DataUpload &_dataUpload, SendParams &_sendParams); // 按指定格式打包数据并上传

	// recv handle
	void RecvMsgFromCloudThread();
	void tspHandleRecvMsgThread();
	void tspHandleRecvMsg(std::string _tspMsgStr);
	void tspHandleCmd(uint8_t _cmdFlag, uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleCarLogin(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleRealtimeMsg(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleReissueMsg(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleRemoteControl(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleRSA(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandlePlatform(uint8_t _ansFlag, char* _data, short _datalen);
	void tspHandleAES(uint8_t _ansFlag, char* _data, short _datalen);

	// others
	void ResponseRSAPublicKey(int dataLength,char *dataUnitBuffer);
	void SetConnectManagerApp(ConnectionManagerApp* _cma);

private:
	bool connectSocketThreadRunning_{false};
	bool recvMsgFromCloudThreadRunning_{false};
	bool shouldSessionLogout_{false};
	std::atomic<int> socketFd_{-1};
	bool TSPConnected_{false};
	bool AESFlag_{false};
	bool RSAFlag_{false};
	bool Logined_{false};
	bool PlatformLogined_{false};
	ConnectionManagerApp* cma_;

	std::mutex tspMtx_;
	std::condition_variable tspCv_;
	std::vector<std::string> recvTspMsgQueue_;
};


#endif /* CONNECTIONPGSOCKET_H_ */
