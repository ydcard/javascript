#ifndef CONNECTIONMANAGERAPP_H_
#define CONNECTIONMANAGERAPP_H_

#include <iostream>
#include <queue>
#include <mutex>#include <condition_variable>

#include "ConnectionPGSocket.h"
#include "ConnectionManagerAppSink.h"
#include "Common.h"

class TelematicsServices;

class ConnectionManagerApp
{
public:
	ConnectionManagerApp(TelematicsServices* pTelematicsServices);
	virtual ~ConnectionManagerApp();

	void Init();

	void RecvMsgFromApp(DataUpload &_dataUpload);

	void StartSendMsgToCloudThread();
	void SendMsgToCloudThread();

	bool getTSPConnected(); // 获取后台连接状态
	void NotifyPGtoTBOX(std::string _dataUnitBufferStr); // Pangoo车辆控制信息下发
	void NotifyTSPConnected(); // 通知已经与后台建立连接
	void NotifyTSPDisconnected(); // 通知已经与后台断开连接

//	void ReportDataUploadResultToAPP(unsigned long long node_id,int session_id, int method_id, int errorCode, string RecordId, string Type,
//			string RecordBufferHexStr, unsigned int RecordBufferSize, bool Priority);
	void ReportDataUploadResultToAPP(DataUpload _dataUpload, int _errorCode);

private:
	ConnectionPGSocket *pConnectionPANGOO_;
	ConnectionManagerAppSink* pSink_;
	std::vector<DataUpload> tspMsgQueue_;
	std::mutex cmaMutex_;
	std::condition_variable cmaCond_;
	//TSP是否连接，MQTT和EASocket通知到这里，再通知到其他的APP。
	bool TSPConnected_{false};
	bool shouldExitSendMsgToCloudThread_{false};
};
#endif /* CONNECTIONMANAGERAPP_H_ */
