#ifndef CONFIGINFO_H_
#define CONFIGINFO_H_

#include <string>
using namespace std;

class ConfigInfo
{
private:
	ConfigInfo();
	ConfigInfo(const ConfigInfo& _other);
	void readConfigInfo();
public:
	static ConfigInfo* getInstance() {
		static ConfigInfo instance;
		return &instance;
	}
	void writeConfigInfo();
public:
	//配置文件：
	std::string TSPServerIp_; // 后台服务器ip地址
	int TSPServerPort_; // 后台服务器端口号
	std::string TBOX_VIN_; // Tbox所在车辆VIN码
	std::string TBOX_ICCID_; // Tbox的ICCID
	std::string TBOX_VERSION_; // Tbox版本号
	long TSPLoginSerialNumberDate_; // Tbox车辆登录日期
	int TSPLoginSerialNumber_; // Tbox车辆登录序列号

	std::string RSAKeyStr_; // RSA公钥字符串
	int platformLoginSerialNumber_; // 平台登录序列号
	std::string username_; // 用户名
	std::string userPassword_; // 用户密码
	std::string tokenStr_; // TOKEN字符串
};

#endif /* CONFIGINFO_H_ */
