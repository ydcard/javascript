/*
 * Common.h
 *
 *  Created on: Mar 12, 2020
 *      Author: yindi
 * Description: 
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <string>
#include <stdint.h>

// 数据上传类型
#define DATATYPE_DATAUPLOAD				1 // "DataUpload"
#define DATATYPE_HEARTBEAT				2 // "Heartbeat"
#define DATATYPE_PANGOO_WARNING			3 // "PangooWarning"
#define DATATYPE_PANGOO_RESPONSE		4 // "PangooResponse"

#define DATATYPE_CARLOGIN				5 // "CarLogin"
#define DATATYPE_PLATFORMLOGIN			6 // "PlatformLogin"
#define DATATYPE_SENDAESKEY				7 // "SendAESKey"
#define DATATYPE_REQUESTRSA				8 // "RequestRSA"

//Pangoo:用户名和密码的长度
#define USERNAME_STR_LENGTH 12
#define USERPASSWORD_STR_LENGTH 700
#define TOKEN_STR_LENGTH 36
#define VERSION_STR_LENGTH 10

//VIN和ICCID长度
#define VIN_STR_LENGTH   17
#define ICCID_STR_LENGTH 20

#define PG_AesKey "A8943929934B8D11"
#define PG_AesIv "91C0575A40427AFB"
#define AES_BLOCK_SIZE 16

class DataUpload
{
public:
	DataUpload(){}
	int getPackageType() {
		return packageType_;
	}
	void setPackageType(int _ptype) {
		packageType_ = _ptype;
	}
	std::string getBufferStr() {
		return hexBufferStr_;
	}
	void setBufferStr(std::string _bufferStr) {
		hexBufferStr_ = _bufferStr;
	}
	std::string getRawBufferStr() {
		return rawBufferStr_;
	}
	void setRawBufferStr(std::string _rawBufferStr) {
		rawBufferStr_ = _rawBufferStr;
	}
	int getBufferSize() {
		return hexBufferSize_;
	}
	void setBufferSize(int _bufferSize) {
		hexBufferSize_ = _bufferSize;
	}
	int getRawBufferSize() {
		return rawBufferSize_;
	}
	void setRawBufferSize(int _rawBufferSize) {
		rawBufferSize_ = _rawBufferSize;
	}
	bool getRealTime() {
		return realTime_;
	}
	void setRealTime(bool _realTime) {
		realTime_ = _realTime;
	}
	uint64_t getNodeId() {
		return nodeId_;
	}
	void setNodeId(uint64_t _nodeId) {
		nodeId_ = _nodeId;
	}
	int getMethodId() {
		return methodId_;
	}
	void setMethodId(int _methodId) {
		methodId_ = _methodId;
	}

private:
	int packageType_{0}; // 信息类型
	std::string hexBufferStr_; // 信息的数据实体
	int hexBufferSize_{0}; // 信息的数据实体长度
	std::string rawBufferStr_; // 未经加密的原始数据
	int rawBufferSize_{0}; // 未经加密的原始数据长度

	uint64_t nodeId_{0}; // 节点号--用于进程通讯
	int methodId_{0}; // 方法号--用于进程通讯
	bool realTime_{true}; // 是否为实时信号--用于进程通讯
};

struct SendParams
{
	bool checkCarLogin_;
	bool checkPlatformLogin_;
	uint8_t commandId_;
	uint8_t encryptionMode_; // 0x01-不加密,0x02-RSA加密,0x03-AES加密,0xFE-异常,0xFF-无效
};



#endif /* COMMON_H_ */
