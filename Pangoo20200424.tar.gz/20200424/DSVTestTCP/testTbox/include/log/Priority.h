/*
 * Priority.h
 *
 *  Created on: Sep 20, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef PRIORITY_H_
#define PRIORITY_H_

#include <string>


class Priority {
 public:

	static const int MESSAGE_SIZE; // = 8;

	typedef enum {
		LOG_EMERG	= 0,
		LOG_ALERT	= 1,
		LOG_CRIT	= 2,
		LOG_ERROR	= 3,
		LOG_WARN	= 4,
		LOG_NOTICE	= 5,
		LOG_INFO	= 6,
		LOG_DEBUG   = 7,
		LOG_NOTSET	= 8
	} PriorityLevel;

	static const std::string& getPriorityName(int priority) noexcept;

	static int getPriorityValue(const std::string& priorityName);

	static int max();
};



#endif /* PRIORITY_H_ */
