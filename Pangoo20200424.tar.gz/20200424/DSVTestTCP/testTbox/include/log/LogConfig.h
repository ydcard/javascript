/*
 * LogConfig.h
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef LOGCONFIG_H_
#define LOGCONFIG_H_

#define DEFAULT_FILENAME "" // 文件名为空,默认标准输出stdout
#define DEFAULT_FORMAT	"origin" // 暂时只支持origin模式
#define DEFAULT_LOGPATH	"./"
#define DEFAULT_PRIORITY 8
#define DEFAULT_FILECOUNT 10 // 默认存放10个文件
#define DEFAULT_FILESIZE 1024000
#define DEFAULT_USERNAME "desay"

#define MAX_LOGFILE_SIZE 100*1024*1024 // 单个log文件可设置的最大容量:100MB
#define MIN_LOGFILE_SIZE 100*1024 // 单个log文件可设置的最小容量:100KB

#define DEFAULT_WAIT_SECONDS 3000 // 从缓冲区到输出默认最大等待时间为:3000ms


#endif /* LOGCONFIG_H_ */
