/*
 * DsvEncrypt.h
 *
 *  Created on: Mar 14, 2020
 *      Author: yindi
 * Description: 
 */

#ifndef DSVENCRYPT_H_
#define DSVENCRYPT_H_

#include <stdint.h>


class DsvEncrypt
{
public:
	DsvEncrypt(){}
	~DsvEncrypt(){}

	static uint8_t BCC_CheckSum(uint8_t *buf, uint32_t len);
	static void EncryptAES_ECB(unsigned char* in,unsigned char* out,int length);
	static void DecryptAES_ECB(unsigned char* in,unsigned char* out, int length);
	static int EncryptRSA(unsigned char* in,unsigned char* out,int len);
	static int Base64_encrypt(char *in, int len, char *out);

	static int Base64_decrypt(char *in, int len, char *out);

};



#endif /* DSVENCRYPT_H_ */
