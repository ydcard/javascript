#ifndef TELEMATICSSERVICES_H_
#define TELEMATICSSERVICES_H_

#include "ConnectionManagerApp.h"
#include "MacroDefine.h"

#include "IInterfaceBinderIPC.h"
#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>

#include <list>
using namespace std;

class TelematicsServices: public BnInterfaceBinderIPC, public ConnectionManagerAppSink
{
public:
	virtual ~TelematicsServices();
	static TelematicsServices* getInstance() {
		static TelematicsServices instance;
		return &instance;
	}

	void BinderIPCThread(); // 单独启动一个线程进行Binder服务的提供
	void StartApp();

protected:
    //BinderIPC
	virtual void ASyncCall(unsigned long long source_id,int method_id,std::string contentJsonStr); // DataAPP->TSP传输通道
	//函数接口用于注册callback函数接口
	virtual void setCallback(unsigned long long callbackNodeId,const sp<ICallBackBinderIPC> &callback); // 注册cb,TSP->DataAPP传输通道

	virtual void OnPGtoTBOX(std::string notifyJsonStr);// 车辆控制信息下发
	virtual void OnTSPConnected();  // 通知DataAPP已经与后台建立连接
	virtual void OnTSPDisconnected(); // 通知DataAPP已经与后台断开连接
	virtual void OnASyncCallResult(unsigned long long node_id, int method_id, string resultJsonStr); // 对DataAPP上传数据的处理结果进行反馈通知
	virtual void OnRecvNotify(unsigned long long node_id, string notifyJsonStr); // 预留---旧的车辆控制


private:
	TelematicsServices();
	ConnectionManagerApp *pConnectionManagerApp_;
	std::list<sp<ICallBackBinderIPC>> callbackList_; // 回调类集合

};

#endif /* TELEMATICSSERVICES_H_ */
