/*
 * DSVLog.h
 *
 *  Created on: Sep 18, 2018
 *      Author: desay-sv
 */

#ifndef DSVLOG_H_
#define DSVLOG_H_

#include <iostream>
#include <stddef.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdlib.h>
#include <stdio.h>
#include <mutex>
#include <string>
#include <string.h>
#include <errno.h>
#include <set>
#include <sstream>
#include <mutex>
#include <pthread.h>
#include <chrono>
#include <fstream>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <iomanip>
#include <stdint.h>
#include "prettywriter.h"
#include "document.h"
#include "stringbuffer.h"
#include "filereadstream.h"
#include "filewritestream.h"
#include <regex>

#define FILE_SIZE 1024

enum LogLevel{
	YD_ERR		= 0,
	YD_WARN  	= 1,
	YD_INFO	 	= 2,
	YD_PERIOD 	= 3,
	YD_DEBUG	= 4,
	YD_ALL		= 5
};

class DSVYdLog{
public:
	static DSVYdLog *GetInstance();
	int GetSumOfLogfile(std::string __path);//获取log文件个数--仅在构造函数之后调用，主要作用是检查命名有没有连续以及获得FileFlag的值
	void DDLOG(int __loglevel, std::string tag, std::string __logstr);//log记录函数
	void SortRule();//排序规则--每次需要进行文件更名的时候使用（逆序进行更名)
	void resetFileSerial(std::set<int> Set);//重新排序--仅在构造函数之后使用（当文件夹命名没有中缺失文件的时候调用，采用顺序更名)
	void addNewLog();//添加新的log文件--每次需要进行文件更名的时候使用
	void readConfig();//加入配置文件模式下的log机制，看情况使用
	~DSVYdLog();
private:
	DSVYdLog();
	static DSVYdLog *m_instance;
	int FileFlag;  //记录文件个数
	std::mutex my_mutex;

// below only use in config module
private:
	std::string m_logFilePrefix;
	std::string m_logFileName;
	std::string m_logPath;
	int m_loglevel;
	int m_logFileAmount;
	long int m_logFileMaxBytes;
};

inline void YDLOG(int __loglevel, std::string tag, std::string __logstr){
	DSVYdLog* Log = DSVYdLog::GetInstance();
	Log->DDLOG(__loglevel,tag,__logstr);
}

#endif /* DSVLOG_H_ */
