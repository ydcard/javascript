#ifndef CONNECTIONMANAGERAPPSINK_H_
#define CONNECTIONMANAGERAPPSINK_H_

#include <string>

class ConnectionManagerAppSink
{
public:
	ConnectionManagerAppSink(){}
	virtual ~ConnectionManagerAppSink(){}
	virtual void OnPGtoTBOX(std::string ESJsonStr) = 0;// 车辆控制
	virtual void OnTSPConnected() = 0;
	virtual void OnTSPDisconnected() = 0;
	virtual void OnASyncCallResult(unsigned long long node_id, int method_id, std::string resultJsonStr) = 0;
	virtual void OnRecvNotify(unsigned long long node_id, std::string notifyJsonStr) = 0;
};

#endif /* CONNECTIONMANAGERAPPSINK_H_ */
