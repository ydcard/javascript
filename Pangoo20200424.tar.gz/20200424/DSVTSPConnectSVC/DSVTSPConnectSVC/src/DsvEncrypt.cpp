/*
 * DsvEncrypt.cpp
 *
 *  Created on: Mar 14, 2020
 *      Author: yindi
 * Description: 
 */

#include "DsvEncrypt.h"
#include "ConfigInfo.h"
#include <openssl/aes.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/ossl_typ.h>
#include <string>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/pem.h>
#include "Common.h"

uint8_t DsvEncrypt::BCC_CheckSum(uint8_t *buf, uint32_t len)
{
	uint32_t i;
	uint8_t checksum = 0;
	for (i = 0; i < len; i++)
	{
		checksum ^= *buf++;
	}
	return checksum;
}

void DsvEncrypt::EncryptAES_ECB(unsigned char* in,unsigned char* out,int length)
{
//	int length = ((strlen((char *)in)+AES_BLOCK_SIZE-1)/AES_BLOCK_SIZE)*AES_BLOCK_SIZE;
	AES_KEY aes;
	if(AES_set_encrypt_key((unsigned char*)PG_AesKey, AES_BLOCK_SIZE*8, &aes) < 0)
	{
		return;
	};
	int len = 0;
	/*循环解密*/
	while(len < length) {
		AES_encrypt(in+len, out+len, &aes);
		len += AES_BLOCK_SIZE;
	}
}

void DsvEncrypt::DecryptAES_ECB(unsigned char* in,unsigned char* out, int length)
{
//	int length = ((Plen+AES_BLOCK_SIZE-1)/AES_BLOCK_SIZE)*AES_BLOCK_SIZE;
	AES_KEY aes;
	if(AES_set_decrypt_key((unsigned char*)PG_AesKey, AES_BLOCK_SIZE*8, &aes) < 0)
	{
		return;
	};
	int len = 0;
	/*循环解密*/
	while(len < length) {
		AES_decrypt(in+len, out+len, &aes);
		len += AES_BLOCK_SIZE;
	}
//	printf("len is %d\n",len);
}

//采用RSA加密;TODO:如果length()的长度不满足RSA长度，原因可能是包含0x00，这个后续出现问题再改动
int DsvEncrypt::EncryptRSA(unsigned char* in,unsigned char* out,int len)
{
	std::string PKey = ConfigInfo::getInstance()->RSAKeyStr_;
////	char *Gkey = (char *)PKey.c_str();
//	char Gkey[400];
//	strcpy(Gkey,PKey.c_str());
//	int PublicKeyLen = ConfigInfo::getInstance()->RSAKeyStr_.length();
//	RSA *EncryptRsa = d2i_RSAPublicKey(NULL, (const unsigned char**)&Gkey, PublicKeyLen);
////	int nLen = RSA_size(EncryptRsa);
//	RSA_public_encrypt(len, in, out, EncryptRsa, RSA_NO_PADDING);
//    std::string strRet;
    BIO *bio = NULL;
    RSA* pRSAPublicKey = NULL;

    bio = BIO_new_mem_buf((char*)PKey.c_str(),-1);
    pRSAPublicKey = PEM_read_bio_RSA_PUBKEY(bio,NULL,NULL,NULL);

    int nLen = RSA_size(pRSAPublicKey);
//    char* pEncode = new char[nLen + 1];
    int ret = RSA_public_encrypt(len, (const unsigned char*)in, (unsigned char*)out, pRSAPublicKey, RSA_PKCS1_PADDING);
    if (ret >= 0)
    {
//    	memcpy(out,pEncode,ret);
//        strRet = std::string(pEncode, ret);
//        printf("ret is %d\n",ret);
    }
//    delete[] pEncode;
    return ret;
}

int DsvEncrypt::Base64_encrypt(char *in, int len, char *out){
	return EVP_EncodeBlock((unsigned char*)out, (const unsigned char*)in, len);
}

int DsvEncrypt::Base64_decrypt(char *in, int len, char *out){
	return EVP_DecodeBlock((unsigned char*)out, (const unsigned char*)in, len);
}




