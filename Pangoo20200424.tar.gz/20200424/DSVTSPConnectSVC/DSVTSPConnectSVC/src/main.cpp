#include "TelematicsServices.h"
#include <stdio.h>
#include "logging.h"

int main(void)
{
	LOG_CONFIG_FILE("./TLogConfig.json");
	LOG_INFO << "============DSVTSPConnectSVC BEGIN=========";
	TelematicsServices *svr = TelematicsServices::getInstance();
	svr->StartApp();
	while (true) {
		sleep(10);
	}
	return 0;
}
