/*
 * TelematicsServices.cpp
 *
 *  Created on: May 16, 2017
 *      Author: wsong
 */

#include "writer.h"
#include "prettywriter.h"
#include "stringbuffer.h"
#include "document.h"
using namespace rapidjson;

#include <stdio.h>
#include <thread>
#include <sys/prctl.h>
#include <iostream>

#include "TelematicsServices.h"
#include "logging.h"
#include "ConfigInfo.h"
#include "Common.h"

#define DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_PANGOO           4   //YinDi:添加

TelematicsServices::TelematicsServices()
{
}

TelematicsServices::~TelematicsServices()
{
}

void TelematicsServices::BinderIPCThread()
{
	prctl(PR_SET_NAME,"TSP_SVC_Binder");

	sp<ProcessState> proc(ProcessState::self());
	sp<IServiceManager> sm = defaultServiceManager();
	int ret = sm->addService(String16("com.desay.DSVTSPConnectSVC"), TelematicsServices::getInstance());
	proc->setThreadPoolMaxThreadCount(30);
	proc->startThreadPool();
	IPCThreadState::self()->joinThreadPool(true);

	LOG_INFO << "Binder init finish";
}

void TelematicsServices::OnTSPConnected()
{
	LOG_INFO << "tsp connected";

	StringBuffer resultJsonStrBuffer;
	Writer<StringBuffer> writer(resultJsonStrBuffer);
	writer.StartObject();
	writer.Key("NotifyType");
	writer.String("TSPConnectStatus");
	writer.Key("TSPConnectStatus");
	writer.String("online");
	writer.EndObject();
	string resultJsonStr = resultJsonStrBuffer.GetString();
	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
//		printf("DSVTSPConnectSVC TelematicsServices::OnTSPConnected() cb->callbackNodeId:%llx\n",cb->callbackNodeId);
		if (cb->callbackNodeId == NODE_APP_DATA_UPLOAD ) {
		    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_NOTIFY,resultJsonStr);
		}
	}
}

void TelematicsServices::OnTSPDisconnected()
{
	LOG_INFO << "tsp disconnected";

	StringBuffer resultJsonStrBuffer;
	Writer<StringBuffer> writer(resultJsonStrBuffer);
	writer.StartObject();
	writer.Key("NotifyType");
	writer.String("TSPConnectStatus");
	writer.Key("TSPConnectStatus");
	writer.String("offline");
	writer.EndObject();

	string resultJsonStr = resultJsonStrBuffer.GetString();
	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
		//printf("DSVTSPConnectSVC TelematicsServices::OnTSPDisconnected() cb->callbackNodeId:%llx\n",cb->callbackNodeId);
		if (cb->callbackNodeId == NODE_APP_DATA_UPLOAD ) {
		    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_NOTIFY,resultJsonStr);
		}
	}
}

//YinDi:添加蓥石数据Service->TBOX
void TelematicsServices::OnPGtoTBOX(std::string notifyJsonStr)
{
	LOG_INFO << "car cmd : " << notifyJsonStr;

	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
		//printf("DSVTSPConnectSVC TelematicsServices::OnTSPDisconnected() cb->callbackNodeId:%llx\n",cb->callbackNodeId);
		if (cb->callbackNodeId == NODE_APP_DATA_UPLOAD ) {
		    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_PANGOO,notifyJsonStr);
		}
	}
}


void TelematicsServices::OnASyncCallResult(unsigned long long node_id, int method_id, std::string resultJsonStr)
{
	LOG_INFO << "DataAPP cb response";

	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
		//printf("DSVTSPConnectSVC TelematicsServices::OnASyncCallResult() cb->callbackNodeId:%llx\n",cb->callbackNodeId);
		if (cb->callbackNodeId == node_id) {
		    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_ASYNCCALL_RESULT,resultJsonStr);
		    break;
		}
	}
}

void TelematicsServices::OnRecvNotify(unsigned long long node_id, std::string notifyJsonStr)
{
	LOG_INFO << "not use";

	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
		//printf("DSVTSPConnectSVC TelematicsServices::OnRecvNotify() cb->callbackNodeId:%llx\n",cb->callbackNodeId);
		if (cb->callbackNodeId == node_id) {
		    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_NOTIFY,notifyJsonStr);
		    break;
		}
	}
}

void TelematicsServices::StartApp()
{
	LOG_INFO << "BEGIN: startAPP";
	pConnectionManagerApp_ = new ConnectionManagerApp(this);

	std::thread binderTask(&TelematicsServices::BinderIPCThread, this);  //带参数子线程
	binderTask.detach();
	LOG_INFO << "END: startAPP";
}

// 接收从DataApp上传的数据，第一阶段只做实时信息上传这一条需求，对应到这一部分只会传输DataUpload和HeartBeat这两类数据
void TelematicsServices::ASyncCall(unsigned long long source_id,int method_id,std::string contentJsonStr)
{
	LOG_INFO << contentJsonStr;

	const char *pContentJsonStr = contentJsonStr.c_str();
	int session_id = 0;

	if (method_id == TELEMATICS_SERVICES_FUNCTION_CHECK_TSP_CONNECTED) { // 检查与后台的连接状态
		StringBuffer resultJsonStrBuffer;
		Writer<StringBuffer> writer(resultJsonStrBuffer);
		writer.StartObject();
		writer.Key("NotifyType");
		writer.String("TSPConnectStatus");
		writer.Key("TSPConnectStatus");
		if (source_id == NODE_APP_DATA_UPLOAD ) {
			if (pConnectionManagerApp_->getTSPConnected()) {
				//YinDi:因为测试的时候没有使用到GB，所以如果不自己添加，这里没有办法设置为online，
				//所以我在ConnectionManagerApp的NotifyTSPConnected()中添加了m_TSPConnected = true;
				writer.String("online");
				LOG_INFO << "already connect";
			}
			else {
				writer.String("offline");
				LOG_INFO << "not connect";
			}
		}
		writer.EndObject();

		string resultJsonStr = resultJsonStrBuffer.GetString();
		for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
			sp<ICallBackBinderIPC> cb = (*iterator);
			if (cb->callbackNodeId == source_id) {
			    cb->NotifyCallBack(DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_NOTIFY,resultJsonStr);
			    break;
			}
		}
	}
	else if (method_id == TELEMATICS_SERVICES_FUNCTION_COMMON) { // 数据上传
		if (pConnectionManagerApp_->getTSPConnected() == false) {
			LOG_INFO << "disconnect";
			Document document;
			document.Parse(contentJsonStr.c_str());
			if (document.IsObject() && document.IsNull() == false) {
				if (document.HasMember("ResquestType")) {
					Value & ResquestType = document["ResquestType"];
					if (ResquestType.IsString()) {
						// 如果上传的是Dataupload那么进行回应
						if (string(ResquestType.GetString()) == string(TELEMATICS_SERVICES_FUNCTION_DATA_UPLOAD_STRING)) {
							LOG_WARN << "Server Disconnected";

							StringBuffer resultJsonStrBuffer;
							Writer<StringBuffer> writer(resultJsonStrBuffer);
							writer.StartObject();
							writer.Key("ResquestType");
							writer.String("DataUpload");

							writer.Key("ResponseResult");
							writer.Bool(false);

							writer.Key("ResponseErrorCode");
							writer.Int(TELEMATICS_RESULT_NETWORK_ERROR);

							if (document.HasMember("RecordBufferHexStr")) {
								Value & BufferHexStr = document["RecordBufferHexStr"];
								if (BufferHexStr.IsString()) {
									std::string hexStr = BufferHexStr.GetString();
									writer.String(hexStr.c_str());
								}
							}
							if (document.HasMember("RecordBufferSize")) {
								Value & BufferHexSize = document["RecordBufferSize"];
								if (BufferHexSize.IsInt()) {
									writer.Int(BufferHexSize.GetInt());
								}
							}

							writer.EndObject();

							std::string resultJsonStr = resultJsonStrBuffer.GetString();

							OnASyncCallResult(source_id,method_id,resultJsonStr);
							return;

						}
					}
				}
			}
			else
			{
				LOG_ERROR << "error message";
				return;
				//printf("DSVTSPConnectSVC TelematicsServices::ASyncCall() TELEMATICS_RESULT_NETWORK_ERROR parse contentJsonStr error:%s\n",contentJsonStr.c_str());
			}
		}
		Document document;
		document.Parse(pContentJsonStr);
		if (document.IsObject() && document.IsNull() == false) {
			if (document.HasMember("ResquestType")) {
				Value & ResquestType = document["ResquestType"];
				if (ResquestType.IsString()) {
					char str_type[128];
					sprintf(str_type,"ResquestType is %s",ResquestType.GetString());
					LOG_INFO << str_type;
//					std::cout<<"请求的类型是："<<string(ResquestType.GetString())<<std::endl;
					if (string(ResquestType.GetString()) == string(TELEMATICS_SERVICES_FUNCTION_DATA_UPLOAD_STRING)) { // 周期数据以及补发数据
						LOG_INFO << "Recieve realtime&&reissue message from DataAnalysisAPP";

						Value & RecordBufferHexStr = document["RecordBufferHexStr"]; // 数据包
						string RecordBufferHexStrString = RecordBufferHexStr.GetString();
						LOG_INFO << "DataPayload: " << RecordBufferHexStrString;

						Value & RecordBufferSize = document["RecordBufferSize"]; // 数据包大小
						int RecordBufferSizeInt = RecordBufferSize.GetInt();

						Value & RecordRealTime = document["RecordRealTime"];
						bool RecordRealTimeBool = RecordRealTime.GetBool();

						DataUpload dataBlob;
						dataBlob.setRawBufferStr(RecordBufferHexStrString);
						dataBlob.setRawBufferSize(RecordBufferSizeInt);
						dataBlob.setRealTime(RecordRealTimeBool);
						dataBlob.setPackageType(DATATYPE_DATAUPLOAD);
						dataBlob.setNodeId(source_id);
						dataBlob.setMethodId(method_id);

						pConnectionManagerApp_->RecvMsgFromApp(dataBlob);
					}
					else if(string(ResquestType.GetString()) == string(TELEMATICS_SERVICES_FUNCTION_PANGOO_RESPONSE_DATA)) {
						LOG_INFO << "Recieve Pangoo response message from DataAnalysisAPP";
						Value & RecordBufferHexStr = document["RecordBufferHexStr"];
						string RecordBufferHexStrString = RecordBufferHexStr.GetString();
						Value & RecordBufferSize = document["RecordBufferSize"];
						int RecordBufferSizeInt = RecordBufferSize.GetInt();

						DataUpload dataBlob;
						dataBlob.setRawBufferStr(RecordBufferHexStrString);
						dataBlob.setRawBufferSize(RecordBufferSizeInt);
						dataBlob.setRealTime(true);
						dataBlob.setPackageType(DATATYPE_PANGOO_RESPONSE);
						dataBlob.setNodeId(source_id);
						dataBlob.setMethodId(method_id);

						pConnectionManagerApp_->RecvMsgFromApp(dataBlob);
					}
					else if(string(ResquestType.GetString()) == string(TELEMATICS_SERVICES_FUNCTION_PANGOO_WARN_DATA)) {
						LOG_INFO << "Recieve Pangoo warn data message from DataAnalysisAPP";
						Value & RecordBufferHexStr = document["RecordBufferHexStr"];
						string RecordBufferHexStrString = RecordBufferHexStr.GetString();
						Value & RecordBufferSize = document["RecordBufferSize"];
						int RecordBufferSizeInt = RecordBufferSize.GetInt();

						DataUpload dataBlob;
						dataBlob.setRawBufferStr(RecordBufferHexStrString);
						dataBlob.setRawBufferSize(RecordBufferSizeInt);
						dataBlob.setRealTime(true);
						dataBlob.setPackageType(DATATYPE_PANGOO_WARNING);
						dataBlob.setNodeId(source_id);
						dataBlob.setMethodId(method_id);

						pConnectionManagerApp_->RecvMsgFromApp(dataBlob);
					}
					else if(string(ResquestType.GetString()) == string(TELEMATICS_SERVICES_FUNCTION_HEARTBEAT)) {
						LOG_INFO << "Recieve heartbeat message from DataAnalysisAPP";
						DataUpload dataBlob;
						dataBlob.setRealTime(true);
						dataBlob.setPackageType(DATATYPE_HEARTBEAT);
						dataBlob.setNodeId(source_id);
						dataBlob.setMethodId(method_id);

						pConnectionManagerApp_->RecvMsgFromApp(dataBlob);
					}
				}
			}
		}
		else {
			//printf("DSVTSPConnectSVC TelematicsServices::ASyncCall() parse error pContentJsonStr:%s\n",pContentJsonStr);
		}
	}
}

//函数接口用于注册callback函数接口
void TelematicsServices::setCallback(unsigned long long callbackNodeId,const sp<ICallBackBinderIPC> &callback)
{
	callback->callbackNodeId = callbackNodeId;
	for (list<sp<ICallBackBinderIPC>>::iterator iterator = callbackList_.begin(); iterator != callbackList_.end(); ++iterator) {
		sp<ICallBackBinderIPC> cb = (*iterator);
		if (cb->callbackNodeId == callback->callbackNodeId) {
			callbackList_.remove(cb);
			break;
		}
	}
	callbackList_.push_back(callback);
	LOG_INFO << "setcallback success";
}
