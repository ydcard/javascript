#include "ConnectionManagerApp.h"
#include <stddef.h>
#include <cstdio>
#include <cstring>
#include "curl/curl.h"
#include "ByteBuffer.h"
#include <thread>
#include <time.h>
#include <stdlib.h>
#include "ConfigInfo.h"
#include "writer.h"
#include "stringbuffer.h"
#include "document.h"
using namespace rapidjson;
#include "MacroDefine.h"
#include "TelematicsServices.h"
#include <sys/prctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/inotify.h>
#include <iostream>
#include "logging.h"

void ConnectionManagerApp::SendMsgToCloudThread()
{
	prctl(PR_SET_NAME,"CMASendMsg");

	while (shouldExitSendMsgToCloudThread_ == false) {
		std::unique_lock < std::mutex > lock(cmaMutex_);
		while (!tspMsgQueue_.empty()) {
			DataUpload tscm = tspMsgQueue_.front();
			tspMsgQueue_.erase(tspMsgQueue_.begin());
			if (pConnectionPANGOO_ != nullptr) {
				LOG_INFO << "send to cloud";
				pConnectionPANGOO_->SendMsgToCloud(tscm);
			}
		}
		LOG_INFO << "block send";
		cmaCond_.wait(lock);
	}
}

ConnectionManagerApp::ConnectionManagerApp(TelematicsServices* pTelematicsServices)
{
	LOG_INFO << "enter connectionMgrApp";
	pConnectionPANGOO_ = nullptr;
	pSink_ = pTelematicsServices;

	Init();
	StartSendMsgToCloudThread();
//	InitNetworkSignalWatch(); // 如果存在本地网络状态监听的文件,那么这个是有意义的
}

ConnectionManagerApp::~ConnectionManagerApp()
{
	LOG_INFO << "exit connectionMgrApp";
	delete pConnectionPANGOO_;
	pConnectionPANGOO_ = nullptr;
}

void ConnectionManagerApp::Init()
{
	LOG_INFO << "init";
	if (pConnectionPANGOO_ == nullptr) {
		printf("111111111111111111111111111111111111\n");
		pConnectionPANGOO_ = new ConnectionPGSocket();
		pConnectionPANGOO_->SetConnectManagerApp(this);
	}
}

void ConnectionManagerApp::StartSendMsgToCloudThread()
{
	std::thread sendMsgToCloudtask(&ConnectionManagerApp::SendMsgToCloudThread, this);  //带参数子线程
	sendMsgToCloudtask.detach();
}

void ConnectionManagerApp::RecvMsgFromApp(DataUpload &_dataUpload)
{
	LOG_INFO << "recv msg from app";
	std::unique_lock < std::mutex > lock(cmaMutex_);
	tspMsgQueue_.push_back(_dataUpload);
	cmaCond_.notify_one();
}

bool ConnectionManagerApp::getTSPConnected()
{
//	TSPConnected_ = true; // FIXME: test DataAPP communicate with TspAPP
	return TSPConnected_;
}

//通知TSP已经连接成功
void ConnectionManagerApp::NotifyTSPConnected()
{
	LOG_INFO << "notify connected";
	TSPConnected_ = true; // 这里的TSPConnected与ConnectPG中的是不一样的，所以要设置为true
	if (pSink_) {
		pSink_->OnTSPConnected();
	}
}

//YinDi:添加EStoTBOX
void ConnectionManagerApp::NotifyPGtoTBOX(string _dataUnitBufferStr)
{
	LOG_INFO << "notify Pangoo CarCmd";
	if (pSink_) {
		pSink_->OnPGtoTBOX(_dataUnitBufferStr);
	}
}

//通知TSP已经断开连接
void ConnectionManagerApp::NotifyTSPDisconnected()
{
	LOG_INFO << "notify disconnected";
	TSPConnected_ = false;
	if (pSink_) {
		pSink_->OnTSPDisconnected();
	}
}

// 这一部分涉及数据补发逻辑
void ConnectionManagerApp::ReportDataUploadResultToAPP(DataUpload _dataUpload, int _errorCode)
{
	LOG_INFO << "recv dataupload result";
	if (pSink_) {
		StringBuffer resultJsonStrBuffer;
		Writer<StringBuffer> writer(resultJsonStrBuffer);
		writer.StartObject();
		writer.Key("ResquestType");
		writer.String("DataUpload");
		if (_errorCode == TELEMATICS_RESULT_SUCCESS) {
			writer.Key("ResponseResult");
			writer.Bool(true);
		}
		else {
			writer.Key("ResponseResult");
			writer.Bool(false);
		}
		writer.Key("ResponseErrorCode");
		writer.Int(_errorCode);

		writer.Key("RecordBufferHexStr");
		writer.String(_dataUpload.getRawBufferStr().c_str());
		writer.Key("RecordBufferSize");
		writer.Int(_dataUpload.getRawBufferSize());
		writer.EndObject();

		string resultJsonStr = resultJsonStrBuffer.GetString();
		pSink_->OnASyncCallResult(_dataUpload.getNodeId(), _dataUpload.getMethodId(), resultJsonStr);
	}
}
