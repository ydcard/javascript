/*
 * ConnectionPGSocket.cpp
 *
 *  Created on: Mar 11, 2020
 *      Author: yindi
 * Description: 
 */

#include <chrono>
#include <iostream>
#include <sys/prctl.h> // prctl
#include <string.h>
#include <netdb.h> // getaddrinfo
#include <netinet/tcp.h> // setsockopt   SOL_TCP
#include <sys/ioctl.h> // ioctl
#include <linux/sockios.h> // ioctl SIOCOUTQ
#include "ByteBuffer.h"
#include "logging.h"
#include "ConfigInfo.h"
#include "ConnectionPGSocket.h"
#include "ConnectionManagerApp.h"
#include "DsvEncrypt.h"

ConnectionPGSocket::ConnectionPGSocket()
{
	LOG_INFO << "Pangoo Connect";
	std::thread startTspHandleRecvMsgThread(&ConnectionPGSocket::tspHandleRecvMsgThread, this);
	startTspHandleRecvMsgThread.detach();
	connectServer(); // FIXME: no cloud server
}

ConnectionPGSocket::~ConnectionPGSocket()
{
}

void ConnectionPGSocket::connectServer()
{
	std::thread startConnectSocketThread(&ConnectionPGSocket::ConnectSocketThread, this);
	startConnectSocketThread.detach();
}

void ConnectionPGSocket::ConnectSocketThread()
{
	prctl(PR_SET_NAME,"PGConnect");

	LOG_INFO << "Enter Connect Thread";

	if (connectSocketThreadRunning_) {
		LOG_INFO << "repeat open thread!";
		return;
	}
	connectSocketThreadRunning_ = true;
	while (true) {
		if (shouldSessionLogout_ == false) {
			LOG_INFO << "Try Connect!";
			//创建套接字
			socketFd_ = socket(AF_INET, SOCK_STREAM, 0);
			if (socketFd_ == -1) {
				LOG_ERROR << "socket error!";
				break;
			}

			//向服务器（特定的IP和端口）发起请求
			struct sockaddr_in serv_addr;
			if (getSocketAddr(serv_addr) == false) {
				LOG_ERROR << "socketaddr error";
				break;
			}
			setExtraSocketConfig();

			int connResult = connect(socketFd_, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
			if (connResult < 0) {
				LOG_ERROR << "connect error";
				closeSocket();
				break;
			}
			else {
				if (shouldSessionLogout_ == false) {
					TSPConnected_ = true;
					Logined_ = false;
				}
				else {
					LOG_INFO << "logout";
					closeSocket();
					break;
				}
				break;
			}
		}
		else {
			LOG_INFO << "logout";
			break;
		}
	}
	// 按照Pangoo-2018项目的逻辑顺序进行处理
	if (TSPConnected_) {
		LOG_INFO << "TCP Connect Success";
		if (shouldSessionLogout_ == false) {
			std::thread recvMsgFormCloudTask(&ConnectionPGSocket::RecvMsgFromCloudThread, this);
			recvMsgFormCloudTask.detach();
			if (!blockForRSA()) {
				LOG_INFO << "未收到应答: RSA秘钥";
				connectSocketThreadRunning_ = false;
				return;
			}
			if (!blockForPlatformLogin()) {
				LOG_INFO << "未收到应答: 平台登录";
				connectSocketThreadRunning_ = false;
				return;
			}
			if (!blockForAES()) {
				LOG_INFO << "未收到应答: AES发送";
				connectSocketThreadRunning_ = false;
				return;
			}
			if (!blockForCarLogin()) {
				LOG_INFO << "未收到应答: 车辆登录";
				connectSocketThreadRunning_ = false;
				return;
			}
		}
		else {
			LOG_INFO << "logout";
			closeSocket();
		}
	}
	connectSocketThreadRunning_ = false;
	LOG_INFO << "TCP Connect End";
}

bool ConnectionPGSocket::HexStrToByte(const std::string& hexStr, char *output)
{
	const char* const hex = "0123456789ABCDEF";
	size_t len = hexStr.length();
	int k = 0;
	if (len & 1)
	{
		return false;
	}
	for (size_t i = 0; i < len; i += 2)
	{
		char a, b;
		a = hexStr[i];
		const char* p = std::lower_bound(hex, hex + 16, a);
		if (*p != a)
		{
			return false;
		}
		b = hexStr[i + 1];
		const char* q = std::lower_bound(hex, hex + 16, b);
		if (*q != b)
		{
			return false;
		}
		output[k++] = ((p - hex) << 4) | (q - hex);
	}
	return true;
}

bool ConnectionPGSocket::getSocketAddr(sockaddr_in &_socketaddr)
{
	memset(&_socketaddr, 0, sizeof(_socketaddr));
	_socketaddr.sin_family = AF_INET;  //使用IPv4地址
	_socketaddr.sin_addr.s_addr = inet_addr(ConfigInfo::getInstance()->TSPServerIp_.c_str());  //具体的IP地址
	if (_socketaddr.sin_addr.s_addr == INADDR_NONE) {
		// 如果输入的是英文域名比如"www.baidu.com",那么会使用到这里
		LOG_INFO << "Try getaddrinfo!";
		struct addrinfo hints;
		struct addrinfo *res = NULL, *cur = NULL;
		int ret;
		struct sockaddr_in *addr;
		char ipbuf[16] = {'\0'};
		memset(&hints, 0, sizeof(struct addrinfo));
		hints.ai_family = AF_INET; /* Allow IPv4 */
		hints.ai_flags = AI_PASSIVE; /* For wildcard IP address */
		hints.ai_protocol = IPPROTO_TCP; /* Any protocol */
		hints.ai_socktype = SOCK_STREAM;

		ret = getaddrinfo(ConfigInfo::getInstance()->TSPServerIp_.c_str(),NULL,&hints,&res);
		if (ret == -1) {
			LOG_ERROR << "getaddrinfo err!";
			std::this_thread::sleep_for(std::chrono::seconds(1));

			shutdown(socketFd_,SHUT_RDWR);
			close(socketFd_);
			return false;
		}
		for (cur = res; cur != NULL; cur = cur->ai_next) {
			addr = (struct sockaddr_in *)cur->ai_addr;
			printf("%s\n", inet_ntop(AF_INET,&addr->sin_addr, ipbuf, 16));
			_socketaddr.sin_addr.s_addr = inet_addr((char*)inet_ntop(AF_INET,&addr->sin_addr, ipbuf, 16));
			LOG_INFO << "getaddrinfo OK!";
		}
		freeaddrinfo(res);
	}
	_socketaddr.sin_port = htons(ConfigInfo::getInstance()->TSPServerPort_);  //端口
	return true;
}

bool ConnectionPGSocket::setExtraSocketConfig()
{
	setsockopt(socketFd_, SOL_SOCKET, SO_BINDTODEVICE, "rmnet_data0", strlen("rmnet_data0"));
	int setsockoptResult = -1;
	//KeepAlive实现，以秒为单位
	int keepAlive = 1;//设定KeepAlive
	int keepIdle = 1;//开始首次KeepAlive探测前的TCP空闭时间
	int keepInterval = 1;//两次KeepAlive探测间的时间间隔
	int keepCount = 3;//判定断开前的KeepAlive探测次数
	int enable = 1;//Disable the Nagle (TCP No Delay) algorithm
	struct linger so_linger;
	so_linger.l_onoff = 0;
	so_linger.l_linger = 0;
	bool ret = true;
	setsockoptResult = setsockopt(socketFd_,SOL_SOCKET,SO_KEEPALIVE,(void*)&keepAlive,sizeof(keepAlive));
	if (setsockoptResult == -1) {
		ret = false;
		LOG_DEBUG << "setsockopt SO_KEEPALIVE error";
	}
	setsockoptResult = setsockopt(socketFd_,SOL_TCP,TCP_KEEPIDLE,(void *)&keepIdle,sizeof(keepIdle));
	if (setsockoptResult == -1) {
		ret = false;
		LOG_DEBUG << "setsockopt TCP_KEEPIDLE error";
	}
	setsockoptResult = setsockopt(socketFd_,SOL_TCP,TCP_KEEPINTVL,(void *)&keepInterval,sizeof(keepInterval));
	if (setsockoptResult == -1) {
		ret = false;
		LOG_DEBUG << "setsockopt TCP_KEEPINTVL error";
	}
	setsockoptResult = setsockopt(socketFd_,SOL_TCP,TCP_KEEPCNT,(void *)&keepCount,sizeof(keepCount));
	if(setsockoptResult == -1)
	{
		ret = false;
		LOG_DEBUG << "setsockopt TCP_KEEPCNT error";
	}
	setsockoptResult = setsockopt(socketFd_,IPPROTO_TCP,TCP_NODELAY,(void*)&enable,sizeof(enable));//禁用Nagle算法，避免TCP沾包
	if (setsockoptResult == -1) {
		ret = false;
		LOG_DEBUG << "setsockopt TCP_NODELAY error";
	}
	setsockoptResult = setsockopt(socketFd_,SOL_SOCKET,SO_LINGER,&so_linger,sizeof(so_linger));
	if (setsockoptResult == -1) {
		ret = false;
		LOG_DEBUG << "setsockopt SO_LINGER error";
	}
	return ret;
}

void ConnectionPGSocket::closeSocket()
{
	LOG_INFO << "close socket";
	shutdown(socketFd_,SHUT_RDWR);
	close(socketFd_);
	socketFd_ = -1;

	Logined_ = false;
	AESFlag_ = false;
	RSAFlag_ = false;
	PlatformLogined_ = false;
	TSPConnected_ = false;
	if (cma_ != NULL) {
		cma_->NotifyTSPDisconnected();
	}
	tspCv_.notify_all();

	if (shouldSessionLogout_ == false) {
		// 延迟5s之后重新连接, TODO: 是否需要开启一个线程无限次去进行连接试探
		std::this_thread::sleep_for(std::chrono::seconds(5));
		connectServer();
	}
}

bool ConnectionPGSocket::blockForRSA()
{
	SendRSARequest();
	int serialNumber = 1;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	// 目前的逻辑是每隔1s查询一次状态,每1分钟进行一次重新请求,10分钟无响应退出连接
	while (!RSAFlag_) {
		printf("wait for RSA response\n");
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		serialNumber++;
		if (!TSPConnected_ || shouldSessionLogout_ || serialNumber == 600) {
			closeSocket();
			return false;
		}
		if (serialNumber % 60 == 0) {
			SendRSARequest();
		}
	}
	return true;
}

bool ConnectionPGSocket::blockForPlatformLogin()
{
	PlatformLogin();
	int serialNumber = 1;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	// 目前的逻辑是每隔1s查询一次状态,每1分钟进行一次重新请求,10分钟无响应退出连接
	while (!PlatformLogined_) {
		printf("wait for platformLogin response\n");
		serialNumber++;
		if (!TSPConnected_ || shouldSessionLogout_ || serialNumber == 600) {
			closeSocket();
			return false;
		}
		if (serialNumber % 60 == 0) {
			PlatformLogin();
		}
	}
	return true;
}

bool ConnectionPGSocket::blockForAES()
{
	SendAESKey();
	int serialNumber = 1;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	// 目前的逻辑是每隔1s查询一次状态,每1分钟进行一次重新请求,10分钟无响应退出连接
	while (!AESFlag_) {
		printf("wait for AES response\n");
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		serialNumber++;
		if (!TSPConnected_ || shouldSessionLogout_ || serialNumber == 600) {
			closeSocket();
			return false;
		}
		if (serialNumber % 60 == 0) {
			SendAESKey();
		}
	}
	return true;
}

bool ConnectionPGSocket::blockForCarLogin()
{
	CarLogin();
	int serialNumber = 1;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	// 目前的逻辑是每隔1s查询一次状态,每1分钟进行一次重新请求,10分钟无响应退出连接
	while (!Logined_) {
		printf("wait for AES response\n");
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		serialNumber++;
		if (!TSPConnected_ || shouldSessionLogout_ || serialNumber == 600) {
			closeSocket();
			return false;
		}
		if (serialNumber % 60 == 0) {
			CarLogin();
		}
	}
	return true;
}

// 数据 = 时间
void ConnectionPGSocket::SendRSARequest()
{
	LOG_INFO << "send RSA request";
	time_t now;  //实例化time_t结构
	time(&now);  //time函数读取现在的时间(国际标准时间非北京时间)，然后传值给now
	now = now + 8 * 3600;  //GMT+8*3600，等于北京时间
	struct tm *timenow;  //实例化tm结构指针
	struct tm timenowInstance;
	timenow = gmtime_r(&now,&timenowInstance);

	std::vector<uint8_t> sendBuffer;
	sendBuffer.push_back(timenow->tm_year + 1900 - 2000);
	sendBuffer.push_back(timenow->tm_mon + 1);
	sendBuffer.push_back(timenow->tm_mday);
	sendBuffer.push_back(timenow->tm_hour);
	sendBuffer.push_back(timenow->tm_min);
	sendBuffer.push_back(timenow->tm_sec);

	DataUpload dataUpload;
	dataUpload.setBufferStr(sendBuffer);
	dataUpload.setBufferSize(sendBuffer.size());
	dataUpload.setPackageType(DATATYPE_REQUESTRSA);
	HandleMsgToCloud(dataUpload);
}

void ConnectionPGSocket::PlatformLogin()
{
	LOG_INFO << "send platform login";
	std::shared_ptr<ByteBuffer> bccpkt = std::make_shared<ByteBuffer>();
	//数据采集时间 BYTE[6]
	time_t now;  //实例化time_t结构
	time(&now);  //time函数读取现在的时间(国际标准时间非北京时间)，然后传值给now
	now = now + 8 * 3600;  //GMT+8*3600，等于北京时间
	struct tm *timenow;  //实例化tm结构指针
	struct tm timenowInstance;
	timenow = gmtime_r(&now,&timenowInstance);

	bccpkt->put(timenow->tm_year + 1900 - 2000); //年 0～99
	bccpkt->put(timenow->tm_mon + 1); //月 1～12
	bccpkt->put(timenow->tm_mday); //日 1～31
	bccpkt->put(timenow->tm_hour); //时 0～23
	bccpkt->put(timenow->tm_min); //分 0～59
	bccpkt->put(timenow->tm_sec); //秒 0～59


	char buffer[100] = {0};
	char buffer1[100] = {0};
	sprintf(buffer,"%4d%02d%02d%02d%02d%02d",timenow->tm_year + 1900,timenow->tm_mon + 1,timenow->tm_mday,timenow->tm_hour,timenow->tm_min,timenow->tm_sec);
	sprintf(buffer1,"%s%s",buffer,ConfigInfo::getInstance()->userPassword_.c_str());

	//登入流水号 WORD:TBOX每登入一次，登入流水号自动加1，从1开始循环累加，最大值为65531，循环周期为天。
	bccpkt->putShort(htons(ConfigInfo::getInstance()->platformLoginSerialNumber_));

	//username的加入
	bccpkt->putBytes((uint8_t*)ConfigInfo::getInstance()->username_.c_str(), USERNAME_STR_LENGTH);

	//user password的加入,TODO:这里成都目前给出的长度是700，我不确定这是否正确
	char outUsrPwd1[700] = {0};
	char outUsrPwd2[700] = {0};
	char finalStr[700] = {0};
	int UsrPwdlen = ConfigInfo::getInstance()->userPassword_.length() + 14;
	int RSA_len = DsvEncrypt::EncryptRSA((unsigned char*)buffer1,(unsigned char*)outUsrPwd1,UsrPwdlen);
	//进行Base64加密
	int Base64_len = DsvEncrypt::Base64_encrypt(outUsrPwd1, RSA_len, outUsrPwd2);
	memset(finalStr,0,700);
	memcpy(finalStr,outUsrPwd2,Base64_len);//待测试，outUsrPwd1中如果存在0x00会怎样

	bccpkt->putBytes((uint8_t*)finalStr,700);

	uint8_t sBuffer[bccpkt->size()] = {0};
	bccpkt->getBytes(sBuffer, bccpkt->size());

	std::vector<uint8_t> sendBuffer(sBuffer, sBuffer+bccpkt->size());

	DataUpload dataUpload;
	dataUpload.setBufferStr(sendBuffer);
	dataUpload.setBufferSize(sendBuffer.size());
	dataUpload.setPackageType(DATATYPE_PLATFORMLOGIN);
	HandleMsgToCloud(dataUpload);
}

// 数据 = 时间 + 对AES秘钥进行RSA和AES组合加密
void ConnectionPGSocket::SendAESKey()
{
	LOG_INFO << "send AES key";
	std::shared_ptr<ByteBuffer> bccpkt = std::make_shared<ByteBuffer>();

	time_t now;  //实例化time_t结构
	time(&now);  //time函数读取现在的时间(国际标准时间非北京时间)，然后传值给now
	now = now + 8 * 3600;  //GMT+8*3600，等于北京时间
	struct tm *timenow;  //实例化tm结构指针
	struct tm timenowInstance;
	timenow = gmtime_r(&now,&timenowInstance);

	bccpkt->put(timenow->tm_year + 1900 - 2000); //年 0～99
	bccpkt->put(timenow->tm_mon + 1); //月 1～12
	bccpkt->put(timenow->tm_mday); //日 1～31
	bccpkt->put(timenow->tm_hour); //时 0～23
	bccpkt->put(timenow->tm_min); //分 0～59
	bccpkt->put(timenow->tm_sec); //秒 0～59

	char RSAEncryptStr[256] = {0};
	int RSA_len = DsvEncrypt::EncryptRSA((unsigned char*)PG_AesKey,(unsigned char*)RSAEncryptStr,AES_BLOCK_SIZE);
	char Base64EncryptStr[1024] = {0};
	memset(Base64EncryptStr,0,1024);
	int Base64_len = DsvEncrypt::Base64_encrypt(RSAEncryptStr, RSA_len, Base64EncryptStr);

	bccpkt->putBytes((uint8_t*)Base64EncryptStr,1024);

	uint8_t buffer[bccpkt->size()] = {0};
	bccpkt->getBytes(buffer, bccpkt->size());

	std::vector<uint8_t> sendBuffer(buffer, buffer + bccpkt->size());

	DataUpload dataUpload;
	dataUpload.setBufferStr(sendBuffer);
	dataUpload.setBufferSize(sendBuffer.size());
	dataUpload.setPackageType(DATATYPE_SENDAESKEY);
	HandleMsgToCloud(dataUpload);
}

// 数据单元-车辆登入
void ConnectionPGSocket::CarLogin()
{
	LOG_INFO << "send car login";
	std::shared_ptr<ByteBuffer> bccpkt = std::make_shared<ByteBuffer>();

	//数据采集时间 BYTE[6]
	time_t now;  //实例化time_t结构
	time(&now);  //time函数读取现在的时间(国际标准时间非北京时间)，然后传值给now
	now = now + 8 * 3600;  //GMT+8*3600，等于北京时间
	struct tm *timenow;  //实例化tm结构指针
	struct tm timenowInstance;
	timenow = gmtime_r(&now,&timenowInstance);

	bccpkt->put(timenow->tm_year + 1900 - 2000); //年 0～99
	bccpkt->put(timenow->tm_mon + 1); //月 1～12
	bccpkt->put(timenow->tm_mday); //日 1～31
	bccpkt->put(timenow->tm_hour); //时 0～23
	bccpkt->put(timenow->tm_min); //分 0～59
	bccpkt->put(timenow->tm_sec); //秒 0～59

	//登入流水号 WORD:TBOX每登入一次，登入流水号自动加1，从1开始循环累加，最大值为65531，循环周期为天。
	bccpkt->putShort(htons(ConfigInfo::getInstance()->TSPLoginSerialNumber_));

	//ICCID。
	bccpkt->putBytes((uint8_t*)ConfigInfo::getInstance()->TBOX_ICCID_.c_str(), ICCID_STR_LENGTH);

	//可充电储能子系统数:可充电储能子系统数n，有效值范围：0～250。
	bccpkt->put(1);
	//可充电储能系统编码长度:可充电储能系统编码长度m，有效范围：0～50，“0”表示不上传该编码
	bccpkt->put((uint8_t) 0x18);

	bccpkt->put((uint8_t) 0x43); //生产厂商代码
	bccpkt->put((uint8_t) 0x41); //生产厂商代码
	bccpkt->put((uint8_t) 0x54); //生产厂商代码
	bccpkt->put((uint8_t) 0x50); //产品类型
	bccpkt->put((uint8_t) 0x45); //电池类型代码，参见电池代码表
	bccpkt->put((uint8_t) 0x30); //规格代码
	bccpkt->put((uint8_t) 0x31); //规格代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x30); //追溯信息代码
	bccpkt->put((uint8_t) 0x37); //生产日期，年
	bccpkt->put((uint8_t) 0x37); //生产日期，月
	bccpkt->put((uint8_t) 0x47); //生产日期，日
	bccpkt->put((uint8_t) 0x30); //序列号
	bccpkt->put((uint8_t) 0x30); //序列号
	bccpkt->put((uint8_t) 0x36); //序列号
	bccpkt->put((uint8_t) 0x35); //序列号
	bccpkt->put((uint8_t) 0x35); //序列号
	bccpkt->put((uint8_t) 0x33); //序列号
	bccpkt->put((uint8_t) 0x35); //序列号

	uint8_t dataUnitBuffer[bccpkt->size()] = {0};

	bccpkt->getBytes(dataUnitBuffer, bccpkt->size());

//		printf("车辆登录数据单元长度：%d\n",bccpkt->size());
//		for(int _ii;_ii<bccpkt->size();_ii++){
//			printf("%02x",*dataUnitBuffer);
//			dataUnitBuffer++;
//		}
//		printf("\n");
//		dataUnitBuffer = dataUnitBuffer - bccpkt->size();

	int session_nLen = bccpkt->size();
	int session_nBei = session_nLen / AES_BLOCK_SIZE + 1;
	int session_nTotal = session_nBei * AES_BLOCK_SIZE;//数据对齐

	uint8_t session_enc_in[session_nTotal] = {0};
	uint8_t session_enc_ou[session_nTotal] = {0};

    int session_nNumber;
    if (session_nLen % 16 > 0) {
    	session_nNumber = session_nTotal - session_nLen;
    }
    else {
    	session_nNumber = 16;
    }

	memset(session_enc_in, session_nNumber, session_nTotal);
	memcpy(session_enc_in, dataUnitBuffer, session_nLen);

	DsvEncrypt::EncryptAES_ECB(session_enc_in,session_enc_ou, session_nTotal);

	std::vector<uint8_t> sendBuffer(session_enc_ou, session_enc_ou + session_nTotal);

	DataUpload dataUpload;
	dataUpload.setBufferStr(sendBuffer);
	dataUpload.setBufferSize(session_nTotal);
	dataUpload.setPackageType(DATATYPE_CARLOGIN);
	HandleMsgToCloud(dataUpload);
}

void ConnectionPGSocket::SendMsgToCloud(DataUpload _dataUpload)
{
	LOG_INFO << "send msg from DataApp";

	char dataUnitBuffer[_dataUpload.getRawBufferSize()/2] = {0};
	HexStrToByte(_dataUpload.getRawBufferStr(), dataUnitBuffer);

//	printf("加密之前的数据打印: \n");
//	for(int i=0; i<_dataUpload.getRawBufferSize()/2; i++) {
//		printf("%#02X", dataUnitBuffer[i]);
//	}
//	printf("\n");

//	char *dataUnitBuffer = (char*)_dataUpload.getRawBufferStr().c_str();

	int session_nLen = _dataUpload.getRawBufferSize() / 2;
	int session_nBei = session_nLen / AES_BLOCK_SIZE + 1;
	int session_nTotal = session_nBei * AES_BLOCK_SIZE;//数据对齐

	uint8_t session_enc_in[session_nTotal] = {0};
	uint8_t session_enc_ou[session_nTotal] = {0};

    int session_nNumber;
    if (session_nLen % 16 > 0) {
    	session_nNumber = session_nTotal - session_nLen;
    }
    else {
    	session_nNumber = 16;
    }

	memset(session_enc_in, session_nNumber, session_nTotal);
	memcpy(session_enc_in, dataUnitBuffer, session_nLen);

	DsvEncrypt::EncryptAES_ECB(session_enc_in, session_enc_ou, session_nTotal);

	std::vector<uint8_t> sendBuffer(session_enc_ou, session_enc_ou + session_nTotal);

//	printf("加密之后的数据打印: \n");
//	for(int j=0; j<session_nTotal; j++) {
//		printf("%#02X", session_enc_ou[j]);
//	}
//	printf("\n");
//
//	printf("测试解密功能: \n");
//	uint8_t testout[session_nTotal] = {0};
//	DsvEncrypt::DecryptAES_ECB(session_enc_ou,testout, session_nTotal);
//	for(int k=0; k<session_nTotal; k++) {
//		printf("%#02X", testout[k]);
//	}
//	printf("\n");

	DataUpload dataUpload;
	dataUpload.setBufferStr(sendBuffer);
	dataUpload.setBufferSize(session_nTotal);
	dataUpload.setPackageType(_dataUpload.getPackageType());
	HandleMsgToCloud(dataUpload);
}

// 统一发送接口
void ConnectionPGSocket::HandleMsgToCloud(DataUpload &_dataUpload)
{
	LOG_INFO << "handle msg";
	int dataType = _dataUpload.getPackageType();
	SendParams sendParams;
	switch (dataType) {
	case DATATYPE_DATAUPLOAD:
		{
			sendParams.checkCarLogin_ = true;
			sendParams.checkPlatformLogin_ = true;
			if (_dataUpload.getRealTime()) {
				sendParams.commandId_ = 0x02;
			}
			else {
				sendParams.commandId_ = 0x03;
			}
			sendParams.encryptionMode_ = 0x03;
		}
		break;
	case DATATYPE_HEARTBEAT:
		{
			sendParams.checkCarLogin_ = true;
			sendParams.checkPlatformLogin_ = true;
			sendParams.commandId_ = 0x07;
			sendParams.encryptionMode_ = 0x03; // TODO:待确认心跳是否需要加密
		}
		break;
	case DATATYPE_PANGOO_WARNING:
		{
			sendParams.checkCarLogin_ = true;
			sendParams.checkPlatformLogin_ = true;
			sendParams.commandId_ = 0xC7;
			sendParams.encryptionMode_ = 0x03;
		}
		break;
	case DATATYPE_PANGOO_RESPONSE:
		{
			sendParams.checkCarLogin_ = true;
			sendParams.checkPlatformLogin_ = true;
			sendParams.commandId_ = 0xC3;
			sendParams.encryptionMode_ = 0x03;
		}
		break;
	case DATATYPE_CARLOGIN:
		{
			sendParams.checkCarLogin_ = false;
			sendParams.checkPlatformLogin_ = true;
			sendParams.commandId_ = 0x01;
			sendParams.encryptionMode_ = 0x03;
		}
		break;
	case DATATYPE_PLATFORMLOGIN:
		{
			sendParams.checkCarLogin_ = false;
			sendParams.checkPlatformLogin_ = false;
			sendParams.commandId_ = 0x05;
			sendParams.encryptionMode_ = 0x02;
		}
		break;
	case DATATYPE_SENDAESKEY:
		{
			sendParams.checkCarLogin_ = false;
			sendParams.checkPlatformLogin_ = true;
			sendParams.commandId_ = 0xC6;
			sendParams.encryptionMode_ = 0x02;
		}
		break;
	case DATATYPE_REQUESTRSA:
		{
			sendParams.checkCarLogin_ = false;
			sendParams.checkPlatformLogin_ = false;
			sendParams.commandId_ = 0xC5;
			sendParams.encryptionMode_ = 0x01;
		}
		break;
	default:
		break;
	}
	SendPackage(_dataUpload, sendParams);
}

// 所有的上传数据都走这个通道,函数要求:可重入
void ConnectionPGSocket::SendPackage(DataUpload &_dataUpload, SendParams &_sendParams)
{
	LOG_INFO << "send to cloud";
	if (shouldSessionLogout_ == false) {
		if (TSPConnected_ == false) {
			return;
		}
		if (_sendParams.checkCarLogin_) {
			if (Logined_ == false)
				return;
		}
		if (_sendParams.checkPlatformLogin_) {
			if (PlatformLogined_ == false)
				return;
		}
		//蓥石企标车辆登入
		std::shared_ptr<ByteBuffer> bccpkt = std::make_shared<ByteBuffer>();
//		std::string version = "TT00040000";
//		bccpkt->putBytes((uint8_t*)version.c_str(),10);
		bccpkt->putBytes((uint8_t*)ConfigInfo::getInstance()->TBOX_VERSION_.c_str(),VERSION_STR_LENGTH);
		bccpkt->put(_sendParams.commandId_); // 命令标识
		bccpkt->put((uint8_t) 0xFE);  //应答标志:命令的主动发起方应答标志为 0xFE, 表示此包为命令包; 当应答标志不是 0xFE 时, 被动接收方应不应答
		bccpkt->putBytes((uint8_t*)ConfigInfo::getInstance()->TBOX_VIN_.c_str(),VIN_STR_LENGTH); //VIN:VIN, 应符合 GB16735 的规定 AAAAAAAAAA0009990

		bccpkt->put(_sendParams.encryptionMode_); // 加密方式

		bccpkt->putBytes((uint8_t*)ConfigInfo::getInstance()->tokenStr_.c_str(),TOKEN_STR_LENGTH);

		bccpkt->putShort(_dataUpload.getBufferSize()); // 数据长度

		bccpkt->putBytes((uint8_t*)_dataUpload.getBufferStr().data(), _dataUpload.getBufferSize()); // 传输数据

		uint8_t BCCBuffer[bccpkt->size()];
		bccpkt->getBytes(BCCBuffer, bccpkt->size());

		//校验码:采用BCC（异或校验）法，校验范围从TBOX版本（即BYTE1）开始，同后一字节异或，直到校验码前一字节为止，校验码占用一个字节，当数据单元存在加密时，应先加密后校验，先校验后解密。
		uint8_t checksum = 0;
		checksum = DsvEncrypt::BCC_CheckSum(BCCBuffer, bccpkt->size());

		std::shared_ptr<ByteBuffer> wholepkt = std::make_shared<ByteBuffer>();
		wholepkt->put((uint8_t) 0x23);  //起始符:固定为ASCII字符‘#’,用“0x23”表示
		wholepkt->put(bccpkt.get());
		wholepkt->put(checksum);

		// FIXME: 看有没有问题----有问题
//		string wholeBufferString = std::string(wholepkt->getBuffer().begin(), wholepkt->getBuffer().end());
//		LOG_INFO << "[wholebuffer]-->" << wholeBufferString;

		uint8_t sendBuffer[wholepkt->size()];

		wholepkt->getBytes(sendBuffer, wholepkt->size());

		ssize_t writeSize = write(socketFd_, sendBuffer, wholepkt->size());

		int value = -1;
		for (int i = 0; i < 100*12; i++) {
//			usleep(1000*50);
			struct timeval temp;
			temp.tv_sec = 0;
			temp.tv_usec = 1000*50;
			select(0, NULL, NULL, NULL, &temp);
			value = -1;
			ioctl(socketFd_, SIOCOUTQ, &value);
			if (value <= 0) {
				LOG_INFO << "Send Success";
				break;
			}
		}
		if(value > 0) {
			LOG_INFO << "Send Fail";
			closeSocket(); // TODO: 这里的逻辑看看是否需要取消
		}
	}
}

void ConnectionPGSocket::RecvMsgFromCloudThread()
{
	prctl(PR_SET_NAME,"RecvCloud");
	LOG_INFO << "recv tspmsg thread";
	if (recvMsgFromCloudThreadRunning_) {
		printf("repeat open thread\n");
		return;
	}
	recvMsgFromCloudThreadRunning_ = true;
	if (shouldSessionLogout_ != false || socketFd_ == -1) {
		return;
	}

	while (true) {
		fd_set rset;
		FD_ZERO(&rset);
		FD_SET(socketFd_, &rset);
		struct timeval temp;
		temp.tv_sec = 30;
		temp.tv_usec = 0;
		int nReady = select(socketFd_ + 1, &rset, NULL, NULL, &temp);  // rset和temp必须写到循环中,不然第二次调用会被清空

		//返回值为-1表示描述符清零，为0表示检测超时
		if (nReady == -1) {
			LOG_ERROR << "描述符清零";
			closeSocket();
			recvMsgFromCloudThreadRunning_ = false;
			break;
		}
		else if (nReady == 0) {
			// TODO: 超时多次需不需要响应的处理逻辑这里目前还不清楚
			LOG_ERROR << "检测超时";
			if (shouldSessionLogout_ != false) {
				closeSocket();
				recvMsgFromCloudThreadRunning_ = false;
				break;
			}
			continue;
		}
		if (FD_ISSET(socketFd_, &rset)) {
			LOG_ERROR << "检测到了可读事件";
			char buffer[1024] = {0}; // #define RECV_BUFFER_SIZE 1024
			if (shouldSessionLogout_ != false) { // 此时可能登出了
				closeSocket();
				recvMsgFromCloudThreadRunning_ = false;
				break;
			}
			int readBytes = read(socketFd_, buffer, sizeof(buffer));
			if (readBytes == 0) {
				LOG_ERROR << "连接关闭";
				closeSocket();
				recvMsgFromCloudThreadRunning_ = false;
				break;
			}
			else if (readBytes == -1) {
				LOG_ERROR << "读取错误";
				closeSocket();
				recvMsgFromCloudThreadRunning_ = false;
				break;
			}
			std::string recvStr(buffer, buffer+readBytes);
			{
				std::unique_lock<std::mutex> lck(tspMtx_);
				recvTspMsgQueue_.emplace_back(recvStr);
				tspCv_.notify_all();
			}
		}
	}
}

void ConnectionPGSocket::tspHandleRecvMsgThread()
{
	LOG_INFO << "handle thread";
	while (!shouldSessionLogout_) {
		std::unique_lock<std::mutex> lck(tspMtx_);
		while (!recvTspMsgQueue_.empty()) {
			LOG_INFO << "recv msg from cloud";
			std::string tspMsgStr = recvTspMsgQueue_.front();
			recvTspMsgQueue_.erase(recvTspMsgQueue_.begin());
			tspHandleRecvMsg(tspMsgStr);
		}
		tspCv_.wait(lck);
	}
}

void ConnectionPGSocket::tspHandleRecvMsg(std::string _tspMsgStr)
{
	std::shared_ptr<ByteBuffer> wholeBuffer = std::make_shared<ByteBuffer>();
	wholeBuffer->putBytes((uint8_t*) _tspMsgStr.c_str(), _tspMsgStr.size());
	if (wholeBuffer->size() <= 0) {
		return;
	}
	int index = wholeBuffer->find(ntohs((short) 0x2354)); // 0x23表示起始符，0x04表示版本号
	if (index >= 0 && wholeBuffer->size() >= (index + 70)) { // 根据数据协议至少包含70个字节大小
		uint8_t cmdFlag = wholeBuffer->get(index + 11); // 获取命令标识
		uint8_t ansFlag = wholeBuffer->get(index + 12); // 获取应答标志
		uint8_t encryptFlag = wholeBuffer->get(index + 30); // 获取加密方式
		short dataLen = ntohs(wholeBuffer->getShort(index + 67)); // 获取数据长度
		printf("cmdFlag: %#02X | ansFlag: %#02X | encryptFlag: %#02X | dataLen: %d\n"
				, cmdFlag, ansFlag, encryptFlag, dataLen);
		if (dataLen < 0 || wholeBuffer->size() > (index + 70 + dataLen)) {
			return;
		}
		uint8_t checkBit = wholeBuffer->get(index + 69 + dataLen);
		uint8_t BCCBuffer[69 + dataLen - 1] = {0};
		wholeBuffer->getBytes(BCCBuffer, 69 + dataLen - 1, index + 1);
		uint8_t checkSum = DsvEncrypt::BCC_CheckSum(BCCBuffer, 69 + dataLen - 1);
		if (checkBit == checkSum) {
			LOG_INFO << "校验和通过";
			uint8_t dataUnitBuffer[dataLen] = {0};
			if (encryptFlag == 0x01) {
				wholeBuffer->getBytes(dataUnitBuffer, dataLen, index + 69);
			}
			else if (encryptFlag == 0x03) {
				uint8_t dataBeforeEncrypt[dataLen] = {0};
				wholeBuffer->getBytes(dataBeforeEncrypt, dataLen, index + 69);
				DsvEncrypt::DecryptAES_ECB((unsigned char*)dataBeforeEncrypt,(unsigned char*)dataUnitBuffer,dataLen);
			}
			// TODO: 后台看是否需要改变这里,平台登录的响应与其他数据会有不同这里将其特别列出来
			if (cmdFlag == 0x05) {
				if (ansFlag == 0x01) {
					LOG_INFO << "收到了TOKEN字符串";
					PlatformLogined_ = true;
					uint8_t tokenBuf[36] = {0};
					wholeBuffer->getBytes(tokenBuf, 36, index + 31);
					ConfigInfo::getInstance()->tokenStr_ = std::string((char *)tokenBuf,36);
				}
			}
			else {
				tspHandleCmd(cmdFlag,ansFlag,(char*)dataUnitBuffer,dataLen);
			}
		}
	}
}

void ConnectionPGSocket::tspHandleCmd(uint8_t _cmdFlag, uint8_t _ansFlag, char* _data, short _datalen)
{
	LOG_INFO << "处理tsp传下来的各个cmd";
	switch (_cmdFlag) {
	case 0x01: // 车辆登录
		tspHandleCarLogin(_ansFlag, _data, _datalen);
		break;
	case 0x02: // 实时数据上报
		tspHandleRealtimeMsg(_ansFlag, _data, _datalen);
		break;
	case 0x03: // 补发数据上报
		tspHandleReissueMsg(_ansFlag, _data, _datalen);
		break;
	case 0xC3: // 远程控制
		tspHandleRemoteControl(_ansFlag, _data, _datalen);
		break;
	case 0xC5: // 获取RSA公钥
		tspHandleRSA(_ansFlag, _data, _datalen);
		break;
	case 0x05: // 平台登录
		tspHandlePlatform(_ansFlag, _data, _datalen);
		break;
	case 0xC6: // AES秘钥上传
		tspHandleAES(_ansFlag, _data, _datalen);
		break;
	default:
		break;
	}
}

// 车辆登录结果处理
void ConnectionPGSocket::tspHandleCarLogin(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0x01) {
		LOG_INFO << "车辆登录成功";
		Logined_ = true;
		if (cma_ != NULL) {
			cma_->NotifyTSPConnected(); // 登录流程的最后一个步骤
		}
		ConfigInfo::getInstance()->TSPLoginSerialNumber_++;
		ConfigInfo::getInstance()->writeConfigInfo();
	}
}

// 实时数据上传结果处理, TODO: 目前的逻辑是对已经上传但是没有处理成功的数据不进行补发存储
void ConnectionPGSocket::tspHandleRealtimeMsg(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0x01) {
		LOG_INFO << "实时数据上传成功";
	}
}

// 补发数据上传结果处理, TODO: 目前的逻辑是对已经上传但是没有处理成功的数据不进行补发存储
void ConnectionPGSocket::tspHandleReissueMsg(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0x01) {
		LOG_INFO << "补发数据上传成功";
	}
}

// 远程控制结果处理
void ConnectionPGSocket::tspHandleRemoteControl(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0xFE) {
		LOG_INFO << "接收到远程控制信息";
		std::string notifyStr(_data, _datalen);
		cma_->NotifyPGtoTBOX(notifyStr);
	}
}

// 获取RSA公钥结果处理
void ConnectionPGSocket::tspHandleRSA(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0x01) {
		LOG_INFO << "接收到RSA公钥";
		RSAFlag_ = true;
		ResponseRSAPublicKey((int)_datalen, _data);
	}
}

// 平台登录结果处理
void ConnectionPGSocket::tspHandlePlatform(uint8_t _ansFlag, char* _data, short _datalen)
{
}

// AES秘钥上传结果处理
void ConnectionPGSocket::tspHandleAES(uint8_t _ansFlag, char* _data, short _datalen)
{
	if (_ansFlag == 0x01) {
		LOG_INFO << "AES秘钥上传成功";
		AESFlag_ = true;
	}
}

void ConnectionPGSocket::ResponseRSAPublicKey(int dataLength,char *dataUnitBuffer)
{
	dataUnitBuffer = dataUnitBuffer + 6;
//	std::string PubRSA = Utility::ByteToHexStr(dataUnitBuffer, dataLength-6);
	std::string PubRSA;
//	printf("收到的RSA公钥的长度为%d\n",dataLength);
	PubRSA = std::string(dataUnitBuffer,dataLength-6);
	//生成一个完整的pem格式的公钥
	std::stringstream fs;
	int flag = 0;
	fs<<"-----BEGIN PUBLIC KEY-----";
	fs<<endl;
	for(int i=0;i<PubRSA.length();i++){
		if(flag<64){
			fs<<PubRSA[i];
			flag++;
		}else{
			fs<<endl;
			fs<<PubRSA[i];
			flag = 1;
		}
	}
	fs<<endl;
	fs<<"-----END PUBLIC KEY-----";
	fs<<endl;
	string PUB_str = fs.str();
	LOG_INFO << PUB_str;
//	cout<<PUB_str<<endl;
	ConfigInfo::getInstance()->RSAKeyStr_ = PUB_str;
}

void ConnectionPGSocket::SetConnectManagerApp(ConnectionManagerApp* _cma)
{
	cma_ = _cma;
}



