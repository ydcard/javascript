#概述
DSVTSPConnectSVC应用功能包括：连接NEVS TSP或者EASTONE TSP，发送车辆登入和车辆登出报文到TSP，打包转发车辆数据报文到TSP，打包转发其他APP的数据报文到TSP，接收TSP下发指令转发给其他APP。

#运行条件
NEVS：TBOX能够上公网，能够通过域名地址访问NEVS TSP，NEVS TSP工作正常，车辆VIN码和SIM卡ICCID在NEVS TSP已经注册，而且相应的证书预置在TBOX里面。
EASTONE：TBOX能够上公网，能够通过域名地址访问EASTONE TSP，EASTONE TSP工作正常，车辆VIN码和SIM卡ICCID在EASTONE TSP已经注册。

#更改记录
20171115：
1. 实现NEVS Echo Socket和MQTT同时运行。
2. 实现NEVS Echo Socket自动连接TSP模拟器（不需要手动修改配置文件的IP地址）。
20171226：
1. 适配SDK2.1接口变动。
2. 集成system svc投票。
3. EASTONE完善获取VIN码逻辑处理。
4. 解决NEVS车辆登出流水号的bug。
5. NEVS TSP地址动态从配置文件获取解析。
6. EASTONE升级包下载目录从/app移到/media/card目录。
