#ifndef _I_CALLBACKBINDERIPC_H_
#define	_I_CALLBACKBINDERIPC_H_

#include <binder/IInterface.h>
using namespace android;

#include <string>
using namespace std;

class ICallBackBinderIPC : public IInterface
{
public:
	DECLARE_META_INTERFACE(CallBackBinderIPC);
	virtual void NotifyCallBack(int method_id,string notifyJsonStr) = 0;
	enum
	{
		NOTIFY_CALLBACK = IBinder::FIRST_CALL_TRANSACTION,
	};
	unsigned long long callbackNodeId;
};

class BnCallBackBinderIPC:public BnInterface<ICallBackBinderIPC>
{
public:
	virtual status_t onTransact(uint32_t code,const Parcel& data,Parcel* reply,uint32_t flags = 0);
};

#endif
