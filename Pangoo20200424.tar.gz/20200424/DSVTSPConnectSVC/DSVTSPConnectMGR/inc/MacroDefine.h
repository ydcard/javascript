/*
 * MacroDefine.h
 *
 *  Created on: 2017年6月27日
 *      Author: wsong
 */

#ifndef MACRODEFINE_H_
#define MACRODEFINE_H_

#include "node_type.h"
#include "log.h"

#define TELEMATICS_SERVICES_INDEX NODE_APP_TSP_CONNECT

#define TELEMATICS_SERVICES_FUNCTION_PANGOO_RESPONSE_DATA                         "PangooResponse"   //Pangoo
#define TELEMATICS_SERVICES_FUNCTION_PANGOO_WARN_DATA							  "PangooWarnData"	 //Pangoo--20181128
#define TELEMATICS_SERVICES_FUNCTION_DATA_UPLOAD_STRING                           "DataUpload"
#define TELEMATICS_SERVICES_FUNCTION_HEARTBEAT									  "HeartBeat"

#define TELEMATICS_SERVICES_FUNCTION_REPORT_VEHICLE_STATUS_STRING                 "ReportVehicleStatus"
#define TELEMATICS_SERVICES_FUNCTION_REMOTE_COMMAND_UPDATE_STRING                 "RemoteCommandUpdate"
#define TELEMATICS_SERVICES_FUNCTION_REMOTE_DIAGNOSTIC_RESPONSE_STRING            "RemoteDiagnosticResponse"
#define TELEMATICS_SERVICES_FUNCTION_TIME_ADJUSTMENT_COMMAND_UPDATE_STRING        "TimeAdjustmentCommandUpdate"
#define TELEMATICS_SERVICES_FUNCTION_REPORT_SW_UPDATE_STATUS_STRING               "ReportSWUpdateStatus"
#define TELEMATICS_SERVICES_FUNCTION_REPORT_VEHICLE_VIN_STRING                    "ReportVehicleVIN"
#define TELEMATICS_SERVICES_FUNCTION_REPORT_DATA_UPLOAD_APP_SLEEP_STRING          "ReportDataUploadAppSleep"
#define TELEMATICS_SERVICES_FUNCTION_BACKGROUND_DATA_UPLOAD_STRING                "BackgroundDataUpload"
#define TELEMATICS_SERVICES_FUNCTION_REPORT_ANTI_THEFT_STRING                     "ReportAntiTheft"
#define TELEMATICS_SERVICES_FUNCTION_OTA_COMMAND_RESPONSE_STRING                  "OTACommandResponse"
#define TELEMATICS_SERVICES_FUNCTION_SWDL_DOWNLOAD_PACKAGE_STRING                 "SWDL_Download_Package"
#define TELEMATICS_SERVICES_FUNCTION_GET_USER_CONFIG_INFO_STRING                  "GetUserConfigInfo"
#define TELEMATICS_SERVICES_FUNCTION_SET_USER_CONFIG_INFO_STRING                  "SetUserConfigInfo"
#define TELEMATICS_SERVICES_FUNCTION_RECHARGEABLE_ENERGY_STORAGE_SUBSYSTEM_STRING "RechargeableEnergyStorageSubsystem"
#define TELEMATICS_SERVICES_FUNCTION_OPERATING_HEARTBEAT_CONTROL_DATA_STRING      "OperatingHeartbeatControlData"
#define TELEMATICS_SERVICES_FUNCTION_REMOTE_FORBID_IGNITE_LOG_STRING              "Remote_Forbid_Ignite_Log"


// ASyncCall异步函数调用回调结果JSON字符串ResponseErrorCode含义：
// 0，成功
// 1，gdbus错误
// 2，网络错误
// 3，服务器未响应
// 4，服务器认为数据包有问题
// 5，TU还没有登录
// 6，数据单元为空
// 7，程序已经睡眠
// 8，VIN码未激活
// 9，蓥石和国标Socket发送消息锁失败
// 10，Manger发送消息锁失败
// 11，binder错误
// 12，Record ID重复错误
#define TELEMATICS_RESULT_SUCCESS                 0
#define TELEMATICS_RESULT_GDBUS_ERROR             1
#define TELEMATICS_RESULT_NETWORK_ERROR           2
#define TELEMATICS_RESULT_SERVER_ERROR            3
#define TELEMATICS_RESULT_PACKET_ERROR            4
#define TELEMATICS_RESULT_TU_NOT_LOGIN_ERROR      5
#define TELEMATICS_RESULT_PACKET_DATA_EMPTY_ERROR 6
#define TELEMATICS_RESULT_SLEEP_ERROR             7
#define TELEMATICS_RESULT_VIN_NOT_ACTIVATED_ERROR 8
#define TELEMATICS_RESULT_SOCKET_SEND_LOCK_ERROR  9
#define TELEMATICS_RESULT_MANGER_CALL_LOCK_ERROR  10
#define TELEMATICS_RESULT_BINDER_ERROR            11
#define TELEMATICS_RESULT_RECORD_ID_REPEAT_ERROR  12

#define TELEMATICS_SERVICES_FUNCTION_COMMON              0
#define TELEMATICS_SERVICES_FUNCTION_CHECK_TSP_CONNECTED 1
#define TELEMATICS_SERVICES_FUNCTION_ECHO                2

#define TELEMATICS_SERVICES_SIGNAL_COMMON               "SignalCommon"
#define TELEMATICS_SERVICES_SIGNAL_ECHO                 "SignalEcho"

#define DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_ECHO             0
#define DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_NOTIFY           1
#define DSV_TSP_CONNECT_MGR_FUNCTION_COMMON_ASYNCCALL_RESULT 2

//the following are UBUNTU/LINUX ONLY terminal color codes.
#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

#endif /* MACRODEFINE_H_ */
