#ifndef _I_INTERFACEBINDERIPC_H_
#define _I_INTERFACEBINDERIPC_H_

#include <binder/IInterface.h>
using namespace android;

#include "ICallBackBinderIPC.h"

#include <string>
using namespace std;

//定义要共享的接口
class IInterfaceBinderIPC : public IInterface
{
public:
	DECLARE_META_INTERFACE(InterfaceBinderIPC);
	virtual void ASyncCall(unsigned long long node_id,int method_id,string contentJsonStr) = 0;
	//函数接口用于注册callback函数接口
	virtual void setCallback(unsigned long long callbackNodeId,const sp<ICallBackBinderIPC> &callback) = 0;
	enum
	{
		ASYNCCALL_TRANSACTION = IBinder::FIRST_CALL_TRANSACTION,
    	SET_CALLBACK_TRANSACTION
	};
};

//接口服务端，主要实现onTransact函数
class BnInterfaceBinderIPC : public BnInterface<IInterfaceBinderIPC>
{
public:
	virtual status_t onTransact(uint32_t code,const Parcel& data,Parcel* reply,uint32_t flags = 0);
};

#endif
