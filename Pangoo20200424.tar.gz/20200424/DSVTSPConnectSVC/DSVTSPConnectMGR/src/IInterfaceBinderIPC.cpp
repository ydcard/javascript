#include <binder/Parcel.h>
using namespace android;

#include "IInterfaceBinderIPC.h"

//接口代理类，只是实现共享接口的调用逻辑，即：调用transact函数，进而调用接口服务端的onTransact函数
class BpInterfaceBinderIPC : public BpInterface<IInterfaceBinderIPC>
{
public:
	BpInterfaceBinderIPC(const sp<IBinder>& impl): BpInterface<IInterfaceBinderIPC>(impl)
	{
	}

	virtual void ASyncCall(unsigned long long node_id,int method_id,string contentJsonStr)
	{
		Parcel data, reply;
		data.writeInterfaceToken(IInterfaceBinderIPC::getInterfaceDescriptor());
		data.writeInt64(node_id);
		data.writeInt32(method_id);
		data.writeCString(contentJsonStr.c_str());
		remote()->transact(ASYNCCALL_TRANSACTION, data, &reply);
	}

	virtual void setCallback(unsigned long long callbackNodeId,const sp<ICallBackBinderIPC>& callback)
	{
		Parcel data, reply;
		data.writeInterfaceToken(IInterfaceBinderIPC::getInterfaceDescriptor());
		data.writeInt64(callbackNodeId);
		data.writeStrongBinder(IInterface::asBinder(callback));
		remote()->transact(SET_CALLBACK_TRANSACTION, data, &reply);
   }
};

IMPLEMENT_META_INTERFACE(InterfaceBinderIPC, "com.desay.IInterfaceBinderIPC");

status_t BnInterfaceBinderIPC::onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)
{
	switch(code)
	{
		case ASYNCCALL_TRANSACTION:
			{
				CHECK_INTERFACE(IInterfaceBinderIPC, data, reply);
				unsigned long long node_id = data.readInt64();
				int method_id = data.readInt32();
				const char* contentJsonStr = data.readCString();
				ASyncCall(node_id,method_id,contentJsonStr);
				reply->writeNoException();
				return NO_ERROR;
			}
			break;
		case SET_CALLBACK_TRANSACTION:
			{
				CHECK_INTERFACE(IInterfaceBinderIPC, data, reply);
				unsigned long long callbackNodeId = data.readInt64();
				sp<ICallBackBinderIPC> callback = interface_cast<ICallBackBinderIPC>(data.readStrongBinder());
				setCallback(callbackNodeId,callback);
				reply->writeNoException();
				return NO_ERROR;
			}
			break;
		default:
			return BBinder::onTransact(code, data, reply, flags);
	}
}
