#include <binder/Parcel.h>
#include "ICallBackBinderIPC.h"

class BpCallBackBinderIPC: public BpInterface<ICallBackBinderIPC>
{
public:
	BpCallBackBinderIPC(const sp<IBinder>& impl):BpInterface<ICallBackBinderIPC>(impl)
	{
	}

	virtual void NotifyCallBack(int method_id,string notifyJsonStr)
	{
		Parcel data, reply;
		data.writeInterfaceToken(ICallBackBinderIPC::getInterfaceDescriptor());
		data.writeInt32(method_id);
		data.writeCString(notifyJsonStr.c_str());
		remote()->transact(NOTIFY_CALLBACK, data, &reply);
	}

};

IMPLEMENT_META_INTERFACE(CallBackBinderIPC, "com.desay.ICallBackBinderIPC");

status_t BnCallBackBinderIPC::onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)
{
	switch (code)
	{
		case NOTIFY_CALLBACK:
		{
			CHECK_INTERFACE(ICallBackBinderIPC, data, reply);
			int method_id = data.readInt32();
			const char* notifyJsonStr = data.readCString();
			NotifyCallBack(method_id,notifyJsonStr);
			return NO_ERROR;
		}
			break;
		default:
			return BBinder::onTransact(code, data, reply, flags);
	}
}
