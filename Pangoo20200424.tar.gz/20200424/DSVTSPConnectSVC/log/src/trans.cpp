/*
 * trans.cpp
 *
 *  Created on: Sep 27, 2019
 *      Author: yindi
 * Description: 
 */

#include "trans.h"
#include "logging.h"
#include <iomanip>

trans::trans(std::string _filename, int _line, int _priority)
	: i_line(_line),
	i_priority(_priority)
{
	size_t pos = _filename.find_last_of("/");
	if ( pos == std::string::npos ) {
		s_filename = _filename;
	} else {
		s_filename = _filename.substr(pos+1);
	}
}
trans::~trans() {
	std::string _logMsg = combine();
	Logger::GetInstance()->insertBuffer(_logMsg);
}

std::string trans::getTimeStamp() {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	time_t timep;
	time(&timep);
	timep = timep + 3600*8; // 由于Tbox上的时间始终少8小时
//	int64_t seconds = tv.tv_sec;
	struct tm pTM;
//	struct tm *pTM = gmtime( &timep );
//	gmtime_r(&timep, &pTM); // gmtime返回格林威治时间,localtime返回本地时间
	localtime_r(&timep, &pTM);
	char outstr[26];
	// 20190924 08:08:08.123456
//	sprintf(outstr,"%4d-%02d-%02d %02d:%02d:%02d.%06ld",
//			pTM->tm_year+1900,pTM->tm_mon+1, pTM->tm_mday,
//			pTM->tm_hour, pTM->tm_min, pTM->tm_sec,tv.tv_usec);
	sprintf(outstr,"%4d-%02d-%02d %02d:%02d:%02d.%06ld",
			pTM.tm_year+1900,pTM.tm_mon+1, pTM.tm_mday,
			pTM.tm_hour, pTM.tm_min, pTM.tm_sec,tv.tv_usec);
	std::string time_str = outstr;
	return time_str;

}
// 2019-09-25 16:21:49.994447 | INFO | test5.cpp:157 | hello yindi2019 | <desay>
std::string trans::combine() {
	std::stringstream os;
	std::string _timeStamp = getTimeStamp();
	std::string _username = Logger::GetInstance()->getUserName();
	std::string _priority = Priority::getPriorityName(i_priority);
	os << _timeStamp << " | ";
	os << std::left << std::setw(6) << _priority << "| ";
	os << s_filename << ":" << i_line << " | ";
	os << _msgstream.str() << " |";
	os << "<" << _username << ">";
	os << std::endl;
	return os.str();
}


