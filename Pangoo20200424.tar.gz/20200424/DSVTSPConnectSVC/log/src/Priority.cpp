/*
 * Priority.cpp
 *
 *  Created on: Sep 20, 2019
 *      Author: yindi
 * Description: 
 */

#include "Priority.h"

const std::string *names() {
	static const std::string priority_names[9] = {
		"EMERG",
		"ALERT",
		"CRIT",
		"ERROR",
		"WARN",
		"NOTICE",
		"INFO",
		"DEBUG",
		"NOTSET"
	};
	return priority_names;
}

const int Priority::MESSAGE_SIZE = 8;

const std::string& Priority::getPriorityName(int priority) noexcept {
	return names()[((priority < 0) || (priority > 8)) ? 8 : priority];
}

int Priority::getPriorityValue(const std::string& priorityName) {
	int value = -1;

	for (unsigned int i = 0; i < 9; i++) {
		if (priorityName == names()[i]) {
			value = i;
			break;
		}
	}
	return value;
}

int Priority::max() {
	return MESSAGE_SIZE;
}

