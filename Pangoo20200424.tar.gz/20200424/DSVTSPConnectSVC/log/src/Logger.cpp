/*
 * Logger.cpp
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */
#include "rapidjson/rapidjson.h"
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "Logger.h"
#include <fcntl.h>
#include <unistd.h>
#include <assert.h>

Logger* Logger::m_instance = nullptr;

Logger::Logger()
	:s_fileName(DEFAULT_FILENAME),
	s_format(DEFAULT_FORMAT),
	s_logPath(DEFAULT_LOGPATH),
	i_priority(DEFAULT_PRIORITY),
	i_fileCount(DEFAULT_FILECOUNT),
	i_fileSize(DEFAULT_FILESIZE),
	s_userName(DEFAULT_USERNAME)
{
	m_logstream.reset(new LogStream(s_fileName, s_logPath, i_fileCount, i_fileSize));
}

bool Logger::setFileName(std::string _fileName) {
	if ( _fileName == "") {
		return false;
	}
	if ( _fileName.length() > 20 ) {
		s_fileName = _fileName.substr(_fileName.length()-20, 20);
	} else {
		s_fileName = _fileName;
	}
	std::cout << "\033[32m Logger->setFileNameSuccess\033[0m" << std::endl;
	m_logstream->setFileName(s_fileName);
	return true;
}

// TODO:暂时使用默认格式,后续有需求再添加
bool Logger::setFormat(std::string _format) {
	return true;
}

// mode: 需要测试的操作模式，可能值是一个或多个R_OK(可读?), W_OK(可写?), X_OK(可执行?) 或 F_OK(文件存在?)
bool Logger::setLogPath(std::string _logPath){
	if ( access(_logPath.c_str(), F_OK) != 0 ) {
		std::cout << "\033[31m Logger->setPathFail\033[0m" << std::endl;
		return false;
	}
	if ( _logPath.back() != '/' ) {
		_logPath = _logPath + "/";
	}
	std::cout << "\033[32m Logger->setPathSuccess\033[0m" << std::endl;
	s_logPath = _logPath;
	m_logstream->setLogPath(s_logPath);
	return true;
}

bool Logger::setPriority(int _priority){
	if ( _priority > Priority::max() || _priority < 0 ) {
		std::cout << "\033[31m Logger->setPriorityFail\033[0m" << std::endl;
		return false;
	}
	std::cout << "\033[32m Logger->setPrioritySuccess\033[0m" << std::endl;
	i_priority = _priority;
	return true;
}

bool Logger::setFileCount(int _fileCount){
	if ( _fileCount >= 100 || _fileCount < 0 ) {
		std::cout << "\033[31m Logger->setPathFail\033[0m" << std::endl;
		return false;
	}
	std::cout << "\033[32m Logger->setFileCountSuccess\033[0m" << std::endl;
	i_fileCount = _fileCount;
	m_logstream->setFileCount(i_fileCount);
	return true;
}

bool Logger::setFileSize(int _fileSize){
	if ( _fileSize > MAX_LOGFILE_SIZE || _fileSize < MIN_LOGFILE_SIZE ) {
		std::cout << "\033[31m Logger->setFileSizeFail\033[0m" << std::endl;
		return false;
	}
	std::cout << "\033[32m Logger->setFileSizeSuccess\033[0m" << std::endl;
	i_fileSize = _fileSize;
	m_logstream->setFileSize(i_fileSize);
	return true;
}

bool Logger::setUserName(std::string _userName){
	if ( _userName == "" ) {
		std::cout << "\033[31m Logger->setUserNameFail\033[0m" << std::endl;
		return false;
	}
	if ( _userName.length() > 10 ) {
		s_userName = _userName.substr(_userName.length()-10, 10);
	} else {
		s_userName = _userName;
	}
	std::cout << "\033[32m Logger->setUserNameSuccess\033[0m" << std::endl;
	return true;
}

/*
 * {
 *   "fileName": "vehicle.log",
 *   "fileCount": 10,
 *   "fileSize": 1024000,
 *   "priority": 7,
 *   "logPath": "./",
 *   "userName": "yindi",
 *	}
 */
bool Logger::loadConfig(std::string _configFileName) {
	// 先看文件存不存在
    struct stat statbuf;
    int ret = stat(const_cast<char*>(_configFileName.c_str()),&statbuf);
    if ( ret == -1 ) {
    	return false;
    }
    long jsonFileSize=statbuf.st_size;
    // 以下都是rapidjson的推荐操作
	if ( jsonFileSize > 0 ) {
		FILE * pConfigJsonFile = fopen (_configFileName.c_str() , "r"); // 非 Windows 平台使用 "r"
		if ( pConfigJsonFile != NULL ) {
			char *readBuffer = NULL;
			readBuffer = (char *)malloc(sizeof(char)*jsonFileSize);
			//读取文件进行解析成json
			rapidjson::FileReadStream inputFileReadStream(pConfigJsonFile,readBuffer,jsonFileSize);
			rapidjson::Document document;
			document.ParseStream(inputFileReadStream);
			fclose(pConfigJsonFile);
			if(document.IsObject() && document.IsNull() == false) {
				if ( document.HasMember("fileName") ) {
					rapidjson::Value & fileNameValue = document["fileName"];
					if ( fileNameValue.IsString() ) {
						setFileName(fileNameValue.GetString());
					}
				}

				if ( document.HasMember("fileCount") ) {
					rapidjson::Value & fileCountValue = document["fileCount"];
					if ( fileCountValue.IsInt() ) {
						setFileCount(fileCountValue.GetInt());
					}
				}

				if ( document.HasMember("fileSize") ) {
					rapidjson::Value & fileSizeValue = document["fileSize"];
					if ( fileSizeValue.IsInt() ) {
						setFileSize(fileSizeValue.GetInt());
					}
				}

				if ( document.HasMember("priority") ) {
					rapidjson::Value & priorityValue = document["priority"];
					if ( priorityValue.IsInt() ) {
						setPriority(priorityValue.GetInt());
					}
				}

				if ( document.HasMember("logPath") ) {
					rapidjson::Value & logPathValue = document["logPath"];
					if ( logPathValue.IsString() ) {
						setLogPath(logPathValue.GetString());
					}
				}

				if ( document.HasMember("userName") ) {
					rapidjson::Value & userNameValue = document["userName"];
					if ( userNameValue.IsString() ) {
						setUserName(userNameValue.GetString());
					}
				}
			} else {
				return false;
			}
			if ( readBuffer != NULL ) {
				free(readBuffer);
			}
		}
	}
	return true;
}
