/*
 * LogStream.cpp
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */

#include "LogStream.h"
#include <iostream>

void LogStream::openFile(){
	if ( i_fd > 0 ) {
		close(i_fd);
	}
	std::string currentLogFile = s_logPath + s_fileName;
	i_fd = open(currentLogFile.c_str(),O_WRONLY|O_CREAT|O_APPEND, 0766);
	getSumOfLogfile();
	if ( !b_running ) {
		b_running = true;
		std::cout << "\033[32m runThread\033[0m" << std::endl;
		std::thread startBufferThread(&LogStream::BufferThread, this);
		startBufferThread.detach();
	}
}

void LogStream::setFileName(std::string _fileName) {
	s_fileName = _fileName;
	if (b_toFile != true) {
		b_toFile = true;
	}
}

void LogStream::setLogPath(std::string _logPath) {
	s_logPath = _logPath;
}

void LogStream::resetFileSerial(std::set<int> Set) {
	std::set<int>::iterator it = Set.begin();
	char old_serial[i_fileCount] = {0};
	char new_serial[i_fileCount] = {0};
	for ( unsigned int _i = 1; _i <= Set.size(); _i++ ) {
		sprintf(old_serial,"%02d",(*it));
		sprintf(new_serial,"%02d",_i);
		std::string old_name = s_logPath + s_fileName + old_serial;
		std::string new_name = s_logPath + s_fileName + new_serial;
		// TODO: if rename fail
		rename((char*)old_name.c_str(),(char*)new_name.c_str());;
		it++;
	}
}

int LogStream::getSumOfLogfile() {
	DIR *dir;
	struct dirent * ptr;
	int total = 0;
	std::set<int> Set;
	Set.clear();
	dir = opendir(s_logPath.c_str()); /* 打开目录*/
	if ( dir == NULL ) {
		perror("fail to open dir");
		exit(1);
	}

	errno = 0;
	while( (ptr = readdir(dir)) != NULL ) {
		//顺序读取每一个目录项；
		//跳过“..”和“.”两个目录
		if ( strcmp(ptr->d_name,".") == 0 || strcmp(ptr->d_name,"..") == 0 ) {
			continue;
		}
		//尝试加入正则表达式来进行
		if ( ptr->d_type == DT_REG ) {  // qnx中不支持
			std::string str_regex = s_fileName + "(\\d{2})$";
			std::regex my_regex(str_regex);
			std::smatch my_match;
			std::string a = ptr->d_name;
			if ( regex_search(a,my_match,my_regex) ) {
				int c = stoi(my_match[1],nullptr,10);
				if ( c <= i_fileCount ) { // 如果设置的存放文件数量为10,文件名为file.log,那么可能存在的最后log文件是file.log.10,file.log.11会被过滤掉
					total++;
					Set.insert(c);
				}
			}
		}
	}

	if ( (!Set.empty()) && (*(--Set.end()) != (int)Set.size()) ) {
		resetFileSerial(Set);
	}
	if ( errno != 0 ) {
		std::cout << "\033[31m fail to read dir\033[0m"; //失败则输出提示信息
		exit(1);
	}
	closedir(dir);
	i_alreadyLogNum = total; // 已经存在的log文件数量
	return total;
}

// 在测试过程中,连续的log记录会导致程序的崩溃,原因是多次连续的log记录就像是一个while...unique_lock...notify_one的模式
// 而这样的模式最大的弊端就是unique_lock可能会抢占wait的锁,而大概率上是unique_lock抢赢的,所以这会导致wait后的部分迟迟不能进行相应的处理逻辑
// 为了解决这样的问题,考虑机器性能,而又不对程序本身的性能造成明显损害,我们采用sleep+创建新buffer的组合逻辑
void LogStream::append(std::string _message) {
	// 组合逻辑1,＋sleep,大规模测试下性能损耗严重,考虑实际情况几乎不可能出现一直不等待循环的log,且组合逻辑2目前看来够用,暂时将其去掉
	// std::this_thread::sleep_for(std::chrono::microseconds(1));

	// 项目不需要使用buffer时可以替换为直接文件IO操作,性能对比:在ubuntu16上:单次buffer_log:3微秒,非buffer_log:5微秒
	//	std::unique_lock<std::mutex> lck(m_mutex);
	//	checkFile(static_cast<int>(1));
	//	int a = write(i_fd, _message.c_str(), _message.length());
	//	if (a == -1) {
	//	}
	if ( !b_toFile ) {
		std::cout << _message;
	} else {
		if (b_firstLog && s_fileName!="") {
			b_firstLog = false;
			openFile();
		}
		std::unique_lock<std::mutex> lck(m_mutex);
		// log字符串仿越界检测
		if ( _message.length() > (DEFAULT_BUFFER_SIZE/2) ) {
			_message = "oversize log\n";
		}
		if ( p_currentBuffer->avail() >= static_cast<int>(_message.length()) ) {
			p_currentBuffer->append(_message.c_str(), _message.length());
		} else {
			p_outputBuffer.emplace_back(std::move(p_currentBuffer));
			if ( p_nextBuffer ) {
				p_currentBuffer = std::move(p_nextBuffer);
			} else {
				p_currentBuffer.reset(new _logBuffer); // 组合逻辑2, +new buffer
			}
			p_currentBuffer->append(_message.c_str(), _message.length());
			m_cv.notify_one();
		}
	}
}

void LogStream::SortRule() {
	int __flag = 0;
	int it = i_alreadyLogNum;
	char old_serial[i_fileCount] = {0};
	char new_serial[i_fileCount] = {0};
	for ( int _i = 1; _i <= i_alreadyLogNum; _i++ ) {
		sprintf(old_serial,"%02d",it);
		__flag = it+1;
		sprintf(new_serial,"%02d",__flag);
		std::string old_name = s_logPath + s_fileName + old_serial;
		std::string new_name = s_logPath + s_fileName + new_serial;
//		std::cout<<"old1 file is "<<old_name<<std::endl;
//		std::cout<<"new1 file is "<<new_name<<std::endl;
		rename((char*)old_name.c_str(),(char*)new_name.c_str());
		it--;
	}
	sprintf(new_serial,"%02d",it+1);
	std::string _new_name = s_logPath + s_fileName + new_serial;
	std::string log_name = s_logPath + s_fileName;
//	std::cout<<"old2 file is "<<log_name<<std::endl;
//	std::cout<<"new2 file is "<<_new_name<<std::endl;
	rename(log_name.c_str(),_new_name.c_str());
}

void LogStream::rollRule() {
	close(i_fd);
	std::string _currentLogFile = s_logPath + s_fileName;
	std::string _filePrefix = s_logPath + s_fileName + ".";
	if ( i_alreadyLogNum >= i_fileCount ) {
		i_alreadyLogNum = i_fileCount;
		char _oldLogFile[24];
		snprintf(_oldLogFile, 24, "%s%d", _filePrefix.c_str(), i_alreadyLogNum);
		remove(_oldLogFile);
		i_alreadyLogNum--;
		SortRule();
	} else {
		SortRule();
	}
	i_fd = open(_currentLogFile.c_str(), O_WRONLY|O_CREAT|O_APPEND, 0766);
	i_alreadyLogNum++;
}

void LogStream::checkFile(int _bufferCount) {
	off_t offset = ::lseek(i_fd, 0, SEEK_END);
	if ( (static_cast<int>(offset) + _bufferCount*DEFAULT_BUFFER_SIZE) > i_fileSize ) {
		rollRule();
	}
}

void LogStream::BufferThread() {
	std::unique_ptr<_logBuffer> _pNewBuffer1(new _logBuffer); // 常见的错误方式是:std::unique_ptr<_logBuffer> _pNewBuffer1 = new _logBuffer;
	std::unique_ptr<_logBuffer> _pNewBuffer2(new _logBuffer);
	_logBufVector _pBufferToWrite; // 添加逻辑:写缓冲区,使得锁更快得以释放,提升了程序效率,经测试:buffer10240的前提下,3000次连续log记录,性能提升由9ms-->8ms
	while (b_running) {
		{
			std::unique_lock<std::mutex> lck(m_mutex);
			if ( p_outputBuffer.empty() ) {
				m_cv.wait_for(lck, std::chrono::milliseconds(i_waitMilliSeconds));
			}
			p_outputBuffer.emplace_back(std::move(p_currentBuffer));
			p_currentBuffer = std::move(_pNewBuffer1);
			p_outputBuffer.swap(_pBufferToWrite);
			if ( !p_nextBuffer ) {
				p_nextBuffer = std::move(_pNewBuffer2);
			}
		}
		// 检查日志大小,执行日志滚动逻辑
		checkFile(static_cast<int>(_pBufferToWrite.size()));
		// 将缓冲区的数据写入到文件中
		for (auto& buf : _pBufferToWrite) {
			// 注意的是write操作是没有缓冲区的
			int a = write(i_fd, buf->data(), buf->length());
			if (a == -1) {
				// TODO write的异常处理
			}
		}

		// 上面组合逻辑2+new buffer的配套处理
	    if (_pBufferToWrite.size() > 2) {
	    	_pBufferToWrite.resize(2);
	    }

	    if (!_pNewBuffer1)
	    {
	    	_pNewBuffer1 = std::move(_pBufferToWrite.back());
	    	_pBufferToWrite.pop_back();
			_pNewBuffer1->reset();
	    }

	    if (!_pNewBuffer2)
	    {
	    	// TODO: 待验证,是否move之后还需要pop_back,以及两者之间是否会相互影响,将结论补充到文档中
	    	_pNewBuffer2 = std::move(_pBufferToWrite.back());
	    	_pBufferToWrite.pop_back();
			_pNewBuffer2->reset();
	    }

	    _pBufferToWrite.clear();
	}
}

