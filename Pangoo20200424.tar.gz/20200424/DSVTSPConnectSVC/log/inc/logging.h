/*
 * logging.h
 *
 *  Created on: Sep 27, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef LOGGING_H_
#define LOGGING_H_

#include "trans.h"
//==============================================将以下部分作为与用户交互的API接口==================================================

// 当前采用的LOG记法为: LOG_INFO<<"hello world"
#define LOG_DEBUG if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("DEBUG")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("DEBUG")).self()
#define LOG_INFO if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("INFO")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("INFO")).self()
#define LOG_NOTICE if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("NOTICE")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("NOTICE")).self()
#define LOG_WARN if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("WARN")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("WARN")).self()
#define LOG_ERROR if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("ERROR")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("ERROR")).self()
#define LOG_CRIT if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("CRIT")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("CRIT")).self()
#define LOG_ALERT if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("ALERT")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("ALERT")).self()
#define LOG_EMERG if(Logger::GetInstance()->getPriority() >= Priority::getPriorityValue("EMERG")) \
	trans(__FILE__, __LINE__, Priority::getPriorityValue("EMERG")).self()

// 配置内容
// --这里注意如果switch中有多种类型需要推到,不能直接将模板类型值写入,比如直接使用setPriority(_value)就是错误的,
// --报错为:could not convert ‘_value’ from ‘int’ to ‘std::__cxx11::string {aka std::__cxx11::basic_string<char>}’

typedef enum {
	TP_PRIORITY = 1,
	TP_USER_NAME,
	TP_FILESIZE,
	TP_FILECOUNT,
	TP_LOGPATH,
	TP_FILENAME
} eConfigType;

template <typename ValType>
inline void LOG_CONFIG_SET(eConfigType type, ValType _value) {
	std::stringstream str;
	str << _value;
	std::string a = str.str();
	switch(type) {
	case TP_PRIORITY:
		Logger::GetInstance()->setPriority(atoi(a.c_str()));
		break;
	case TP_USER_NAME:
		Logger::GetInstance()->setUserName(a);
		break;
	case TP_FILESIZE:
		Logger::GetInstance()->setFileSize(atoi(a.c_str()));
		break;
	case TP_FILECOUNT:
		Logger::GetInstance()->setFileCount(atoi(a.c_str()));
		break;
	case TP_LOGPATH:
		Logger::GetInstance()->setLogPath(a);
		break;
	case TP_FILENAME:
		Logger::GetInstance()->setFileName(a);
		break;
	default:
		break;
	}
}
// 配置文件----给出绝对路径或者相对路径
inline bool LOG_CONFIG_FILE(std::string _logName) {
	return Logger::GetInstance()->loadConfig(_logName);
}



#endif /* LOGGING_H_ */
