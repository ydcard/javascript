/*
 * trans.h
 *
 *  Created on: Sep 27, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef TRANS_H_
#define TRANS_H_

//#include "Logger.h"
// trans组织log日志内容的传递类,它的生命周期很短,在一次调用之后会被释放,所以我的组合与数据传递都是在析构函数中实现的
/*
 * TODO: 在测试中__FILE__输出了绝对路径:/home/desay-sv/workspace/HDMAP/LOG/test_release/test1.cpp
 * 这是因为__FILE__是根据实际编译的过程产生的,如果你在编译的时候使用的是绝对路径那么会一改路径为主,
 * 比如:
 *  gcc -o filetest /srv/example/c/test/filetest.c | __FILE__输出就是/srv/example/c/test/filetest.c
 */
#include "Logger.h"
#include <string>
#include <sstream>

class trans {
public:
	trans(std::string _filename, int _line, int _priority);
	~trans();
	template <typename T>
	trans& operator<<(const T& t) {
		_msgstream << t;
		return *this;
	}
	trans& self(){
		return *this;
	}

	std::string getTimeStamp();
// 2019-09-25 16:21:49.994447 | INFO | test5.cpp:157 | hello yindi2019 | <desay>
	std::string combine();
	std::stringstream _msgstream;
	std::string s_filename;
	int i_line;
	int i_priority;
};


#endif /* TRANS_H_ */
