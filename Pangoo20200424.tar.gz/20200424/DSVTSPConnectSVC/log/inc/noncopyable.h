/*
 * noncopyable.h
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef NONCOPYABLE_H_
#define NONCOPYABLE_H_

class noncopyable
{
 public:
  noncopyable(const noncopyable&) = delete;
  void operator=(const noncopyable&) = delete;

 protected:
  noncopyable() = default;
  ~noncopyable() = default;
};

#endif /* NONCOPYABLE_H_ */
