/*
 * LogStream.h
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef LOGSTREAM_H_
#define LOGSTREAM_H_

#include <stdio.h>

#include "noncopyable.h"
#include <mutex>
#include <condition_variable>
#include <string>
#include <unistd.h>
#include <vector>
#include <thread>
#include <chrono>
#include <string.h>
#include <regex>
#include <algorithm>
#include <set>
#include <atomic>
#include <fcntl.h>
#include <dirent.h>
#include <stdlib.h>
#include <errno.h>
#include "LogConfig.h"

const int DEFAULT_BUFFER_SIZE = 2048; // 缓冲区的大小

// 定义缓冲类: logBuffer<10240> _buffer;
template <int SIZE>
class logBuffer : public noncopyable{
public:
	logBuffer() {
		reset();
	}
	~logBuffer(){}
	int avail() {
		return static_cast<int>(end() - p_current);
	}
	void add(size_t len) { // size_t == unsigned int
		p_current += len;
	}
	void append(const char *_buf, size_t _bufSize) {
		memcpy(p_current, _buf, _bufSize);
		add(_bufSize);
	}
	void reset() {
		memset(s_buffer, 0, SIZE);
		p_current = s_buffer;
	}
	char *current() {
		return p_current;
	}
	const char *data() {
		return s_buffer;
	}
	int length() const {
		return static_cast<int>(p_current - s_buffer);
	}

	int size() {
		return SIZE;
	}

private:
	const char* end() const {
		return s_buffer + SIZE;
	}
	char s_buffer[SIZE];
	char *p_current;
};

class LogStream {
public:
	typedef logBuffer<DEFAULT_BUFFER_SIZE> _logBuffer;
	typedef std::vector<std::unique_ptr<_logBuffer>> _logBufVector;

	LogStream(std::string _fileName, std::string _logPath,
			int _fileCount, int _fileSize)
	: p_currentBuffer(new _logBuffer),
	  p_nextBuffer(new _logBuffer),
	  p_outputBuffer(),
	  b_running(false),
	  b_toFile(false),
	  i_fd(-1),
	  s_fileName(_fileName),
	  s_logPath(_logPath),
	  i_fileCount(_fileCount),
	  i_fileSize(_fileSize),
	  i_waitMilliSeconds(DEFAULT_WAIT_SECONDS),
	  i_alreadyLogNum(-1),
	  b_firstLog(true)
	{
	}

	// 万一log文件出现缺失,比如只有01,03,09结尾的log文件,调用此函数可以调整为01,02,03结尾的文件,这是为了后续的日志重命名逻辑
	void resetFileSerial(std::set<int> Set);

	// 获取当前log文件的格式,因为可能出现log文件部分被删除或者全部被删除的情况
	int getSumOfLogfile();

	void setFileName(std::string _fileName);

	void setLogPath(std::string _logPath);

	void setFileCount(int _fileCount) { i_fileCount = _fileCount; }

	void setFileSize(int _fileSize) { i_fileSize = _fileSize; }

	~LogStream() {}

	// log数据追加函数,追加满之后会通知BufferThread线程来处理缓冲区数据
	void append(std::string _message);

	// 日志回滚--日志重命名
	void SortRule();

	// 日志回滚:在开始的时候关闭log文件,在结束的时候打开log文件
	void rollRule();

	// 当前log文件的剩余空间能否存下缓冲区的数据,不能则进行日志回滚rollRule
	void checkFile(int _bufferCount);

	// 主要功能: 将缓冲区的内容写入到磁盘文件
	// 有设置最大等待时间,超时情况下在会强制将缓冲区的内容写到磁盘文件
	void BufferThread();

	void openFile();

private:
	std::unique_ptr<_logBuffer> p_currentBuffer;
	std::unique_ptr<_logBuffer> p_nextBuffer;
	_logBufVector p_outputBuffer;
	std::mutex m_mutex;
	std::condition_variable m_cv;
	bool b_running;
	bool b_toFile;

	std::atomic<int> i_fd;
	std::string s_fileName;
	std::string s_logPath;
	int i_fileCount;
	int i_fileSize;
	int i_waitMilliSeconds;
	int i_alreadyLogNum;
	std::atomic<bool> b_firstLog;
};

#endif /* LOGSTREAM_H_ */
