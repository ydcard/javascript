/*
 * Logger.h
 *
 *  Created on: Sep 24, 2019
 *      Author: yindi
 * Description: 
 */

#ifndef LOGGER_H_
#define LOGGER_H_

#include <stdio.h>
#include <iostream>

#include <sys/stat.h>
#include <sys/time.h>
#include "LogConfig.h"
#include "Priority.h"
#include "LogStream.h"

class Logger {
private:
	Logger();
	static Logger *m_instance;

public:
	static Logger* GetInstance() {
		if (nullptr == m_instance) {
			m_instance = new Logger();
		}
		return m_instance;
	}
	~Logger() {
		delete m_instance;
		m_instance = nullptr;
	}

	inline std::string getFileName() {
		return s_fileName;
	}
	inline std::string getFormat() {
		return s_format;
	}
	inline std::string getLogPath() {
		return s_logPath;
	}
	inline int getPriority() {
		return i_priority;
	}
	inline int getFileCount() {
		return i_fileCount;
	}
	inline int getFileSize() {
		return i_fileSize;
	}
	inline std::string getUserName() {
		return s_userName;
	}
	// TODO: 将log的字符串拼接到缓存区
	void insertBuffer(std::string _logMsg) {
		m_logstream->append(_logMsg);
	}

	// username和priority用于log字符串的拼接
	bool setUserName(std::string _userName); // 超过10字节截断
	bool setPriority(int _priority); // 所有小于这个等级的log将会被记录

	// 日志回滚模块的重要变量:filename,logPath,fileCount,fileSize
	bool setFileName(std::string _fileName); // 超过20字节截断
	bool setFormat(std::string _format); // TODO: 先支持默认格式,后续考虑仅给出几种模式供用户选择
	bool setLogPath(std::string _logPath); // 自己设置要求绝对路径,所以是以'/'开始,以'/'结束
	bool setFileCount(int _fileCount); // 0~99, 暂时设置阈值为99
	bool setFileSize(int _fileSize); // 是以1字节为单位的文件大小

//	bool setReserveTime(int _days); // 设置log保存的时间,默认是不设置的,设置完成之后响应的b_reserveFlag为true;

	bool loadConfig(std::string _configFileName); // TODO: 通过配置文件的方式来进行设置,为了方便现阶段先使用json

private:
	std::string s_fileName;
	std::string s_format;
	std::string s_logPath;
	int i_priority;
	int i_fileCount;
	int i_fileSize;
	std::string s_userName;
	std::unique_ptr<LogStream> m_logstream;
//	LogInfo p_loginfo;
};




#endif /* LOGGER_H_ */
